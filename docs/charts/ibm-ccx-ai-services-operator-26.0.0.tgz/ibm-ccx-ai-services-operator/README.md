# IBM Content Cortex AI Services Operator Helm Chart

[![Helm Version](https://img.shields.io/badge/Helm-v4.0+-blue.svg)](https://helm.sh)
[![Kubernetes Version](https://img.shields.io/badge/Kubernetes-v1.24+-blue.svg)](https://kubernetes.io)
[![OpenShift Version](https://img.shields.io/badge/OpenShift-v4.12+-red.svg)](https://www.openshift.com)
[![Chart Version](https://img.shields.io/badge/Chart-26.0.0-green.svg)](./Chart.yaml)

## 📋 Table of Contents

- [Overview](#overview)
- [Prerequisites](#prerequisites)
- [Quick Start](#quick-start)
- [Installation](#installation)
- [Configuration](#configuration)
- [Post-Installation](#post-installation)
- [AI Provider Configuration](#ai-provider-configuration)
- [Upgrading](#upgrading)
- [Uninstallation](#uninstallation)
- [Troubleshooting](#troubleshooting)
- [Advanced Configuration](#advanced-configuration)
- [Use Cases](#use-cases)
- [Useful Helm Commands](#useful-helm-commands)
- [Support](#support)

## 🎯 Overview

The **IBM Content Cortex AI Services Operator** Helm chart deploys the operator for **IBM AI Services** on Kubernetes and OpenShift platforms. The operator enables agentic AI capabilities for enterprise content management, providing:

- **LLM Integration**: Connect to multiple AI providers (watsonx.ai SaaS, watsonx.ai Lightweight Engine, Microsoft Azure AI Foundry)
- **Intelligent Document Processing**: AI-powered content analysis and extraction
- **Natural Language Interactions**: Conversational interfaces for content access
- **Secure Credential Management**: Vault integration for AI provider credentials
- **Cloud-Native Deployment**: Kubernetes-native architecture with operator pattern
- **Multi-Provider Support**: Flexible AI provider configuration (SaaS and on-premises)

### What is IBM AI Services?

IBM AI Services is a comprehensive AI platform that enhances Content Cortex with three core components:

1. **Reasoning Service**: AI-powered reasoning engine that processes natural language queries and provides intelligent responses using configured LLM providers
2. **Core MCP Server**: Model Context Protocol server that manages AI model interactions, tool registrations, and agent orchestration
3. **Agent UI Plugin**: User interface plugin for Content Navigator that enables conversational AI interactions with enterprise content

**Key Capabilities:**
- **Semantic Search**: Natural language queries across content repositories
- **Document Summarization**: AI-generated summaries of documents
- **Content Classification**: Automatic categorization and tagging
- **Intelligent Extraction**: Extract key information from documents
- **Conversational AI**: Chat-based content interactions through the Agent UI
- **Tool Integration**: Extensible framework for custom AI tools and agents

### Supported AI Providers

- **watsonx.ai SaaS** - IBM's cloud-based AI platform with enterprise LLMs
- **watsonx.ai Lightweight Engine (LWE)** - On-premises watsonx deployment for air-gapped environments
- **Microsoft Azure AI Foundry** - Azure's AI platform (formerly Azure OpenAI)

## ✅ Prerequisites

Before installing this chart, ensure you have:

### Required

- **Kubernetes 1.24+** or **OpenShift 4.12+**
- **Helm 4.0+** installed and configured
- **IBM Entitlement Key** from [IBM Container Library](https://myibm.ibm.com/products-services/containerlibrary)
- **Namespace** created for the deployment
- **Minimum Resources**: 10m CPU and 64Mi memory available per operator replica
- **AI Provider Access**: Connectivity to watsonx.ai SaaS, watsonx.ai LWE, or Microsoft Azure AI Foundry
- **Storage Class**: File storage class for PVC provisioning

### Recommended

- **Content Cortex Deployment**: IBM Content Operator and Content Cortex already deployed
- **Vault Integration**: HashiCorp Vault for secure credential management
- **Network Policies**: Configured for AI provider egress access
- **TLS Certificates**: For secure communication with AI services
- **Redis**: For enhanced caching and performance (optional, uses PVC by default)

### Network Requirements

The operator requires egress access to:
- Container registry (cp.icr.io or your private registry)
- AI provider endpoints:
  - watsonx.ai SaaS: `*.ml.cloud.ibm.com`, `*.watson.cloud.ibm.com`
  - watsonx.ai LWE: Your on-premises endpoint
  - Microsoft Azure AI Foundry: `ai.azure.com`, `*.openai.azure.com`
- Kubernetes API server
- Content Cortex services (GraphQL, CPE) if integrating with existing deployment

## 🚀 Quick Start

Get up and running in 5 minutes:

```bash
# 1. Create namespace
kubectl create namespace ibm-ai-services

# 2. Create image pull secret
kubectl create secret docker-registry ibm-entitlement-key \
  --docker-server=cp.icr.io \
  --docker-username=cp \
  --docker-password=<your-entitlement-key> \
  --namespace ibm-ai-services

# 3. Install the chart
helm install ai-services-operator ./helm-charts/ai-services-operator \
  --namespace ibm-ai-services

# 4. Verify installation
kubectl get pods -n ibm-ai-services -l control-plane=ibm-ccx-ai-services-operator
```

## 📦 Installation

### Step 1: Create Namespace

```bash
kubectl create namespace ibm-ai-services
```

**OpenShift:**
```bash
oc new-project ibm-ai-services
```

### Step 2: Create Image Pull Secret

Get your IBM Entitlement Key from [IBM Container Library](https://myibm.ibm.com/products-services/containerlibrary).

```bash
kubectl create secret docker-registry ibm-entitlement-key \
  --docker-server=cp.icr.io \
  --docker-username=cp \
  --docker-password=<your-entitlement-key> \
  --namespace ibm-ai-services
```

**Verify the secret:**
```bash
kubectl get secret ibm-entitlement-key -n ibm-ai-services
```

### Step 3: Install the Chart

**Basic Installation:**
```bash
helm install ai-services-operator ./helm-charts/ai-services-operator \
  --namespace ibm-ai-services
```

**With Custom Values:**
```bash
helm install ai-services-operator ./helm-charts/ai-services-operator \
  --namespace ibm-ai-services \
  --values custom-values.yaml
```

**With Inline Overrides:**
```bash
helm install ai-services-operator ./helm-charts/ai-services-operator \
  --namespace ibm-ai-services \
  --set image.tag=26.0.0 \
  --set replicaCount=2
```

### Step 4: Verify Installation

```bash
# Check Helm release
helm list -n ibm-ai-services

# Check operator deployment
kubectl get deployment ibm-ccx-ai-services-operator -n ibm-ai-services

# Check operator pods
kubectl get pods -n ibm-ai-services -l control-plane=ibm-ccx-ai-services-operator

# View operator logs
kubectl logs -n ibm-ai-services -l control-plane=ibm-ccx-ai-services-operator -f

# Check CRD installation
kubectl get crd ccxaiservices.ccxaiservices.operator.ibm.com
```

**Expected Output:**
```
NAME                             READY   UP-TO-DATE   AVAILABLE   AGE
ibm-ccx-ai-services-operator     1/1     1            1           2m

NAME                                              READY   STATUS    RESTARTS   AGE
ibm-ccx-ai-services-operator-7d8f9c5b6d-x7k2p     1/1     Running   0          2m
```

## ⚙️ Configuration

### Key Configuration Parameters

| Parameter | Description | Default | Required |
|-----------|-------------|---------|----------|
| `image.repository` | Operator image repository | `icr.io/cpopen/ibm-ccx-ai-services-operator` | Yes |
| `image.digest` | Default operator image digest | `sha256:86b0110a...` | No |
| `image.tag` | Optional image tag override | `""` | No |
| `image.pullPolicy` | Image pull policy | `IfNotPresent` | Yes |
| `imagePullSecrets` | Image pull secrets | `[{name: ibm-entitlement-key}]` | Yes |
| `replicaCount` | Number of operator replicas | `1` | Yes |
| `serviceAccount.create` | Create service account | `true` | Yes |
| `serviceAccount.name` | Service account name | `ibm-ccx-ai-services-operator-sa` | Yes |
| `rbac.create` | Create RBAC resources | `true` | Yes |
| `operator.name` | Operator name | `ibm-ccx-ai-services-operator` | Yes |
| `operator.resources.limits.cpu` | CPU limit | `500m` | Yes |
| `operator.resources.limits.memory` | Memory limit | `128Mi` | Yes |
| `operator.resources.requests.cpu` | CPU request | `10m` | Yes |
| `operator.resources.requests.memory` | Memory request | `64Mi` | Yes |
| `operator.args` | Command line arguments | `[--leader-elect, --health-probe-bind-address=:8081]` | Yes |

### Image Configuration

The chart supports two image reference methods:

**1. Using Digest (Default - Recommended for Production):**
```yaml
image:
  repository: icr.io/cpopen/ibm-ccx-ai-services-operator
  digest: "sha256:86b0110a6cb6926373ee4aa23ee25002acaf5e596ceaf8c4941fe171b11b476c"
  tag: ""  # Leave empty to use digest
```

**2. Using Tag (Flexible for Development):**
```yaml
image:
  repository: icr.io/cpopen/ibm-ccx-ai-services-operator
  tag: "26.0.0"  # When set, digest is ignored
```

### Resource Configuration

**Development Environment:**
```yaml
operator:
  resources:
    limits:
      cpu: 200m
      memory: 128Mi
    requests:
      cpu: 10m
      memory: 64Mi
```

**Production Environment:**
```yaml
operator:
  resources:
    limits:
      cpu: "1"
      memory: 256Mi
    requests:
      cpu: 100m
      memory: 128Mi
```

### Security Configuration

**Basic Security (Default):**
```yaml
operator:
  securityContext:
    runAsNonRoot: true
  
  containerSecurityContext:
    allowPrivilegeEscalation: false
    privileged: false
    readOnlyRootFilesystem: true
    capabilities:
      drop:
        - ALL
```

**Enhanced Security (OpenShift 4.12+):**
```yaml
operator:
  securityContext:
    runAsNonRoot: true
    runAsUser: 1001
  
  containerSecurityContext:
    allowPrivilegeEscalation: false
    privileged: false
    readOnlyRootFilesystem: true
    capabilities:
      drop:
        - ALL
    seccompProfile:
      type: RuntimeDefault
```

### Network Policy Labels

Control network egress for AI provider access:

```yaml
networkPolicyLabels:
  # Deny all egress by default
  com.ibm.ccxai.networking/egress-deny-all: "true"
  
  # Allow specific egress
  com.ibm.ccxai.networking/egress-allow-same-namespace: "true"
  com.ibm.ccxai.networking/egress-allow-k8s-services: "true"
  
  # Allow all (for AI provider access)
  com.ibm.ccxai.networking/egress-allow-all: "true"
```

### Vault Integration for Secrets

Enable HashiCorp Vault integration for secure credential management:

```yaml
vault:
  enabled: true
  secretsMountPath: /tmp/secrets
  certificatesMountPath: /tmp/certificates
  secrets:
    - name: ibm-providers-config-secret
      type: secret
    - name: ai-services-root-ca
      type: certificate
```

**Prerequisites:**
- Secrets Store CSI Driver installed
- Vault configured with appropriate policies
- SecretProviderClass resources created

### Redis Configuration

Enable Redis for enhanced caching and performance:

**In Helm values (operator chart):**
```yaml
# Redis is configured in the CCXAIServices CR, not in operator values
# The operator chart only deploys the operator itself
```

**In CCXAIServices CR:**
```yaml
spec:
  shared_configuration:
    sc_redis_enable: true
    storage_configuration:
      sc_slow_file_storage_classname: "ibmc-file-gold"
      sc_block_storage_classname: "ibmc-block-gold"  # Required for Redis
```

**Note:** When Redis is enabled, block storage class is required for Redis PVCs.

### Custom Values File Example

Create `my-values.yaml`:

```yaml
# Image configuration
image:
  tag: 26.0.0
  pullPolicy: Always

# Scaling
replicaCount: 2

# Resources
operator:
  resources:
    limits:
      cpu: "1"
      memory: 256Mi
    requests:
      cpu: 100m
      memory: 128Mi
  
  # Command arguments
  args:
    - --leader-elect
    - --health-probe-bind-address=:8081
    - --metrics-bind-address=:8080

# Vault integration
vault:
  enabled: true
  secretsMountPath: /tmp/secrets
  certificatesMountPath: /tmp/certificates
  secrets:
    - name: ibm-providers-config-secret
      type: secret
    - name: ldap-bind-secret
      type: secret
    - name: ibm-graphql-ssl-secret
      type: certificate

# Node affinity
affinity:
  nodeAffinity:
    requiredDuringSchedulingIgnoredDuringExecution:
      nodeSelectorTerms:
        - matchExpressions:
            - key: kubernetes.io/arch
              operator: In
              values:
                - amd64

# Custom annotations
podAnnotations:
  custom-annotation: "custom-value"
  ai-provider: "watsonx"

# Network policy labels
networkPolicyLabels:
  com.ibm.ccxai.networking/egress-allow-all: "true"
  com.ibm.ccxai.networking/egress-allow-k8s-services: "true"
```

Install with custom values:
```bash
helm install ai-services-operator ./helm-charts/ai-services-operator \
  --namespace ibm-ai-services \
  --values my-values.yaml
```

## 🔄 Post-Installation

After installing the operator, you need to create a CCXAIServices custom resource to deploy the AI services components.

### 1. Verify Operator Status

```bash
# Check deployment
kubectl get deployment ibm-ccx-ai-services-operator -n ibm-ai-services

# Check pods
kubectl get pods -n ibm-ai-services -l control-plane=ibm-ccx-ai-services-operator

# View logs
kubectl logs -n ibm-ai-services -l control-plane=ibm-ccx-ai-services-operator --tail=100 -f
```

### 2. Verify CRD Installation

```bash
# Check if CRD exists
kubectl get crd ccxaiservices.ccxaiservices.operator.ibm.com

# View CRD details
kubectl describe crd ccxaiservices.ccxaiservices.operator.ibm.com

# List CRD versions
kubectl get crd ccxaiservices.ccxaiservices.operator.ibm.com -o jsonpath='{.spec.versions[*].name}'
```

### 3. Create AI Provider Configuration Secret

Before deploying AI services, create the provider configuration secret:

```bash
# Example: watsonx.ai SaaS provider
kubectl create secret generic ibm-providers-config-secret \
  --from-literal=WATSONXPROD_PROVIDER_TYPE=watsonx_saas \
  --from-literal=WATSONXPROD_PROVIDER_URL=https://us-south.ml.cloud.ibm.com \
  --from-literal=WATSONXPROD_API_KEY=<your-api-key> \
  --from-literal=WATSONXPROD_SPACE_ID=<your-space-id> \
  --from-literal=WATSONXPROD_ENABLED=true \
  --from-literal=WATSONXPROD_MODEL_0_MODEL=openai/gpt-oss-120b \
  --from-literal=WATSONXPROD_MODEL_0_DEFAULT=true \
  --from-literal=WATSONXPROD_MODEL_0_MAX_COMPLETION_TOKENS=2048 \
  --from-literal=WATSONXPROD_MODEL_0_TEMPERATURE=0.7 \
  --from-literal=WATSONXPROD_MODEL_0_CONTEXT_WINDOW_TOKEN_LIMIT=131072 \
  --namespace ibm-ai-services
```

### 4. Create AI Services Deployment

Create a CCXAIServices custom resource. See the [full CR example](../../../descriptors/content-cortex/ai-services/ibm_ai_services_full_cr.yaml) for all available options.

**Minimal Example:**
```yaml
apiVersion: ccxaiservices.operator.ibm.com/v1
kind: CCXAIServices
metadata:
  name: ai-services
  namespace: ibm-ai-services
spec:
  appVersion: 26.0.0
  license:
    accept: true
  
  shared_configuration:
    sc_deployment_context: "FNCM"
    sc_ccx_license_model: "CCx.Ess.AU"
    image_pull_secrets:
      - ibm-entitlement-key
    sc_image_repository: cp.icr.io
    root_ca_secret: ai-services-root-ca
    sc_deployment_profile_size: "small"
    storage_configuration:
      sc_slow_file_storage_classname: "ibmc-file-gold"
  
  reasoning_service_configuration:
    reasoning_service_secret_name: ibm-providers-config-secret
    replica_count: 2
  
  core_mcp_server_configuration:
    replica_count: 2
```

Apply the CR:
```bash
kubectl apply -f ai-services-cr.yaml
```

### 5. Monitor Deployment Progress

```bash
# Watch all pods
kubectl get pods -n ibm-ai-services -w

# Check operator logs for reconciliation
kubectl logs -n ibm-ai-services -l control-plane=ibm-ccx-ai-services-operator -f | grep -i reconcile

# Check events
kubectl get events -n ibm-ai-services --sort-by='.lastTimestamp'
```

## 🤖 AI Provider Configuration

Content Cortex AI Services supports the following AI providers:

### Supported Providers

1. **watsonx.ai SaaS** - IBM's cloud-based AI platform
2. **watsonx.ai Lightweight Engine (LWE)** - On-premises watsonx deployment
3. **Microsoft Azure AI Foundry** - Azure's AI platform (formerly Azure OpenAI)

### watsonx.ai SaaS Integration

**Provider Type:** `watsonx_saas`

**1. Create Provider Configuration Secret:**

The AI provider credentials are stored in a Kubernetes secret referenced by the `reasoning_service_secret_name` field in the CR.

```bash
# Create the providers config secret with watsonx SaaS configuration
kubectl create secret generic ibm-providers-config-secret \
  --from-literal=WATSONXPROD_PROVIDER_TYPE=watsonx_saas \
  --from-literal=WATSONXPROD_PROVIDER_URL=https://us-south.ml.cloud.ibm.com \
  --from-literal=WATSONXPROD_API_KEY=<your-api-key> \
  --from-literal=WATSONXPROD_SPACE_ID=<your-space-id> \
  --from-literal=WATSONXPROD_ENABLED=true \
  --namespace ibm-ai-services
```

**Available Endpoints:**
- US South: `https://us-south.ml.cloud.ibm.com`
- EU Frankfurt: `https://eu-de.ml.cloud.ibm.com`
- Tokyo: `https://jp-tok.ml.cloud.ibm.com`

**2. Configure Model Settings:**

Add model configuration to the secret:
```bash
kubectl create secret generic ibm-providers-config-secret \
  --from-literal=WATSONXPROD_MODEL_0_MODEL=openai/gpt-oss-120b \
  --from-literal=WATSONXPROD_MODEL_0_DEFAULT=true \
  --from-literal=WATSONXPROD_MODEL_0_MAX_COMPLETION_TOKENS=2048 \
  --from-literal=WATSONXPROD_MODEL_0_TEMPERATURE=0.7 \
  --from-literal=WATSONXPROD_MODEL_0_CONTEXT_WINDOW_TOKEN_LIMIT=131072 \
  --namespace ibm-ai-services
```

**3. Reference in CCXAIServices CR:**
```yaml
apiVersion: ccxaiservices.operator.ibm.com/v1
kind: CCXAIServices
metadata:
  name: ai-services
spec:
  reasoning_service_configuration:
    reasoning_service_secret_name: ibm-providers-config-secret
```

### watsonx.ai Lightweight Engine (On-Premises)

**Provider Type:** `watsonx_lwe`

**1. Create Provider Configuration Secret:**

```bash
kubectl create secret generic ibm-providers-config-secret \
  --from-literal=WATSONXONPREM_PROVIDER_TYPE=watsonx_lwe \
  --from-literal=WATSONXONPREM_PROVIDER_URL=https://watsonx.company.local:9443 \
  --from-literal=WATSONXONPREM_API_KEY=<your-api-key> \
  --from-literal=WATSONXONPREM_USERNAME=<your-username> \
  --from-literal=WATSONXONPREM_VERSION=5.4 \
  --from-literal=WATSONXONPREM_INSTANCE_ID=openshift \
  --from-literal=WATSONXONPREM_ENABLED=true \
  --namespace ibm-ai-services
```

**2. Configure Model Settings:**
```bash
kubectl create secret generic ibm-providers-config-secret \
  --from-literal=WATSONXONPREM_MODEL_0_MODEL=openai/gpt-oss-120b \
  --from-literal=WATSONXONPREM_MODEL_0_DEFAULT=true \
  --from-literal=WATSONXONPREM_MODEL_0_MAX_COMPLETION_TOKENS=2048 \
  --from-literal=WATSONXONPREM_MODEL_0_TEMPERATURE=0.7 \
  --from-literal=WATSONXONPREM_MODEL_0_CONTEXT_WINDOW_TOKEN_LIMIT=131072 \
  --namespace ibm-ai-services
```

### Microsoft Azure AI Foundry Integration

**Provider Type:** `microsoft_foundry`

**1. Create Provider Configuration Secret:**

```bash
kubectl create secret generic ibm-providers-config-secret \
  --from-literal=AZUREFOUNDRY_PROVIDER_TYPE=microsoft_foundry \
  --from-literal=AZUREFOUNDRY_PROVIDER_URL=https://ai.azure.com/api/v1 \
  --from-literal=AZUREFOUNDRY_API_KEY=<your-azure-api-key> \
  --from-literal=AZUREFOUNDRY_ENABLED=true \
  --namespace ibm-ai-services
```

**2. Configure Model Settings:**
```bash
kubectl create secret generic ibm-providers-config-secret \
  --from-literal=AZUREFOUNDRY_MODEL_0_MODEL=gpt-5.4 \
  --from-literal=AZUREFOUNDRY_MODEL_0_DEFAULT=true \
  --from-literal=AZUREFOUNDRY_MODEL_0_USE_ENTRA_ID=false \
  --from-literal=AZUREFOUNDRY_MODEL_0_MAX_COMPLETION_TOKENS=16384 \
  --from-literal=AZUREFOUNDRY_MODEL_0_TEMPERATURE=1.0 \
  --from-literal=AZUREFOUNDRY_MODEL_0_TIMEOUT=60 \
  --from-literal=AZUREFOUNDRY_MODEL_0_API_VERSION=2024-12-01-preview \
  --from-literal=AZUREFOUNDRY_MODEL_0_CONTEXT_WINDOW_TOKEN_LIMIT=272000 \
  --namespace ibm-ai-services
```

**Optional: Enable Microsoft Entra ID Authentication:**
Set `USE_ENTRA_ID=true` to use Entra ID (formerly Azure AD) instead of API key authentication.

### Network Requirements for AI Providers

Ensure network policies allow egress to:

**watsonx.ai SaaS:**
- `*.ml.cloud.ibm.com` (port 443)
- `*.watson.cloud.ibm.com` (port 443)

**watsonx.ai Lightweight Engine:**
- Your on-premises watsonx endpoint (port 443 or custom)

**Microsoft Azure AI Foundry:**
- `ai.azure.com` (port 443)
- `*.openai.azure.com` (port 443) - if using custom Azure OpenAI endpoint

**Configure Network Policy:**
```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: ai-services-egress
  namespace: ibm-ai-services
spec:
  podSelector:
    matchLabels:
      control-plane: ibm-ccx-ai-services-operator
  policyTypes:
    - Egress
  egress:
    - to:
        - namespaceSelector: {}
      ports:
        - protocol: TCP
          port: 443
```

## 📈 Upgrading

### Upgrade the Operator

```bash
# Upgrade with same values
helm upgrade ai-services-operator ./helm-charts/ai-services-operator \
  --namespace ibm-ai-services \
  --reuse-values

# Upgrade with new values
helm upgrade ai-services-operator ./helm-charts/ai-services-operator \
  --namespace ibm-ai-services \
  --values new-values.yaml

# Upgrade with inline overrides
helm upgrade ai-services-operator ./helm-charts/ai-services-operator \
  --namespace ibm-ai-services \
  --reuse-values \
  --set image.tag=26.0.1
```

### Verify Upgrade

```bash
# Check release history
helm history ai-services-operator -n ibm-ai-services

# Check deployment status
kubectl rollout status deployment/ibm-ccx-ai-services-operator -n ibm-ai-services

# Verify new version
kubectl get deployment ibm-ccx-ai-services-operator -n ibm-ai-services \
  -o jsonpath='{.spec.template.spec.containers[0].image}'
```

### Rollback if Needed

```bash
# Rollback to previous version
helm rollback ai-services-operator -n ibm-ai-services

# Rollback to specific revision
helm rollback ai-services-operator 2 -n ibm-ai-services
```

## 🗑️ Uninstallation

### Standard Uninstall

```bash
# Uninstall the chart
helm uninstall ai-services-operator -n ibm-ai-services
```

**Note:** This will NOT delete:
- The namespace
- Image pull secrets
- CCXAIServices custom resources
- CRD (to prevent data loss)

### Complete Cleanup

To completely remove everything:

```bash
# 1. Delete all CCXAIServices resources first
kubectl delete ccxaiservices --all -n ibm-ai-services

# 2. Wait for resources to be cleaned up
kubectl get pods -n ibm-ai-services -w

# 3. Uninstall the chart
helm uninstall ai-services-operator -n ibm-ai-services

# 4. Delete CRD (WARNING: This deletes all CCXAIServices resources cluster-wide!)
kubectl delete crd ccxaiservices.ccxaiservices.operator.ibm.com

# 5. Delete namespace
kubectl delete namespace ibm-ai-services
```

## 🔧 Troubleshooting

### Operator Not Starting

**Symptoms:**
- Pod in `Pending`, `CrashLoopBackOff`, or `ImagePullBackOff` state

**Diagnosis:**
```bash
# Check pod status
kubectl describe pod -n ibm-ai-services -l control-plane=ibm-ccx-ai-services-operator

# Check events
kubectl get events -n ibm-ai-services --sort-by='.lastTimestamp' | tail -20

# Check logs
kubectl logs -n ibm-ai-services -l control-plane=ibm-ccx-ai-services-operator --previous
```

**Common Solutions:**

1. **Image Pull Errors:**
   ```bash
   # Verify secret exists
   kubectl get secret ibm-entitlement-key -n ibm-ai-services
   
   # Test image pull
   kubectl run test --image=icr.io/cpopen/ibm-ccx-ai-services-operator:26.0.0 \
     --image-pull-policy=Always -n ibm-ai-services --rm -it -- /bin/sh
   ```

2. **Insufficient Resources:**
   ```bash
   # Check node resources
   kubectl describe nodes | grep -A 5 "Allocated resources"
   ```

### AI Provider Connectivity Issues

**Problem: Cannot connect to watsonx.ai**

```bash
# Test connectivity from operator pod
kubectl exec -it <operator-pod> -n ibm-ai-services -- \
  curl -v https://us-south.ml.cloud.ibm.com

# Check network policies
kubectl get networkpolicies -n ibm-ai-services

# Check DNS resolution
kubectl exec -it <operator-pod> -n ibm-ai-services -- \
  nslookup us-south.ml.cloud.ibm.com
```

**Solution:**
```yaml
# Ensure network policy allows egress
networkPolicyLabels:
  com.ibm.ccxai.networking/egress-allow-all: "true"
```

### Authentication Errors

**Problem: AI provider authentication fails**

```bash
# Check secret exists
kubectl get secret watsonx-api-key -n ibm-ai-services

# Verify secret content
kubectl get secret watsonx-api-key -n ibm-ai-services -o jsonpath='{.data.apikey}' | base64 -d

# Check operator logs for auth errors
kubectl logs -n ibm-ai-services -l control-plane=ibm-ccx-ai-services-operator | grep -i auth
```

### Performance Issues

**Operator consuming too much CPU/Memory:**
```bash
# Check resource usage
kubectl top pod -n ibm-ai-services -l control-plane=ibm-ccx-ai-services-operator

# Adjust resources
helm upgrade ai-services-operator ./helm-charts/ai-services-operator \
  --namespace ibm-ai-services \
  --reuse-values \
  --set operator.resources.limits.memory=256Mi
```

### CRD Issues

**Problem: CRD not found**
```bash
# Check if CRD exists
kubectl get crd ccxaiservices.ccxaiservices.operator.ibm.com

# If missing, reinstall
helm upgrade ai-services-operator ./helm-charts/ai-services-operator \
  --namespace ibm-ai-services \
  --reuse-values
```

## 🎓 Advanced Configuration

### Using Private Registry

**1. Create registry secret:**
```bash
kubectl create secret docker-registry my-registry-secret \
  --docker-server=my-registry.company.com \
  --docker-username=myuser \
  --docker-password=mypassword \
  --namespace ibm-ai-services
```

**2. Configure values:**
```yaml
image:
  repository: my-registry.company.com/ibm-ccx-ai-services-operator
  tag: 26.0.0

imagePullSecrets:
  - name: my-registry-secret
```

### Vault Integration for AI Credentials

**Enable Vault secret mounting:**
```yaml
vault:
  enabled: true
  secretsMountPath: /tmp/secrets
  certificatesMountPath: /tmp/certificates
  secrets:
    - name: ibm-ai-services-secret
      type: secret
    - name: watsonx-api-key
      type: secret
    - name: ibm-graphql-ssl-secret
      type: certificate
```

**Prerequisites:**
- Secrets Store CSI Driver installed
- Vault CSI Provider installed
- SecretProviderClass resources created

### High Availability Configuration

**Deploy multiple operator replicas:**
```yaml
replicaCount: 3

operator:
  resources:
    limits:
      cpu: 500m
      memory: 256Mi
    requests:
      cpu: 100m
      memory: 128Mi

# Add pod anti-affinity
affinity:
  podAntiAffinity:
    preferredDuringSchedulingIgnoredDuringExecution:
      - weight: 100
        podAffinityTerm:
          labelSelector:
            matchExpressions:
              - key: control-plane
                operator: In
                values:
                  - ibm-ccx-ai-services-operator
          topologyKey: kubernetes.io/hostname
```

### Custom Monitoring

**Add Prometheus annotations:**
```yaml
podAnnotations:
  prometheus.io/scrape: "true"
  prometheus.io/port: "8080"
  prometheus.io/path: "/metrics"
```

### Air-Gapped Deployment

**1. Mirror images:**
```bash
# Pull image
docker pull icr.io/cpopen/ibm-ccx-ai-services-operator:26.0.0

# Tag for private registry
docker tag icr.io/cpopen/ibm-ccx-ai-services-operator:26.0.0 \
  my-registry.company.com/ibm-ccx-ai-services-operator:26.0.0

# Push to private registry
docker push my-registry.company.com/ibm-ccx-ai-services-operator:26.0.0
```

**2. Configure chart:**
```yaml
image:
  repository: my-registry.company.com/ibm-ccx-ai-services-operator
  tag: 26.0.0
  pullPolicy: IfNotPresent

imagePullSecrets:
  - name: my-registry-secret
```

## 💼 Use Cases

### Use Case 1: Development with watsonx.ai SaaS

**Scenario:** Development environment using watsonx.ai cloud service for document analysis and content summarization.

**1. Install Operator:**
```bash
helm install ai-services-operator ./helm-charts/ai-services-operator \
  --namespace ibm-ai-services \
  --set operator.resources.limits.cpu=200m \
  --set operator.resources.limits.memory=128Mi
```

**2. Create Provider Secret:**
```bash
kubectl create secret generic ibm-providers-config-secret \
  --from-literal=WATSONXPROD_PROVIDER_TYPE=watsonx_saas \
  --from-literal=WATSONXPROD_PROVIDER_URL=https://us-south.ml.cloud.ibm.com \
  --from-literal=WATSONXPROD_API_KEY=<your-api-key> \
  --from-literal=WATSONXPROD_SPACE_ID=<your-space-id> \
  --from-literal=WATSONXPROD_ENABLED=true \
  --from-literal=WATSONXPROD_MODEL_0_MODEL=openai/gpt-oss-120b \
  --from-literal=WATSONXPROD_MODEL_0_DEFAULT=true \
  --from-literal=WATSONXPROD_MODEL_0_MAX_COMPLETION_TOKENS=2048 \
  --from-literal=WATSONXPROD_MODEL_0_TEMPERATURE=0.7 \
  --from-literal=WATSONXPROD_MODEL_0_CONTEXT_WINDOW_TOKEN_LIMIT=131072 \
  --namespace ibm-ai-services
```

**3. Deploy AI Services:**
```yaml
apiVersion: ccxaiservices.operator.ibm.com/v1
kind: CCXAIServices
metadata:
  name: dev-ai-services
  namespace: ibm-ai-services
spec:
  appVersion: 26.0.0
  license:
    accept: true
  
  shared_configuration:
    sc_deployment_context: "FNCM"
    sc_ccx_license_model: "CCx.Ess.AU"
    image_pull_secrets:
      - ibm-entitlement-key
    sc_image_repository: cp.icr.io
    root_ca_secret: ai-services-root-ca
    sc_deployment_profile_size: "small"
    storage_configuration:
      sc_slow_file_storage_classname: "ibmc-file-gold"
  
  reasoning_service_configuration:
    reasoning_service_secret_name: ibm-providers-config-secret
    replica_count: 1
```

**Use Case:** Document summarization, semantic search, content classification

### Use Case 2: Production with watsonx.ai and High Availability

**Scenario:** Production environment with HA configuration and autoscaling for enterprise content management.

**1. Install Operator with HA:**
```bash
helm install ai-services-operator ./helm-charts/ai-services-operator \
  --namespace ibm-ai-services \
  --set replicaCount=3 \
  --set operator.resources.limits.cpu=1 \
  --set operator.resources.limits.memory=256Mi \
  --set operator.resources.requests.cpu=100m \
  --set operator.resources.requests.memory=128Mi
```

**2. Deploy AI Services with Autoscaling:**
```yaml
apiVersion: ccxaiservices.operator.ibm.com/v1
kind: CCXAIServices
metadata:
  name: prod-ai-services
  namespace: ibm-ai-services
spec:
  appVersion: 26.0.0
  license:
    accept: true
  
  shared_configuration:
    sc_deployment_context: "FNCM"
    sc_ccx_license_model: "CCx.Ess.EP"
    image_pull_secrets:
      - ibm-entitlement-key
    sc_image_repository: cp.icr.io
    root_ca_secret: ai-services-root-ca
    sc_deployment_profile_size: "large"
    sc_redis_enable: true
    storage_configuration:
      sc_slow_file_storage_classname: "ibmc-file-gold"
      sc_block_storage_classname: "ibmc-block-gold"
  
  reasoning_service_configuration:
    reasoning_service_secret_name: ibm-providers-config-secret
    replica_count: 3
    auto_scaling:
      enabled: true
      max_replicas: 10
      min_replicas: 3
      target_cpu_average_utilization: 70
      target_memory_average_utilization: 80
    resources:
      requests:
        cpu: 1000m
        memory: 2Gi
      limits:
        cpu: 2000m
        memory: 4Gi
  
  core_mcp_server_configuration:
    replica_count: 3
    auto_scaling:
      enabled: true
      max_replicas: 5
      min_replicas: 3
      target_cpu_average_utilization: 70
```

**Use Case:** High-volume document processing, real-time content analysis, enterprise-scale AI operations

### Use Case 3: On-Premises with watsonx Lightweight Engine

**Scenario:** Air-gapped on-premises deployment with watsonx LWE and Vault integration for secure credential management.

**1. Install Operator with Vault:**
```bash
helm install ai-services-operator ./helm-charts/ai-services-operator \
  --namespace ibm-ai-services \
  --set vault.enabled=true \
  --set vault.secretsMountPath=/tmp/secrets \
  --set vault.secrets[0].name=ai-provider-creds \
  --set vault.secrets[0].type=secret
```

**2. Create Provider Secret for LWE:**
```bash
kubectl create secret generic ibm-providers-config-secret \
  --from-literal=WATSONXONPREM_PROVIDER_TYPE=watsonx_lwe \
  --from-literal=WATSONXONPREM_PROVIDER_URL=https://watsonx.company.local:9443 \
  --from-literal=WATSONXONPREM_API_KEY=<your-api-key> \
  --from-literal=WATSONXONPREM_USERNAME=<your-username> \
  --from-literal=WATSONXONPREM_VERSION=5.4 \
  --from-literal=WATSONXONPREM_INSTANCE_ID=openshift \
  --from-literal=WATSONXONPREM_ENABLED=true \
  --from-literal=WATSONXONPREM_MODEL_0_MODEL=openai/gpt-oss-120b \
  --from-literal=WATSONXONPREM_MODEL_0_DEFAULT=true \
  --namespace ibm-ai-services
```

**3. Deploy with Network Restrictions:**
```yaml
apiVersion: ccxaiservices.operator.ibm.com/v1
kind: CCXAIServices
metadata:
  name: onprem-ai-services
spec:
  shared_configuration:
    sc_deployment_context: "FNCM"
    sc_ccx_license_model: "CCx.PR"
    sc_vault_configuration:
      enable_external_secret_store: true
    sc_generate_sample_network_policies: true
    trusted_certificate_list:
      - watsonx-lwe-ca-cert
  
  reasoning_service_configuration:
    reasoning_service_secret_name: ibm-providers-config-secret
    replica_count: 2
```

**Use Case:** Secure on-premises AI, regulated industries, air-gapped environments

### Use Case 4: Multi-Provider with Azure AI Foundry

**Scenario:** Hybrid deployment using both watsonx.ai SaaS and Microsoft Azure AI Foundry for different workloads.

**1. Create Multi-Provider Secret:**
```bash
# Add watsonx provider
kubectl create secret generic ibm-providers-config-secret \
  --from-literal=WATSONXPROD_PROVIDER_TYPE=watsonx_saas \
  --from-literal=WATSONXPROD_PROVIDER_URL=https://us-south.ml.cloud.ibm.com \
  --from-literal=WATSONXPROD_API_KEY=<watsonx-api-key> \
  --from-literal=WATSONXPROD_SPACE_ID=<space-id> \
  --from-literal=WATSONXPROD_ENABLED=true \
  --from-literal=WATSONXPROD_MODEL_0_MODEL=openai/gpt-oss-120b \
  --from-literal=WATSONXPROD_MODEL_0_DEFAULT=true \
  --namespace ibm-ai-services

# Add Azure Foundry provider
kubectl create secret generic ibm-providers-config-secret \
  --from-literal=AZUREFOUNDRY_PROVIDER_TYPE=microsoft_foundry \
  --from-literal=AZUREFOUNDRY_PROVIDER_URL=https://ai.azure.com/api/v1 \
  --from-literal=AZUREFOUNDRY_API_KEY=<azure-api-key> \
  --from-literal=AZUREFOUNDRY_ENABLED=true \
  --from-literal=AZUREFOUNDRY_MODEL_0_MODEL=gpt-5.4 \
  --from-literal=AZUREFOUNDRY_MODEL_0_DEFAULT=false \
  --from-literal=AZUREFOUNDRY_MODEL_0_API_VERSION=2024-12-01-preview \
  --namespace ibm-ai-services \
  --dry-run=client -o yaml | kubectl apply -f -
```

**2. Deploy AI Services:**
```yaml
apiVersion: ccxaiservices.operator.ibm.com/v1
kind: CCXAIServices
metadata:
  name: multi-provider-ai-services
spec:
  shared_configuration:
    sc_ccx_license_model: "CCx.EE"
    sc_deployment_profile_size: "medium"
  
  reasoning_service_configuration:
    reasoning_service_secret_name: ibm-providers-config-secret
    replica_count: 2
```

**Use Case:** Provider redundancy, workload distribution, cost optimization across cloud providers

## 📚 Useful Helm Commands

### Chart Management

```bash
# Lint the chart
helm lint ./helm-charts/ai-services-operator

# Template rendering
helm template ai-services-operator ./helm-charts/ai-services-operator \
  --namespace ibm-ai-services \
  --debug

# Dry-run installation
helm install ai-services-operator ./helm-charts/ai-services-operator \
  --namespace ibm-ai-services \
  --dry-run --debug

# Show chart values
helm show values ./helm-charts/ai-services-operator

# Show chart README
helm show readme ./helm-charts/ai-services-operator
```

### Release Management

```bash
# List releases
helm list -n ibm-ai-services

# Get release status
helm status ai-services-operator -n ibm-ai-services

# Get release values
helm get values ai-services-operator -n ibm-ai-services

# Get release manifest
helm get manifest ai-services-operator -n ibm-ai-services

# Get release history
helm history ai-services-operator -n ibm-ai-services
```

### Debugging

```bash
# Render templates with values
helm template ai-services-operator ./helm-charts/ai-services-operator \
  --namespace ibm-ai-services \
  --values my-values.yaml \
  --debug > rendered-templates.yaml

# Show computed values
helm get values ai-services-operator -n ibm-ai-services --all
```

### Upgrade and Rollback

```bash
# Upgrade with new values
helm upgrade ai-services-operator ./helm-charts/ai-services-operator \
  --namespace ibm-ai-services \
  --values new-values.yaml

# Rollback to previous version
helm rollback ai-services-operator -n ibm-ai-services

# Rollback to specific revision
helm rollback ai-services-operator 2 -n ibm-ai-services
```

## 📞 Support

### Documentation

- **Product Documentation**: [IBM Content Cortex Documentation](https://www.ibm.com/docs/SSL4SY_26.0.0/com.ibm.p8.containers.doc/containers.html)
- **GitHub Repository**: [Content Cortex Containers](https://github.com/ibm-ecm/ibm-content-cortex-containers)
- **Chart Repository**: [fncm-prerequisites](https://github.ibm.com/ecm-container-service/fncm-prerequisites)

### Getting Help

- **IBM Support**: Open a case through [IBM Support Portal](https://www.ibm.com/mysupport)
- **Email**: support@ibm.com
- **Community**: [IBM ECM Community](https://community.ibm.com/community/user/automation/communities/community-home?CommunityKey=ecm)

### Reporting Issues

When reporting issues, please include:

1. **Chart version**: `helm list -n ibm-ai-services`
2. **Kubernetes version**: `kubectl version`
3. **Operator logs**: `kubectl logs -n ibm-ai-services -l control-plane=ibm-ccx-ai-services-operator`
4. **Pod description**: `kubectl describe pod -n ibm-ai-services -l control-plane=ibm-ccx-ai-services-operator`
5. **Events**: `kubectl get events -n ibm-ai-services --sort-by='.lastTimestamp'`
6. **Values used**: `helm get values ai-services-operator -n ibm-ai-services`
7. **AI provider connectivity**: Test results from operator pod

## 📄 License

Licensed Materials - Property of IBM

(C) Copyright IBM Corp. 2026. All Rights Reserved.

US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

---

**Chart Version**: 26.0.0 | **App Version**: 26.0.0 | **Last Updated**: 2026-06-18