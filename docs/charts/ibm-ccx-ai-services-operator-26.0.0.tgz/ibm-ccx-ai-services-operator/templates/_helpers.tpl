{{/*
Expand the name of the chart.
*/}}
{{- define "ibm-ccx-ai-services-operator.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "ibm-ccx-ai-services-operator.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "ibm-ccx-ai-services-operator.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "ibm-ccx-ai-services-operator.labels" -}}
helm.sh/chart: {{ include "ibm-ccx-ai-services-operator.chart" . }}
{{ include "ibm-ccx-ai-services-operator.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- range $key, $value := .Values.labels }}
{{ $key }}: {{ $value | quote }}
{{- end }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "ibm-ccx-ai-services-operator.selectorLabels" -}}
app.kubernetes.io/name: {{ include "ibm-ccx-ai-services-operator.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Pod labels - includes selector labels plus custom labels
*/}}
{{- define "ibm-ccx-ai-services-operator.podLabels" -}}
{{ include "ibm-ccx-ai-services-operator.selectorLabels" . }}
control-plane: {{ .Values.operator.name }}
{{- range $key, $value := .Values.labels }}
{{ $key }}: {{ $value | quote }}
{{- end }}
{{- range $key, $value := .Values.networkPolicyLabels }}
{{ $key }}: {{ $value | quote }}
{{- end }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "ibm-ccx-ai-services-operator.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "ibm-ccx-ai-services-operator.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Return the proper image name. Use repository:tag when tag is provided;
otherwise fall back to repository@digest.
*/}}
{{- define "ibm-ccx-ai-services-operator.image" -}}
{{- if .Values.image.tag }}
{{- printf "%s:%s" .Values.image.repository .Values.image.tag }}
{{- else }}
{{- printf "%s@%s" .Values.image.repository .Values.image.digest }}
{{- end }}
{{- end }}

{{/*
Return the proper image pull policy
*/}}
{{- define "ibm-ccx-ai-services-operator.imagePullPolicy" -}}
{{- .Values.image.pullPolicy }}
{{- end }}