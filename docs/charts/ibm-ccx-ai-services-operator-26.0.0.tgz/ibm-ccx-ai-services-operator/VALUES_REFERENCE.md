# IBM Content Cortex AI Services Operator - Values Reference Guide

[![Chart Version](https://img.shields.io/badge/Chart-26.0.0-green.svg)](./Chart.yaml)
[![Helm Version](https://img.shields.io/badge/Helm-v4.0+-blue.svg)](https://helm.sh)

## 📋 Table of Contents

- [Overview](#overview)
- [Quick Reference](#quick-reference)
- [Complete Values Reference](#complete-values-reference)
- [Configuration Examples](#configuration-examples)
- [Environment-Specific Configurations](#environment-specific-configurations)
- [Advanced Configurations](#advanced-configurations)
- [Validation](#validation)

## 🎯 Overview

This document provides a comprehensive reference for all configuration values available in the IBM Content Cortex AI Services Operator Helm chart. Each parameter is documented with its purpose, type, default value, and usage examples.

## 🚀 Quick Reference

### Essential Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `image.repository` | string | `icr.io/cpopen/ibm-ccx-ai-services-operator` | Operator image repository |
| `image.tag` | string | `""` | Image tag (overrides digest) |
| `image.digest` | string | `sha256:86b0110a...` | Image digest (used when tag is empty) |
| `replicaCount` | integer | `1` | Number of operator replicas |
| `operator.name` | string | `ibm-ccx-ai-services-operator` | Operator deployment name |
| `operator.args` | array | `[--leader-elect, --health-probe-bind-address=:8081]` | Operator arguments |

### Resource Defaults

| Component | CPU Request | CPU Limit | Memory Request | Memory Limit |
|-----------|-------------|-----------|----------------|--------------|
| Operator | 10m | 500m | 64Mi | 128Mi |

**Note:** AI Services Operator is lightweight compared to Content Operator due to its focused scope.

## 📖 Complete Values Reference

### Name Overrides

```yaml
# Override the chart name
# Type: string
# Default: ""
# Usage: Customize the chart name in resource names
nameOverride: ""

# Override the full name (release-name + chart-name)
# Type: string
# Default: ""
# Usage: Completely customize the full resource name
fullnameOverride: ""
```

**Examples:**
```yaml
# Use custom chart name
nameOverride: "ai-services-op"

# Use completely custom name
fullnameOverride: "my-ai-services-operator"
```

---

### Image Configuration

```yaml
image:
  # Image repository for the Content Cortex AI Services operator
  # Type: string
  # Default: icr.io/cpopen/ibm-ccx-ai-services-operator
  # Required: Yes
  repository: icr.io/cpopen/ibm-ccx-ai-services-operator
  
  # Default image digest used when tag is not provided
  # Type: string
  # Default: sha256:ce4f95b0c0a88103b05a867b63873249cd4fc82bce097d0a4cef1af57e2600a8
  # Required: No (used as fallback)
  # Note: Provides immutable image reference
  digest: "sha256:ce4f95b0c0a88103b05a867b63873249cd4fc82bce097d0a4cef1af57e2600a8"
  
  # Optional image tag override
  # Type: string
  # Default: ""
  # Required: No
  # Note: When set, uses repository:tag instead of repository@digest
  tag: ""
  
  # Image pull policy
  # Type: string
  # Default: IfNotPresent
  # Options: Always, IfNotPresent, Never
  # Required: Yes
  pullPolicy: IfNotPresent
```

**Image Reference Behavior:**
- If `tag` is set: Uses `repository:tag`
- If `tag` is empty: Uses `repository@digest`

**Examples:**
```yaml
# Use specific tag (flexible)
image:
  tag: "26.0.0"

# Use digest (immutable, recommended for production)
image:
  tag: ""
  digest: "sha256:86b0110a..."

# Use private registry
image:
  repository: my-registry.company.com/ibm-ccx-ai-services-operator
  tag: "26.0.0"

# Always pull latest
image:
  tag: "latest"
  pullPolicy: Always
```

---

### Image Pull Secrets

```yaml
# Image pull secrets for accessing the container registry
# Type: array of objects
# Default: [{name: ibm-entitlement-key}]
# Required: Yes (secrets must exist in namespace)
# Note: Secrets must be created before chart installation
imagePullSecrets:
  - name: ibm-entitlement-key
```

**Examples:**
```yaml
# Single secret (default)
imagePullSecrets:
  - name: ibm-entitlement-key

# Multiple secrets
imagePullSecrets:
  - name: ibm-entitlement-key
  - name: my-registry-secret

# Private registry secret
imagePullSecrets:
  - name: my-private-registry
```

---

### Replica Count

```yaml
# Number of operator replicas
# Type: integer
# Default: 1
# Range: 1-5 (typically 1 for operators)
# Required: Yes
# Note: Multiple replicas provide high availability with leader election
replicaCount: 1
```

**Examples:**
```yaml
# Single replica (default)
replicaCount: 1

# High availability (3 replicas with leader election)
replicaCount: 3

# Maximum recommended
replicaCount: 5
```

---

### Service Account

```yaml
serviceAccount:
  # Specifies whether a service account should be created
  # Type: boolean
  # Default: true
  # Required: Yes
  create: true
  
  # The name of the service account to use
  # Type: string
  # Default: ibm-ccx-ai-services-operator-sa
  # Required: Yes (if create is true)
  # Note: If not set and create is true, name is generated from fullname template
  name: "ibm-ccx-ai-services-operator-sa"
```

**Examples:**
```yaml
# Create with default name
serviceAccount:
  create: true
  name: "ibm-ccx-ai-services-operator-sa"

# Use existing service account
serviceAccount:
  create: false
  name: "existing-sa"

# Auto-generate name
serviceAccount:
  create: true
  name: ""
```

---

### RBAC Configuration

```yaml
rbac:
  # Specifies whether RBAC resources should be created
  # Type: boolean
  # Default: true
  # Required: Yes
  # Note: Creates Role and RoleBinding (namespace-scoped)
  create: true
```

**Examples:**
```yaml
# Create RBAC resources (default)
rbac:
  create: true

# Skip RBAC creation (use existing)
rbac:
  create: false
```

---

### Operator Configuration

```yaml
operator:
  # Operator name
  # Type: string
  # Default: ibm-ccx-ai-services-operator
  # Required: Yes
  name: ibm-ccx-ai-services-operator
  
  # Resource limits and requests for the operator container
  resources:
    limits:
      # CPU limit
      # Type: string
      # Default: 500m
      # Format: Kubernetes CPU units (e.g., "500m", "1", "2")
      # Note: AI Services Operator is lightweight
      cpu: 500m
      
      # Memory limit
      # Type: string
      # Default: 128Mi
      # Format: Kubernetes memory units (e.g., "128Mi", "256Mi", "512Mi")
      memory: 128Mi
    
    requests:
      # CPU request
      # Type: string
      # Default: 10m
      # Format: Kubernetes CPU units
      # Note: Very low baseline requirement
      cpu: 10m
      
      # Memory request
      # Type: string
      # Default: 64Mi
      # Format: Kubernetes memory units
      memory: 64Mi
  
  # Security context for the operator pod
  securityContext:
    # Run as non-root user
    # Type: boolean
    # Default: true
    # Required: Yes (security best practice)
    runAsNonRoot: true
    
    # User ID to run the container as
    # Type: integer
    # Default: Not set (uses image default)
    # Optional: Uncomment to specify
    # runAsUser: 1001
    
    # File system group ID
    # Type: integer
    # Default: Not set
    # Optional: Uncomment to specify
    # fsGroup: 0
  
  # Security context for the operator container
  containerSecurityContext:
    # Allow privilege escalation
    # Type: boolean
    # Default: false
    # Required: Yes (security best practice)
    allowPrivilegeEscalation: false
    
    # Run as privileged container
    # Type: boolean
    # Default: false
    # Required: Yes (security best practice)
    privileged: false
    
    # Read-only root filesystem
    # Type: boolean
    # Default: true
    # Required: Yes (security best practice)
    readOnlyRootFilesystem: true
    
    # Capabilities to drop
    # Type: object
    # Default: Drop ALL capabilities
    # Required: Yes (security best practice)
    capabilities:
      drop:
        - ALL
    
    # Seccomp profile (OpenShift 4.12+)
    # Type: object
    # Default: Not set (commented out)
    # Optional: Uncomment for enhanced security
    # seccompProfile:
    #   type: RuntimeDefault
  
  # Command line arguments for the operator
  # Type: array of strings
  # Default: ['--leader-elect', '--health-probe-bind-address=:8081']
  # Note: Controls operator behavior and health check port
  args:
    - --leader-elect
    - --health-probe-bind-address=:8081
```

**Resource Configuration Examples:**

```yaml
# Development environment (minimal resources)
operator:
  resources:
    limits:
      cpu: 200m
      memory: 128Mi
    requests:
      cpu: 10m
      memory: 64Mi

# Production environment (recommended)
operator:
  resources:
    limits:
      cpu: "1"
      memory: 256Mi
    requests:
      cpu: 100m
      memory: 128Mi

# High-load environment
operator:
  resources:
    limits:
      cpu: "2"
      memory: 512Mi
    requests:
      cpu: 500m
      memory: 256Mi
```

**Security Context Examples:**

```yaml
# Enhanced security (OpenShift 4.12+)
operator:
  securityContext:
    runAsNonRoot: true
    runAsUser: 1001
  
  containerSecurityContext:
    allowPrivilegeEscalation: false
    privileged: false
    readOnlyRootFilesystem: true
    capabilities:
      drop:
        - ALL
    seccompProfile:
      type: RuntimeDefault

# Minimal security (not recommended for production)
operator:
  securityContext:
    runAsNonRoot: true
  
  containerSecurityContext:
    allowPrivilegeEscalation: false
    privileged: false
    readOnlyRootFilesystem: true
    capabilities:
      drop:
        - ALL
```

**Operator Arguments Examples:**

```yaml
# Default arguments
operator:
  args:
    - --leader-elect
    - --health-probe-bind-address=:8081

# With metrics endpoint
operator:
  args:
    - --leader-elect
    - --health-probe-bind-address=:8081
    - --metrics-bind-address=:8080

# With custom log level
operator:
  args:
    - --leader-elect
    - --health-probe-bind-address=:8081
    - --zap-log-level=debug
```

---

### Health Probes

```yaml
# Liveness probe configuration
# Type: object
# Purpose: Determines if container needs to be restarted
# Note: Uses port 8081 (configured in operator.args)
livenessProbe:
  httpGet:
    path: /healthz
    port: 8081
  initialDelaySeconds: 15  # Wait before first probe
  periodSeconds: 20        # Probe frequency
  timeoutSeconds: 5        # Probe timeout
  successThreshold: 1      # Consecutive successes needed
  failureThreshold: 3      # Consecutive failures before restart

# Readiness probe configuration
# Type: object
# Purpose: Determines if container is ready to serve traffic
# Note: Uses port 8081 (configured in operator.args)
readinessProbe:
  httpGet:
    path: /readyz
    port: 8081
  initialDelaySeconds: 5   # Wait before first probe
  periodSeconds: 10        # Probe frequency
  timeoutSeconds: 5        # Probe timeout
  successThreshold: 1      # Consecutive successes needed
  failureThreshold: 3      # Consecutive failures before marking unready
```

**Examples:**
```yaml
# Aggressive probing (faster failure detection)
livenessProbe:
  httpGet:
    path: /healthz
    port: 8081
  initialDelaySeconds: 10
  periodSeconds: 10
  timeoutSeconds: 3
  failureThreshold: 2

# Conservative probing (slower, more tolerant)
livenessProbe:
  httpGet:
    path: /healthz
    port: 8081
  initialDelaySeconds: 30
  periodSeconds: 30
  timeoutSeconds: 10
  failureThreshold: 5
```

---

### Node Affinity

```yaml
# Node affinity configuration
# Type: object
# Purpose: Controls which nodes the operator can run on
# Note: AI Services Operator currently supports amd64 only
affinity:
  nodeAffinity:
    # Required node affinity
    # Operator will ONLY run on nodes matching these expressions
    requiredDuringSchedulingIgnoredDuringExecution:
      nodeSelectorTerms:
        - matchExpressions:
            - key: kubernetes.io/arch
              operator: In
              values:
                - amd64
    
    # Preferred node affinity
    # Operator PREFERS these nodes but can run elsewhere
    preferredDuringSchedulingIgnoredDuringExecution:
      - weight: 3
        preference:
          matchExpressions:
            - key: kubernetes.io/arch
              operator: In
              values:
                - amd64
```

**Examples:**
```yaml
# AMD64 only (default)
affinity:
  nodeAffinity:
    requiredDuringSchedulingIgnoredDuringExecution:
      nodeSelectorTerms:
        - matchExpressions:
            - key: kubernetes.io/arch
              operator: In
              values:
                - amd64

# Prefer SSD nodes
affinity:
  nodeAffinity:
    preferredDuringSchedulingIgnoredDuringExecution:
      - weight: 100
        preference:
          matchExpressions:
            - key: disktype
              operator: In
              values:
                - ssd

# Pod anti-affinity (spread across nodes)
affinity:
  podAntiAffinity:
    requiredDuringSchedulingIgnoredDuringExecution:
      - labelSelector:
          matchExpressions:
            - key: control-plane
              operator: In
              values:
                - ibm-ccx-ai-services-operator
        topologyKey: kubernetes.io/hostname
```

---

### Node Selector

```yaml
# Additional node selectors
# Type: object (key-value pairs)
# Default: {}
# Purpose: Simple node selection based on labels
nodeSelector: {}
```

**Examples:**
```yaml
# Select nodes with specific labels
nodeSelector:
  disktype: ssd
  environment: production

# Select nodes in specific zone
nodeSelector:
  topology.kubernetes.io/zone: us-east-1a

# Select dedicated nodes
nodeSelector:
  dedicated: ai-services
```

---

### Tolerations

```yaml
# Tolerations for pod scheduling
# Type: array of objects
# Default: []
# Purpose: Allow pods to schedule on tainted nodes
tolerations: []
```

**Examples:**
```yaml
# Tolerate NoSchedule taint
tolerations:
  - key: "dedicated"
    operator: "Equal"
    value: "ai-services"
    effect: "NoSchedule"

# Tolerate any taint on key
tolerations:
  - key: "special"
    operator: "Exists"
    effect: "NoSchedule"

# Tolerate NoExecute (allows running on draining nodes)
tolerations:
  - key: "node.kubernetes.io/not-ready"
    operator: "Exists"
    effect: "NoExecute"
    tolerationSeconds: 300
```

---

### Pod Annotations

```yaml
# Pod annotations
# Type: object (key-value pairs)
# Purpose: Add metadata to operator pods
podAnnotations:
  # Default container for kubectl commands
  kubectl.kubernetes.io/default-container: "manager"
  
  # IBM product identification
  productID: "9c2d4f167cdb411fa3b1d787eb3c7c34"
  productName: "IBM Content Cortex Essentials"
  productMetric: "AUTHORIZED_USER"
  productChargedContainers: ""
  productVersion: "26.0.0"
```

**Examples:**
```yaml
# Add custom annotations
podAnnotations:
  kubectl.kubernetes.io/default-container: "manager"
  productID: "9c2d4f167cdb411fa3b1d787eb3c7c34"
  productName: "IBM Content Cortex Essentials"
  productVersion: "26.0.0"
  custom-annotation: "custom-value"
  ai-provider: "watsonx"
  monitoring: "enabled"

# Prometheus monitoring
podAnnotations:
  kubectl.kubernetes.io/default-container: "manager"
  prometheus.io/scrape: "true"
  prometheus.io/port: "8080"
  prometheus.io/path: "/metrics"

# Vault injection
podAnnotations:
  kubectl.kubernetes.io/default-container: "manager"
  vault.hashicorp.com/agent-inject: "true"
  vault.hashicorp.com/role: "ai-services-operator"
```

---

### Descriptor Labels

```yaml
# Descriptor-aligned labels used by the deployment manifest defaults
# Type: object (key-value pairs)
# Purpose: Labels that align with operator descriptor files
# Note: These are specific to AI Services Operator
descriptorLabels:
  instance: ibm-ccx-ai-services
  managedBy: ibm-ccx-ai-services
  name: ibm-ccx-ai-services
```

**Examples:**
```yaml
# Default descriptor labels
descriptorLabels:
  instance: ibm-ccx-ai-services
  managedBy: ibm-ccx-ai-services
  name: ibm-ccx-ai-services

# Custom descriptor labels
descriptorLabels:
  instance: my-ai-services
  managedBy: my-ai-services
  name: my-ai-services
  environment: production
```

---

### Common Labels

```yaml
# Common labels applied to chart-managed resources
# Type: object (key-value pairs)
# Default: {control-plane: ibm-ccx-ai-services-operator, release: "26.0.0"}
# Note: app.kubernetes.io/managed-by is automatically set to "Helm"
labels:
  control-plane: ibm-ccx-ai-services-operator
  release: "26.0.0"
```

**Examples:**
```yaml
# Add custom labels
labels:
  control-plane: ibm-ccx-ai-services-operator
  release: "26.0.0"
  environment: "production"
  team: "ai-platform"
  cost-center: "engineering"

# Compliance labels
labels:
  control-plane: ibm-ccx-ai-services-operator
  release: "26.0.0"
  compliance: "pci-dss"
  data-classification: "confidential"
```

---

### Network Policy Labels

```yaml
# Network policy labels for the operator pod
# Type: object (key-value pairs)
# Purpose: Control network egress using network policies
# Note: AI Services needs egress to AI providers (watsonx.ai, Azure OpenAI, etc.)
networkPolicyLabels:
  # Allow all egress (required for AI provider access)
  com.ibm.ccxai.networking/egress-allow-all: "true"
  
  # Allow egress to Kubernetes services
  com.ibm.ccxai.networking/egress-allow-k8s-services: "true"
  
  # Allow egress to same namespace
  com.ibm.ccxai.networking/egress-allow-same-namespace: "true"
  
  # Deny all egress by default (overridden by allow-all)
  com.ibm.ccxai.networking/egress-deny-all: "true"
```

**Examples:**
```yaml
# Permissive network policy (default - required for AI providers)
networkPolicyLabels:
  com.ibm.ccxai.networking/egress-allow-all: "true"
  com.ibm.ccxai.networking/egress-allow-k8s-services: "true"
  com.ibm.ccxai.networking/egress-allow-same-namespace: "true"

# Strict network policy (custom - requires specific egress rules)
networkPolicyLabels:
  com.ibm.ccxai.networking/egress-deny-all: "true"
  com.ibm.ccxai.networking/egress-allow-same-namespace: "true"
  com.ibm.ccxai.networking/egress-allow-k8s-services: "true"
  custom.company.com/egress-allow-watsonx: "true"
  custom.company.com/egress-allow-azure-openai: "true"

# Development network policy (fully permissive)
networkPolicyLabels:
  com.ibm.ccxai.networking/egress-allow-all: "true"
```

---

### Vault Integration

```yaml
# Vault Secret Management Configuration
# Type: object
# Purpose: Mount secrets from HashiCorp Vault using Secrets Store CSI Driver
vault:
  # Enable Vault secret mounting
  # Type: boolean
  # Default: false
  # Required: No
  # Prerequisites: Secrets Store CSI Driver and Vault CSI Provider installed
  enabled: false
  
  # Base mount path for credential secrets
  # Type: string
  # Default: /tmp/secrets
  # Purpose: Where credential secrets (API keys, passwords) are mounted
  secretsMountPath: /tmp/secrets
  
  # Base mount path for certificate secrets
  # Type: string
  # Default: /tmp/certificates
  # Purpose: Where SSL/TLS certificates are mounted
  certificatesMountPath: /tmp/certificates
  
  # List of secret configurations
  # Type: array of objects
  # Default: []
  # Note: Each secret requires a corresponding SecretProviderClass resource
  secrets: []
  # Example configuration:
  # secrets:
  #   - name: ibm-ai-services-secret
  #     type: secret
  #   - name: ldap-bind-secret
  #     type: secret
  #   - name: ibm-graphql-ssl-secret
  #     type: certificate
```

**Examples:**
```yaml
# Enable Vault with AI provider credentials
vault:
  enabled: true
  secretsMountPath: /tmp/secrets
  certificatesMountPath: /tmp/certificates
  secrets:
    - name: watsonx-api-key
      type: secret
    - name: azure-openai-creds
      type: secret
    - name: aws-bedrock-creds
      type: secret
    - name: graphql-ssl-cert
      type: certificate

# Custom mount paths
vault:
  enabled: true
  secretsMountPath: /vault/secrets
  certificatesMountPath: /vault/certs
  secrets:
    - name: ai-provider-secrets
      type: secret
```

---

## 📝 Configuration Examples

### Minimal Configuration

```yaml
# Minimal viable configuration
image:
  tag: "26.0.0"

imagePullSecrets:
  - name: ibm-entitlement-key
```

### Development Environment

```yaml
# Development configuration
image:
  tag: "26.0.0"
  pullPolicy: Always

replicaCount: 1

operator:
  resources:
    limits:
      cpu: 200m
      memory: 128Mi
    requests:
      cpu: 10m
      memory: 64Mi

networkPolicyLabels:
  com.ibm.ccxai.networking/egress-allow-all: "true"
```

### Production Environment

```yaml
# Production configuration
image:
  digest: "sha256:86b0110a6cb6926373ee4aa23ee25002acaf5e596ceaf8c4941fe171b11b476c"
  pullPolicy: IfNotPresent

replicaCount: 3

operator:
  resources:
    limits:
      cpu: "1"
      memory: 256Mi
    requests:
      cpu: 100m
      memory: 128Mi
  
  securityContext:
    runAsNonRoot: true
    runAsUser: 1001
  
  containerSecurityContext:
    allowPrivilegeEscalation: false
    privileged: false
    readOnlyRootFilesystem: true
    capabilities:
      drop:
        - ALL
    seccompProfile:
      type: RuntimeDefault

affinity:
  podAntiAffinity:
    requiredDuringSchedulingIgnoredDuringExecution:
      - labelSelector:
          matchExpressions:
            - key: control-plane
              operator: In
              values:
                - ibm-ccx-ai-services-operator
        topologyKey: kubernetes.io/hostname

networkPolicyLabels:
  com.ibm.ccxai.networking/egress-allow-all: "true"
  com.ibm.ccxai.networking/egress-allow-k8s-services: "true"
  com.ibm.ccxai.networking/egress-allow-same-namespace: "true"

podAnnotations:
  kubectl.kubernetes.io/default-container: "manager"
  productID: "9c2d4f167cdb411fa3b1d787eb3c7c34"
  productName: "IBM Content Cortex Essentials"
  productVersion: "26.0.0"
  ai-provider: "watsonx"
  monitoring: "enabled"
```

### High Availability Configuration

```yaml
# High availability configuration
image:
  digest: "sha256:86b0110a6cb6926373ee4aa23ee25002acaf5e596ceaf8c4941fe171b11b476c"

replicaCount: 5

operator:
  resources:
    limits:
      cpu: "1"
      memory: 256Mi
    requests:
      cpu: 100m
      memory: 128Mi
  
  args:
    - --leader-elect
    - --health-probe-bind-address=:8081
    - --metrics-bind-address=:8080

affinity:
  podAntiAffinity:
    requiredDuringSchedulingIgnoredDuringExecution:
      - labelSelector:
          matchExpressions:
            - key: control-plane
              operator: In
              values:
                - ibm-ccx-ai-services-operator
        topologyKey: kubernetes.io/hostname
  
  nodeAffinity:
    preferredDuringSchedulingIgnoredDuringExecution:
      - weight: 100
        preference:
          matchExpressions:
            - key: disktype
              operator: In
              values:
                - ssd

tolerations:
  - key: "dedicated"
    operator: "Equal"
    value: "ai-services"
    effect: "NoSchedule"
```

### Private Registry Configuration

```yaml
# Private registry configuration
image:
  repository: my-registry.company.com/ibm-ccx-ai-services-operator
  tag: "26.0.0"
  pullPolicy: IfNotPresent

imagePullSecrets:
  - name: my-registry-secret
```

### Vault Integration Configuration

```yaml
# Vault integration for AI provider credentials
image:
  tag: "26.0.0"

vault:
  enabled: true
  secretsMountPath: /tmp/secrets
  certificatesMountPath: /tmp/certificates
  secrets:
    - name: watsonx-api-key
      type: secret
    - name: azure-openai-creds
      type: secret
    - name: aws-bedrock-creds
      type: secret
    - name: graphql-ssl-cert
      type: certificate

networkPolicyLabels:
  com.ibm.ccxai.networking/egress-allow-all: "true"
```

### Multi-Provider AI Configuration

```yaml
# Configuration for multiple AI providers
image:
  tag: "26.0.0"

replicaCount: 3

operator:
  resources:
    limits:
      cpu: "1"
      memory: 256Mi
    requests:
      cpu: 100m
      memory: 128Mi

vault:
  enabled: true
  secrets:
    - name: watsonx-api-key
      type: secret
    - name: azure-openai-creds
      type: secret
    - name: aws-bedrock-creds
      type: secret

podAnnotations:
  kubectl.kubernetes.io/default-container: "manager"
  ai-providers: "watsonx,azure-openai,aws-bedrock"
  failover-enabled: "true"

networkPolicyLabels:
  com.ibm.ccxai.networking/egress-allow-all: "true"
```

## 🔍 Validation

### Validate Values File

```bash
# Lint the chart with custom values
helm lint ./helm-charts/ai-services-operator \
  --values my-values.yaml

# Dry-run installation
helm install ai-services-operator ./helm-charts/ai-services-operator \
  --namespace ibm-ai-services \
  --values my-values.yaml \
  --dry-run --debug

# Template rendering
helm template ai-services-operator ./helm-charts/ai-services-operator \
  --namespace ibm-ai-services \
  --values my-values.yaml \
  --debug
```

### Common Validation Errors

**Error: Invalid CPU format**
```yaml
# ❌ Wrong
operator:
  resources:
    limits:
      cpu: 500  # Missing quotes and unit

# ✓ Correct
operator:
  resources:
    limits:
      cpu: 500m
```

**Error: Invalid memory format**
```yaml
# ❌ Wrong
operator:
  resources:
    limits:
      memory: 128MB  # Wrong unit

# ✓ Correct
operator:
  resources:
    limits:
      memory: 128Mi
```

**Error: Invalid health probe port**
```yaml
# ❌ Wrong - port mismatch
operator:
  args:
    - --health-probe-bind-address=:8081

livenessProbe:
  httpGet:
    port: 8080  # Wrong port

# ✓ Correct - ports match
operator:
  args:
    - --health-probe-bind-address=:8081

livenessProbe:
  httpGet:
    port: 8081
```

## 📞 Support

For questions or issues with values configuration:

- **Documentation**: [Chart README](./README.md)
- **Schema**: [values.schema.json](./values.schema.json)
- **Examples**: See [Configuration Examples](#configuration-examples)
- **IBM Support**: [IBM Support Portal](https://www.ibm.com/mysupport)

---

**Chart Version**: 26.0.0 | **Last Updated**: 2026-06-07