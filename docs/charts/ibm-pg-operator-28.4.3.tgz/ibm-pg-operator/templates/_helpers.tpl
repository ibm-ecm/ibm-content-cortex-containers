{{/*
Expand the name of the chart.
*/}}
{{- define "ibm-pg-operator.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "ibm-pg-operator.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "ibm-pg-operator.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "ibm-pg-operator.labels" -}}
helm.sh/chart: {{ include "ibm-pg-operator.chart" . }}
{{ include "ibm-pg-operator.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- range $key, $value := .Values.labels }}
{{ $key }}: {{ $value | quote }}
{{- end }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "ibm-pg-operator.selectorLabels" -}}
app.kubernetes.io/name: {{ include "ibm-pg-operator.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
icpd support labels (applied to all resources)
*/}}
{{- define "ibm-pg-operator.icpdLabels" -}}
component-id: {{ .Chart.Name | quote }}
icpdsupport/addOnId: ibm-pg-operator
icpdsupport/app: database
icpdsupport/module: ibm-pg-operator
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "ibm-pg-operator.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default "ibm-pg-operator" .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Return the full operator image reference: registry/repo/image@digest
*/}}
{{- define "ibm-pg-operator.image" -}}
{{- printf "%s/%s@%s" (default .Values.global.imagePullPrefix .Values.ibmPgOperator.devImagePullPrefix) .Values.ibmPgOperator.operatorImageName .Values.ibmPgOperator.operatorImageDigest }}
{{- end }}

{{/*
Build a list of all watched namespaces (operator + instance + tethered), deduplicated.
*/}}
{{- define "ibm-pg-operator.watchNamespaces" -}}
{{- $ns := .Values.global.tetheredNamespaces | default list -}}
{{- if .Values.global.instanceNamespace -}}
  {{- $ns = append $ns .Values.global.instanceNamespace -}}
{{- end -}}
{{- $ns = prepend $ns .Values.global.operatorNamespace -}}
{{- uniq $ns | toJson }}
{{- end }}
