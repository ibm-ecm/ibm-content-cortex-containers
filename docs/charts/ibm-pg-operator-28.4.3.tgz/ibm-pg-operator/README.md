# ibm-pg-operator

Helm chart for deploying the **IBM Operator for PostgreSQL** — a Kubernetes operator that manages PostgreSQL clusters (operands) embedded in IBM Products.

| Field | Value |
|---|---|
| Chart Version | `28.4.3` |
| App Version | `28.4.3` |
| API Version | `v2` |
| Supported Architectures | `amd64`, `ppc64le`, `s390x` |
| License | Apache-2.0 |

---

## Overview

`ibm-pg-operator` deploys the operator manager (`ibm-pg-operator`) into a dedicated namespace and grants it RBAC permissions to reconcile PostgreSQL cluster resources (`pg.ibm.com` CRDs) across one or more watched namespaces.

**Resources created by this chart:**

| Resource | Kind | Purpose |
|---|---|---|
| `ibm-pg-operator` | `Deployment` | Operator manager container |
| `ibm-pg-operator` | `ServiceAccount` | Identity for the operator pod |
| `ibm-pg-operator` | `Role` | Namespace-scoped permissions (created in every watched namespace) |
| `ibm-pg-operator-rolebinding` | `RoleBinding` | Binds the Role to the ServiceAccount (every watched namespace) |
| `ibm-pg-operator` | `Service` | Exposes webhook and metrics ports |
| `ibm-pg-operator-config` | `ConfigMap` | Operator runtime configuration |
| `ibm-pg-operand-images` | `ConfigMap` | Operand image references |
| `ibm-pg-operator` | `ImageCatalog` | Catalog of available PostgreSQL images |

---

## Prerequisites

- Kubernetes 1.25+ or OpenShift 4.12+
- Helm 3.10+
- The `pg.ibm.com` CRDs must be installed before deploying the operator
- An IBM Entitlement Key image pull secret in the operator namespace:

```bash
kubectl create secret docker-registry ibm-entitlement-key \
  --docker-server=icr.io \
  --docker-username=iamapikey \
  --docker-password=<YOUR_IBM_ENTITLEMENT_KEY> \
  -n ibm-pg-system
```

---

## Installation

### Single-namespace (operator and instances share a namespace)

```bash
helm install ibm-pg-operator ./ibm-pg-operator \
  --namespace ibm-pg-system \
  --create-namespace \
  --set global.operatorNamespace=ibm-pg-system \
  --set global.instanceNamespace=ibm-pg-system \
  --set global.imagePullSecret=ibm-entitlement-key
```

### Multi-namespace (operator watches additional namespaces)

```bash
helm install ibm-pg-operator ./ibm-pg-operator \
  --namespace ibm-pg-system \
  --create-namespace \
  --set global.operatorNamespace=ibm-pg-system \
  --set global.instanceNamespace=app-namespace-1 \
  --set global.tetheredNamespaces[0]=app-namespace-2 \
  --set global.tetheredNamespaces[1]=app-namespace-3
```

A `Role` and `RoleBinding` are created in every watched namespace — the union of `operatorNamespace`, `instanceNamespace`, and `tetheredNamespaces`, deduplicated.

### Upgrade

```bash
helm upgrade ibm-pg-operator ./ibm-pg-operator \
  --namespace ibm-pg-system \
  -f my-values.yaml
```

### Uninstall

```bash
helm uninstall ibm-pg-operator --namespace ibm-pg-system
```

---

## Post-Installation

### 1. Verify Operator Status

```bash
kubectl get deployment ibm-pg-operator -n ibm-pg-system
kubectl get pods -n ibm-pg-system -l control-plane=ibm-pg-operator
```

### 2. Generate and Apply the PostgreSQL Cluster CR

> **Recommended**: Use the IBM Content Cortex prerequisites script to generate the Custom Resource and all supporting artifacts automatically. The script handles property collection, secret generation, and CR templating for you — eliminating the need to create any artifacts manually.

From the `scripts/` directory:

```bash
# Step 1 — Gather deployment configuration interactively
python3 prerequisites.py gather

# Step 2 — Generate all deployment artifacts (CR YAML, Kubernetes secrets, SQL scripts)
python3 prerequisites.py generate

# Step 3 — Validate external dependencies (certificates, databases, LDAP/IDP)
python3 prerequisites.py validate
```

Generated artifacts are written to `scripts/generatedFiles/<namespace>/`. Apply the generated PostgreSQL Cluster CR:

```bash
kubectl apply -f scripts/generatedFiles/<namespace>/ibm_pg_cr.yaml -n ibm-pg-system
```

If you need to deploy without the prerequisites script, you can apply a reference CR directly from the `descriptors/` directory.

### 3. Monitor Deployment Progress

```bash
kubectl get clusters -n ibm-pg-system
kubectl get pods -n ibm-pg-system -w
kubectl get events -n ibm-pg-system --sort-by='.lastTimestamp'
```

---

## Configuration

All parameters below can be overridden with `--set key=value` or a custom values file (`-f values.yaml`). See [`VALUES_REFERENCE.md`](VALUES_REFERENCE.md) for the full reference with extended examples.

### Essential parameters

| Parameter | Default | Description |
|---|---|---|
| `global.operatorNamespace` | `ibm-pg-system` | Namespace where the operator Deployment and RBAC resources are created |
| `global.instanceNamespace` | `ibm-pg-system` | Primary namespace the operator watches for PostgreSQL cluster operands |
| `global.tetheredNamespaces` | `[]` | Additional namespaces to watch |
| `global.imagePullPrefix` | `icr.io` | Container registry hostname prepended to all image references |
| `global.imagePullSecret` | `ibm-entitlement-key` | Name of the Kubernetes Secret used to pull images |
| `ibmPgOperator.operatorImageDigest` | `sha256:e4fece…` | SHA256 digest of the multi-arch operator image |

### Operator image

| Parameter | Default | Description |
|---|---|---|
| `ibmPgOperator.operatorImageName` | `cpopen/ibm-pg-operator` | Repository path for the operator image |
| `ibmPgOperator.operandImageRepository` | `cpopen/ibm-pg` | Repository path for PostgreSQL operand images |
| `ibmPgOperator.pullPolicy` | `Always` | Image pull policy (`Always`, `IfNotPresent`, `Never`) |
| `ibmPgOperator.devImagePullPrefix` | `""` | Override registry prefix for dev/testing; takes precedence over `global.imagePullPrefix` |

The resolved operator image is: `<imagePullPrefix>/<operatorImageName>@<operatorImageDigest>`

### Service account

| Parameter | Default | Description |
|---|---|---|
| `serviceAccount.create` | `true` | Create the ServiceAccount resource |
| `serviceAccount.name` | `ibm-pg-operator` | Name of the ServiceAccount to create or use |
| `serviceAccount.annotations` | `{}` | Annotations added to the ServiceAccount (e.g. IAM/IRSA on EKS, Workload Identity on GKE) |

### RBAC

| Parameter | Default | Description |
|---|---|---|
| `rbac.create` | `true` | Create Role and RoleBinding resources. Set to `false` if RBAC is managed externally (e.g. via OLM) |

### Operator deployment

| Parameter | Default | Description |
|---|---|---|
| `operator.replicaCount` | `1` | Number of operator replicas. Keep at `1`; leader election is handled by the operator |
| `operator.resources.requests.cpu` | `500m` | CPU request |
| `operator.resources.requests.memory` | `200Mi` | Memory request |
| `operator.resources.requests.ephemeral-storage` | `250Mi` | Ephemeral storage request |
| `operator.resources.limits.cpu` | `1100m` | CPU limit |
| `operator.resources.limits.memory` | `1Gi` | Memory limit |
| `operator.resources.limits.ephemeral-storage` | `500Mi` | Ephemeral storage limit |
| `operator.securityContext` | _(see values.yaml)_ | Pod-level security context |
| `operator.containerSecurityContext` | _(see values.yaml)_ | Container-level security context |

### Scheduling

| Parameter | Default | Description |
|---|---|---|
| `affinity` | amd64 / s390x / ppc64le required | Node affinity rules. Override the entire key to change architecture constraints |
| `nodeSelector` | `{}` | Additional node label selectors |
| `tolerations` | `[]` | Tolerations for scheduling onto tainted nodes |

### Health probes

All probes target the webhook server at `https://:9443/readyz`.

| Parameter | Default | Description |
|---|---|---|
| `livenessProbe.failureThreshold` | `4` | Consecutive failures before container restart |
| `readinessProbe.failureThreshold` | `3` | Consecutive failures before removal from Service endpoints |
| `startupProbe.failureThreshold` | `6` | Consecutive startup failures before container is killed |
| `startupProbe.periodSeconds` | `5` | Interval between startup probe checks |

### Pod annotations and labels

| Parameter | Default | Description |
|---|---|---|
| `podAnnotations` | IBM product annotations | Annotations added to every operator pod. The IBM product annotations are required for licence tracking |
| `labels` | `{}` | Additional labels propagated to all chart resources |

---

## Platform Notes

### OpenShift

Leave `operator.securityContext.runAsUser` and `operator.securityContext.fsGroup` **unset** when running under the `restricted-v2` SCC. OpenShift assigns a UID from the namespace's allowed range automatically.

```yaml
operator:
  securityContext:
    runAsNonRoot: true
    seccompProfile:
      type: RuntimeDefault
```

### Vanilla Kubernetes

Pin a specific UID if your cluster policy requires it:

```yaml
operator:
  securityContext:
    runAsNonRoot: true
    runAsUser: 1001
    fsGroup: 0
    seccompProfile:
      type: RuntimeDefault
```

---

## RBAC Permissions

When `rbac.create=true` the chart creates a `Role` named `ibm-pg-operator` in every watched namespace with permissions for:

- **Core resources:** ConfigMaps, Secrets, Services, Pods, PVCs, ServiceAccounts, Events
- **`pg.ibm.com` CRDs:** Clusters, Backups, ScheduledBackups, Databases, Poolers, Publications, Subscriptions, FailoverQuorums, ImageCatalogs
- **`apps`:** Deployments
- **`batch`:** Jobs
- **`rbac.authorization.k8s.io`:** Roles, RoleBindings
- **`snapshot.storage.k8s.io`:** VolumeSnapshots
- **`monitoring.coreos.com`:** PodMonitors
- **`policy`:** PodDisruptionBudgets
- **`route.openshift.io`:** Routes _(OpenShift only)_
- **`operators.coreos.com`:** ClusterServiceVersions _(OLM introspection)_

---

## Support

- Documentation: https://www.ibm.com/docs
- GitHub Issues: https://github.com/ibm-ecm/ibm-content-cortex-containers/issues
- Maintainer: IBM Support — support@ibm.com
