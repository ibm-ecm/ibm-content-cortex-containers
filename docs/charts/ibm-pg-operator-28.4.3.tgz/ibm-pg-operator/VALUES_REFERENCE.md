# IBM PostgreSQL Operator Helm Chart — Values Reference

> Complete reference for all configurable values in the `ibm-pg-operator` Helm chart.

## Table of Contents

- [Overview](#overview)
- [Quick Reference](#quick-reference)
- [Complete Values Reference](#complete-values-reference)
  - [Global Configuration](#global-configuration)
  - [Operator Image](#operator-image)
  - [Service Account](#service-account)
  - [RBAC Configuration](#rbac-configuration)
  - [Operator Deployment](#operator-deployment)
  - [Health Probes](#health-probes)
  - [Node Affinity](#node-affinity)
  - [Node Selector](#node-selector)
  - [Tolerations](#tolerations)
  - [Pod Annotations](#pod-annotations)
  - [Labels](#labels)
- [Configuration Examples](#configuration-examples)
- [Support](#support)

---

## Overview

This document provides a complete reference for all values exposed by the `ibm-pg-operator` chart. Every parameter listed here can be overridden via `--set` flags or a custom values file.

The operator manages PostgreSQL clusters (operands) in namespaces it is configured to watch. The operator namespace and one or more instance/tethered namespaces are all independently configurable.

---

## Quick Reference

### Essential Parameters

| Parameter | Default | Required |
|---|---|---|
| `global.operatorNamespace` | `ibm-pg-system` | Yes |
| `global.instanceNamespace` | `ibm-pg-system` | Yes |
| `global.imagePullPrefix` | `icr.io` | Yes |
| `global.imagePullSecret` | `ibm-entitlement-key` | Yes |
| `ibmPgOperator.operatorImageDigest` | `sha256:e4fece…` | Yes |

### Resource Defaults

| Container | CPU Request | CPU Limit | Memory Request | Memory Limit | Ephemeral Storage |
|---|---|---|---|---|---|
| `manager` | `500m` | `1100m` | `200Mi` | `1Gi` | `250Mi` / `500Mi` |

---

## Complete Values Reference

### Global Configuration

```yaml
global:
  operatorNamespace: "ibm-pg-system"
  instanceNamespace: "ibm-pg-system"
  tetheredNamespaces: []
  imagePullPrefix: icr.io
  imagePullSecret: "ibm-entitlement-key"
```

| Parameter | Type | Default | Description |
|---|---|---|---|
| `global.operatorNamespace` | string | `ibm-pg-system` | Namespace where the operator Deployment and its RBAC resources are created |
| `global.instanceNamespace` | string | `ibm-pg-system` | Primary namespace the operator watches for PostgreSQL cluster operands |
| `global.tetheredNamespaces` | list | `[]` | Additional namespaces to watch. A Role and RoleBinding are created in each namespace |
| `global.imagePullPrefix` | string | `icr.io` | Container registry hostname prepended to all image references |
| `global.imagePullSecret` | string | `ibm-entitlement-key` | Name of the Kubernetes Secret used to pull images from the registry |

The operator creates a Role and RoleBinding in every watched namespace (the union of `operatorNamespace`, `instanceNamespace`, and `tetheredNamespaces`, deduplicated).

**Pre-requisite:** The image pull secret must exist in the operator namespace before installation:

```bash
kubectl create secret docker-registry ibm-entitlement-key \
  --docker-server=icr.io \
  --docker-username=iamapikey \
  --docker-password=<YOUR_KEY> \
  -n ibm-pg-system
```

---

### Operator Image

```yaml
ibmPgOperator:
  operatorImageDigest: "sha256:e4fecebcc57710ec0141b807d0b1bd3b8470f5cd6dcae14925494c7e92ead2d1"
  devImagePullPrefix: ""
  operatorImageName: cpopen/ibm-pg-operator
  operandImageRepository: cpopen/ibm-pg
  pullPolicy: Always
```

| Parameter | Type | Default | Description |
|---|---|---|---|
| `ibmPgOperator.operatorImageDigest` | string | `sha256:e4fece…` | SHA256 digest of the multi-arch manifest image. No per-architecture selection required |
| `ibmPgOperator.devImagePullPrefix` | string | `""` | Override registry prefix for development/testing. When set, takes precedence over `global.imagePullPrefix` |
| `ibmPgOperator.operatorImageName` | string | `cpopen/ibm-pg-operator` | Repository path for the operator image, appended to the registry prefix |
| `ibmPgOperator.operandImageRepository` | string | `cpopen/ibm-pg` | Repository path for PostgreSQL operand images (used in the ImageCatalog and operand ConfigMap) |
| `ibmPgOperator.pullPolicy` | string | `Always` | Image pull policy. One of `Always`, `IfNotPresent`, `Never` |

The resolved operator image reference is: `<imagePullPrefix>/<operatorImageName>@<operatorImageDigest>`

---

### Service Account

```yaml
serviceAccount:
  create: true
  name: "ibm-pg-operator"
  annotations: {}
```

| Parameter | Type | Default | Description |
|---|---|---|---|
| `serviceAccount.create` | boolean | `true` | Create the ServiceAccount resource |
| `serviceAccount.name` | string | `ibm-pg-operator` | Name of the ServiceAccount to create or use |
| `serviceAccount.annotations` | object | `{}` | Annotations to add to the ServiceAccount — useful for IAM/IRSA on AWS EKS or Workload Identity on GKE |

When `serviceAccount.create` is `false` the chart assumes a ServiceAccount named `serviceAccount.name` already exists in `global.operatorNamespace`.

---

### RBAC Configuration

```yaml
rbac:
  create: true
```

| Parameter | Type | Default | Description |
|---|---|---|---|
| `rbac.create` | boolean | `true` | Create Role and RoleBinding resources |

When `true`, the chart creates in every watched namespace:
- **Role** `ibm-pg-operator` — permissions for `pg.ibm.com` CRDs, core Kubernetes resources, OpenShift `route.openshift.io` routes, and OLM `operators.coreos.com` CSVs
- **RoleBinding** `ibm-pg-operator-rolebinding` — binds the Role to the ServiceAccount

Set to `false` if your platform manages RBAC externally (e.g. OLM subscription).

---

### Operator Deployment

```yaml
operator:
  replicaCount: 1

  resources:
    limits:
      cpu: 1100m
      memory: 1Gi
      ephemeral-storage: 500Mi
    requests:
      cpu: 500m
      memory: 200Mi
      ephemeral-storage: 250Mi

  securityContext:
    runAsNonRoot: true
    seccompProfile:
      type: RuntimeDefault
    # runAsUser: 1001  # Uncomment to pin a UID (optional on OpenShift)
    # fsGroup: 0

  containerSecurityContext:
    allowPrivilegeEscalation: false
    privileged: false
    readOnlyRootFilesystem: true
    capabilities:
      drop:
        - ALL
    seccompProfile:
      type: RuntimeDefault
```

| Parameter | Type | Default | Description |
|---|---|---|---|
| `operator.replicaCount` | integer | `1` | Number of operator replicas. Keep at `1` — leader election is handled by the operator itself |
| `operator.resources.limits.cpu` | string | `1100m` | CPU limit for the `manager` container |
| `operator.resources.limits.memory` | string | `1Gi` | Memory limit |
| `operator.resources.limits.ephemeral-storage` | string | `500Mi` | Ephemeral storage limit |
| `operator.resources.requests.cpu` | string | `500m` | CPU request |
| `operator.resources.requests.memory` | string | `200Mi` | Memory request |
| `operator.resources.requests.ephemeral-storage` | string | `250Mi` | Ephemeral storage request |
| `operator.securityContext.runAsNonRoot` | boolean | `true` | Pod must not run as UID 0 |
| `operator.securityContext.seccompProfile.type` | string | `RuntimeDefault` | Seccomp profile for the pod. Required for OCP 4.12+ `restricted-v2` SCC |
| `operator.securityContext.runAsUser` | integer | _(unset)_ | Pin a specific UID. Leave unset on OpenShift so the platform assigns one from the namespace range |
| `operator.securityContext.fsGroup` | integer | _(unset)_ | Filesystem group ID for mounted volumes |
| `operator.containerSecurityContext.allowPrivilegeEscalation` | boolean | `false` | Prevent the process from gaining additional privileges |
| `operator.containerSecurityContext.privileged` | boolean | `false` | Do not run as a privileged container |
| `operator.containerSecurityContext.readOnlyRootFilesystem` | boolean | `true` | Mount the container's root filesystem as read-only |
| `operator.containerSecurityContext.capabilities.drop` | list | `["ALL"]` | Drop all Linux capabilities |
| `operator.containerSecurityContext.seccompProfile.type` | string | `RuntimeDefault` | Seccomp profile for the container |

**OpenShift note:** Leave `operator.securityContext.runAsUser` and `operator.securityContext.fsGroup` unset when running under the `restricted-v2` SCC. OpenShift will assign a UID from the namespace's allowed range automatically.

---

### Health Probes

```yaml
livenessProbe:
  failureThreshold: 4
  httpGet:
    path: /readyz
    port: 9443
    scheme: HTTPS

readinessProbe:
  failureThreshold: 3
  httpGet:
    path: /readyz
    port: 9443
    scheme: HTTPS

startupProbe:
  failureThreshold: 6
  periodSeconds: 5
  httpGet:
    path: /readyz
    port: 9443
    scheme: HTTPS
```

| Parameter | Type | Default | Description |
|---|---|---|---|
| `livenessProbe.failureThreshold` | integer | `4` | Consecutive failures before the container is restarted |
| `livenessProbe.httpGet.path` | string | `/readyz` | Probe endpoint path |
| `livenessProbe.httpGet.port` | integer | `9443` | Webhook server port (HTTPS) |
| `readinessProbe.failureThreshold` | integer | `3` | Consecutive failures before the pod is removed from Service endpoints |
| `startupProbe.failureThreshold` | integer | `6` | Consecutive startup failures before the container is killed |
| `startupProbe.periodSeconds` | integer | `5` | Interval between startup probe checks |

All three probes target the webhook server on port `9443` (HTTPS). The operator serves `/readyz` from its internal health endpoint.

---

### Node Affinity

```yaml
affinity:
  nodeAffinity:
    requiredDuringSchedulingIgnoredDuringExecution:
      nodeSelectorTerms:
        - matchExpressions:
            - key: kubernetes.io/arch
              operator: In
              values:
                - amd64
                - s390x
                - ppc64le
```

| Parameter | Type | Description |
|---|---|---|
| `affinity` | object | Full Kubernetes affinity spec. Override to restrict or prefer specific nodes |

The default `requiredDuringScheduling` rule restricts the operator to `amd64`, `s390x`, and `ppc64le` nodes. Override the entire `affinity` key to change this behaviour.

---

### Node Selector

```yaml
nodeSelector: {}
```

| Parameter | Type | Default | Description |
|---|---|---|---|
| `nodeSelector` | object | `{}` | Additional node label selectors applied alongside `affinity` |

---

### Tolerations

```yaml
tolerations: []
```

| Parameter | Type | Default | Description |
|---|---|---|---|
| `tolerations` | list | `[]` | Kubernetes tolerations for scheduling onto tainted nodes |

---

### Pod Annotations

```yaml
podAnnotations:
  productChargedContainers: All
  productID: "494bca72144346eb972f63ee7341ada7"
  productMetric: FREE
  productName: IBM Operator for PostgreSQL
```

| Parameter | Type | Default | Description |
|---|---|---|---|
| `podAnnotations` | object | _(see above)_ | Annotations added to every operator pod. The IBM product annotations are required for licence tracking |

---

### Labels

```yaml
labels: {}
```

| Parameter | Type | Default | Description |
|---|---|---|---|
| `labels` | object | `{}` | Additional labels propagated to all chart resources |

---

## Configuration Examples

### Minimal — shared operator and instance namespace

```yaml
global:
  operatorNamespace: ibm-pg-system
  instanceNamespace: ibm-pg-system
  imagePullSecret: ibm-entitlement-key
```

### Multi-namespace — operator watches additional namespaces

```yaml
global:
  operatorNamespace: ibm-pg-system
  instanceNamespace: app-namespace-1
  tetheredNamespaces:
    - app-namespace-2
    - app-namespace-3
```

A Role and RoleBinding are created in `ibm-pg-system`, `app-namespace-1`, `app-namespace-2`, and `app-namespace-3`.

### Development — use a private registry

```yaml
global:
  imagePullPrefix: my-registry.example.com
  imagePullSecret: my-registry-secret

ibmPgOperator:
  devImagePullPrefix: my-registry.example.com/dev
  pullPolicy: Always
```

### OpenShift — pin UID for vanilla Kubernetes, leave unset for OCP

```yaml
# Vanilla Kubernetes — pin UID
operator:
  securityContext:
    runAsNonRoot: true
    runAsUser: 1001
    fsGroup: 0
    seccompProfile:
      type: RuntimeDefault
```

```yaml
# OpenShift — omit runAsUser and fsGroup entirely
operator:
  securityContext:
    runAsNonRoot: true
    seccompProfile:
      type: RuntimeDefault
```

### Reduced resources for non-production

```yaml
operator:
  resources:
    limits:
      cpu: 500m
      memory: 512Mi
      ephemeral-storage: 250Mi
    requests:
      cpu: 100m
      memory: 128Mi
      ephemeral-storage: 100Mi
```

### Custom node placement

```yaml
nodeSelector:
  node-role.kubernetes.io/infra: ""

tolerations:
  - key: node-role.kubernetes.io/infra
    operator: Exists
    effect: NoSchedule

affinity:
  nodeAffinity:
    requiredDuringSchedulingIgnoredDuringExecution:
      nodeSelectorTerms:
        - matchExpressions:
            - key: kubernetes.io/arch
              operator: In
              values:
                - amd64
```

---

## Support

- Documentation: https://www.ibm.com/docs
- GitHub Issues: https://github.com/ibm-ecm/ibm-content-cortex-containers/issues
- Email: support@ibm.com
