# IBM Model Gateway Operator Helm Chart

[![Helm Version](https://img.shields.io/badge/Helm-v4.0+-blue.svg)](https://helm.sh)
[![Kubernetes Version](https://img.shields.io/badge/Kubernetes-v1.24+-blue.svg)](https://kubernetes.io)
[![OpenShift Version](https://img.shields.io/badge/OpenShift-v4.12+-red.svg)](https://www.openshift.com)
[![Chart Version](https://img.shields.io/badge/Chart-26.0.1-green.svg)](./Chart.yaml)

## 📋 Table of Contents

- [Overview](#overview)
- [Prerequisites](#prerequisites)
- [Quick Start](#quick-start)
- [Installation](#installation)
- [Configuration](#configuration)
- [Post-Installation](#post-installation)
- [Upgrading](#upgrading)
- [Uninstallation](#uninstallation)
- [Troubleshooting](#troubleshooting)
- [Advanced Configuration](#advanced-configuration)
- [Useful Helm Commands](#useful-helm-commands)
- [Support](#support)

## 🎯 Overview

The **IBM Model Gateway Operator** Helm chart deploys the operator for **IBM Model Gateway** on Kubernetes and OpenShift platforms. This chart installs only the operator and its supporting RBAC resources — the actual Model Gateway workload is deployed by creating a `modelgateway` Custom Resource after the operator is running.

The operator provides:
- **Unified Model Routing**: A single gateway layer for AI model access across IBM Cloud Pak for Data and Content Cortex environments
- **Lifecycle Management**: Automated deployment, upgrade, and configuration of Model Gateway components
- **Multi-Architecture Support**: Runs on amd64, s390x, and ppc64le nodes
- **Cloud-Native Deployment**: Kubernetes-native operator pattern with CRD-based configuration

## ✅ Prerequisites

Before installing this chart, ensure you have:

### Required

- **Kubernetes 1.24+** or **OpenShift 4.12+**
- **Helm 4.0+** installed and configured
- **IBM Entitlement Key** from [IBM Container Library](https://myibm.ibm.com/products-services/containerlibrary)
- **Namespace** created for the deployment

### Recommended

- **IBM Cloud Pak for Data** or **IBM Content Cortex** already deployed in the cluster
- **cert-manager** installed for TLS certificate management
- **IBM PostgreSQL Operator** deployed (for database-backed components)
- **IBM Redis Operator** deployed (for caching components)

## 🚀 Quick Start

```bash
# 1. Create namespace
kubectl create namespace ibm-model-gateway

# 2. Create image pull secret
kubectl create secret docker-registry ibm-entitlement-key \
  --docker-server=cp.icr.io \
  --docker-username=cp \
  --docker-password=<your-entitlement-key> \
  --namespace ibm-model-gateway

# 3. Install the chart
helm install model-gateway-operator ./helm-charts/model-gateway-operator \
  --namespace ibm-model-gateway

# 4. Verify installation
kubectl get pods -n ibm-model-gateway -l control-plane=ibm-model-gateway-operator
```

## 📦 Installation

### Step 1: Create Namespace

```bash
kubectl create namespace ibm-model-gateway
```

**OpenShift:**
```bash
oc new-project ibm-model-gateway
```

### Step 2: Create Image Pull Secret

Get your IBM Entitlement Key from [IBM Container Library](https://myibm.ibm.com/products-services/containerlibrary).

```bash
kubectl create secret docker-registry ibm-entitlement-key \
  --docker-server=cp.icr.io \
  --docker-username=cp \
  --docker-password=<your-entitlement-key> \
  --namespace ibm-model-gateway
```

### Step 3: Install the Chart

**Basic Installation:**
```bash
helm install model-gateway-operator ./helm-charts/model-gateway-operator \
  --namespace ibm-model-gateway
```

**With Custom Values:**
```bash
helm install model-gateway-operator ./helm-charts/model-gateway-operator \
  --namespace ibm-model-gateway \
  --values custom-values.yaml
```

**With Inline Overrides:**
```bash
helm install model-gateway-operator ./helm-charts/model-gateway-operator \
  --namespace ibm-model-gateway \
  --set image.tag=26.0.0 \
  --set replicaCount=1
```

**Skip CRD installation (if CRD already exists):**
```bash
helm install model-gateway-operator ./helm-charts/model-gateway-operator \
  --namespace ibm-model-gateway \
  --skip-crds
```

### Step 4: Verify Installation

```bash
# Check Helm release
helm list -n ibm-model-gateway

# Check operator deployment
kubectl get deployment ibm-model-gateway-operator -n ibm-model-gateway

# Check operator pods
kubectl get pods -n ibm-model-gateway -l control-plane=ibm-model-gateway-operator

# View operator logs
kubectl logs -n ibm-model-gateway -l control-plane=ibm-model-gateway-operator -f

# Check CRD installation
kubectl get crd modelgateway.modelgateway.cpd.ibm.com
```

## ⚙️ Configuration

### Key Configuration Parameters

| Parameter | Description | Default | Required |
|-----------|-------------|---------|----------|
| `image.repository` | Operator image repository | `icr.io/cpopen/ibm-cpd-model-gateway-operator` | Yes |
| `image.digest` | Default operator image digest | `sha256:c7d8b463...` | No |
| `image.tag` | Optional image tag override | `""` | No |
| `image.pullPolicy` | Image pull policy | `IfNotPresent` | Yes |
| `imagePullSecrets` | Image pull secrets | `[{name: ibm-entitlement-key}]` | Yes |
| `replicaCount` | Number of operator replicas | `1` | Yes |
| `serviceAccount.create` | Create service account | `true` | Yes |
| `serviceAccount.name` | Service account name | `ibm-model-gateway-operator-sa` | Yes |
| `rbac.create` | Create RBAC resources | `true` | Yes |
| `operator.name` | Operator deployment name | `ibm-model-gateway-operator` | Yes |
| `operator.resources.limits.cpu` | CPU limit | `500m` | Yes |
| `operator.resources.limits.memory` | Memory limit | `1024Mi` | Yes |
| `operator.resources.requests.cpu` | CPU request | `100m` | Yes |
| `operator.resources.requests.memory` | Memory request | `256Mi` | Yes |
| `operator.args` | Command line arguments | see values.yaml | Yes |

### Image Configuration

The chart supports two image reference methods:

**1. Using Digest (Default — Recommended for Production):**
```yaml
image:
  repository: icr.io/cpopen/ibm-cpd-model-gateway-operator
  digest: "sha256:aa24398342468543ca793bbb04918ea5385915bdea57882892f44537013e280a"
  tag: ""  # Leave empty to use digest
```

**2. Using Tag (Flexible for Development):**
```yaml
image:
  repository: icr.io/cpopen/ibm-cpd-model-gateway-operator
  tag: "26.0.0"  # When set, digest is ignored
```

### Security Configuration

**Default Security (Pod + Container):**
```yaml
operator:
  securityContext:
    runAsNonRoot: true

  containerSecurityContext:
    allowPrivilegeEscalation: false
    privileged: false
    readOnlyRootFilesystem: true
    capabilities:
      drop:
        - ALL
```

**Enhanced Security (OpenShift 4.12+):**
```yaml
operator:
  securityContext:
    runAsNonRoot: true
    runAsUser: 1001
    seccompProfile:
      type: RuntimeDefault

  containerSecurityContext:
    allowPrivilegeEscalation: false
    privileged: false
    readOnlyRootFilesystem: true
    capabilities:
      drop:
        - ALL
```

### Node Affinity

The operator supports amd64, s390x, and ppc64le architectures:

```yaml
affinity:
  nodeAffinity:
    requiredDuringSchedulingIgnoredDuringExecution:
      nodeSelectorTerms:
        - matchExpressions:
            - key: kubernetes.io/arch
              operator: In
              values:
                - amd64
                - s390x
                - ppc64le
```

### Network Policy Labels

```yaml
networkPolicyLabels:
  com.ibm.fncm.networking/egress-deny-all: "true"
  com.ibm.fncm.networking/egress-allow-same-namespace: "true"
  com.ibm.fncm.networking/egress-allow-k8s-services: "true"
  com.ibm.fncm.networking/egress-allow-all: "true"
```

## 🔄 Post-Installation

After installing the operator, create a `modelgateway` Custom Resource to deploy the gateway workload.

### 1. Verify Operator Status

```bash
kubectl get deployment ibm-model-gateway-operator -n ibm-model-gateway
kubectl get pods -n ibm-model-gateway -l control-plane=ibm-model-gateway-operator
kubectl logs -n ibm-model-gateway -l control-plane=ibm-model-gateway-operator --tail=100 -f
```

### 2. Generate and Apply the Model Gateway CR

> **Recommended**: Use the IBM Content Cortex prerequisites script to generate the Custom Resource and all supporting artifacts automatically. The script handles property collection, secret generation, and CR templating for you.

From the `scripts/` directory:

```bash
# Step 1 — Gather deployment configuration interactively
python3 prerequisites.py gather

# Step 2 — Generate all deployment artifacts (CR YAML, Kubernetes secrets, SQL scripts)
python3 prerequisites.py generate

# Step 3 — Validate external dependencies (certificates, databases, LDAP/IDP)
python3 prerequisites.py validate
```

Generated artifacts are written to `scripts/generatedFiles/<namespace>/`. Apply the generated Model Gateway CR:

```bash
kubectl apply -f scripts/generatedFiles/<namespace>/ibm_modelgateway_cr.yaml -n ibm-model-gateway
```

If you need to deploy without the prerequisites script, reference CR files are provided in the `descriptors/model-gateway/` directory:

```bash
# Minimal CR
kubectl apply -f descriptors/model-gateway/ibm_modelgateway_cr.yaml -n ibm-model-gateway

# Full CR with all options
kubectl apply -f descriptors/model-gateway/ibm_modelgateway_full_cr.yaml -n ibm-model-gateway
```

### 3. Monitor Deployment

```bash
kubectl get modelgateway -n ibm-model-gateway
kubectl get pods -n ibm-model-gateway -w
kubectl get events -n ibm-model-gateway --sort-by='.lastTimestamp'
```

## 📈 Upgrading

```bash
# Upgrade with same values
helm upgrade model-gateway-operator ./helm-charts/model-gateway-operator \
  --namespace ibm-model-gateway \
  --reuse-values

# Upgrade with new image digest
helm upgrade model-gateway-operator ./helm-charts/model-gateway-operator \
  --namespace ibm-model-gateway \
  --reuse-values \
  --set image.digest="sha256:<new-digest>"

# Check rollout status
kubectl rollout status deployment/ibm-model-gateway-operator -n ibm-model-gateway
```

## 🗑️ Uninstallation

```bash
# Uninstall the chart (CRD is preserved)
helm uninstall model-gateway-operator -n ibm-model-gateway
```

**Complete Cleanup:**
```bash
# 1. Delete all modelgateway resources first
kubectl delete modelgateway --all -n ibm-model-gateway

# 2. Uninstall the chart
helm uninstall model-gateway-operator -n ibm-model-gateway

# 3. Delete CRD (WARNING: deletes all modelgateway resources cluster-wide)
kubectl delete crd modelgateway.modelgateway.cpd.ibm.com

# 4. Delete namespace
kubectl delete namespace ibm-model-gateway
```

> **Note:** `helm uninstall` does **not** delete the CRD to prevent accidental data loss.

## 🔧 Troubleshooting

### Operator Not Starting

```bash
# Check pod status and events
kubectl describe pod -n ibm-model-gateway -l control-plane=ibm-model-gateway-operator

# Check previous logs
kubectl logs -n ibm-model-gateway -l control-plane=ibm-model-gateway-operator --previous

# List all events
kubectl get events -n ibm-model-gateway --sort-by='.lastTimestamp' | tail -20
```

**Common Causes:**
- `ImagePullBackOff` — verify `ibm-entitlement-key` secret exists and is valid
- `Pending` — check node resource availability and affinity constraints
- `CrashLoopBackOff` — inspect logs for configuration errors

### CRD Not Found

```bash
# Verify CRD is present
kubectl get crd modelgateway.modelgateway.cpd.ibm.com

# Reinstall with CRD
helm upgrade model-gateway-operator ./helm-charts/model-gateway-operator \
  --namespace ibm-model-gateway --reuse-values
```

### Resource Pressure

```bash
# Check resource usage
kubectl top pod -n ibm-model-gateway -l control-plane=ibm-model-gateway-operator

# Adjust limits
helm upgrade model-gateway-operator ./helm-charts/model-gateway-operator \
  --namespace ibm-model-gateway \
  --reuse-values \
  --set operator.resources.limits.memory=2048Mi
```

## 🎓 Advanced Configuration

### Private Registry

```yaml
image:
  repository: my-registry.company.com/ibm-cpd-model-gateway-operator
  tag: "26.0.0"

imagePullSecrets:
  - name: my-registry-secret
```

### Air-Gapped Deployment

```bash
# Mirror the image
docker pull icr.io/cpopen/ibm-cpd-model-gateway-operator@sha256:c7d8b463...
docker tag icr.io/cpopen/ibm-cpd-model-gateway-operator@sha256:c7d8b463... \
  my-registry.company.com/ibm-cpd-model-gateway-operator:26.0.0
docker push my-registry.company.com/ibm-cpd-model-gateway-operator:26.0.0
```

Then install with your private registry values.

### Custom Operator Arguments

```yaml
operator:
  args:
    - --zap-log-level
    - info          # Change from 'error' to 'info' for verbose logging
    - --max-concurrent-reconciles
    - '2'
    - --reconcile-period
    - 30s
```

## 📚 Useful Helm Commands

```bash
# Lint the chart
helm lint ./helm-charts/model-gateway-operator

# Dry-run installation
helm install model-gateway-operator ./helm-charts/model-gateway-operator \
  --namespace ibm-model-gateway --dry-run --debug

# Render templates
helm template model-gateway-operator ./helm-charts/model-gateway-operator \
  --namespace ibm-model-gateway

# Show values
helm show values ./helm-charts/model-gateway-operator

# Run tests
helm test model-gateway-operator -n ibm-model-gateway
```

## 📞 Support

- **Product Documentation**: [IBM Content Cortex Documentation](https://www.ibm.com/docs/SSL4SY_26.0.0/com.ibm.p8.containers.doc/containers.html)
- **GitHub Repository**: [Content Cortex Containers](https://github.com/ibm-ecm/ibm-content-cortex-containers)
- **IBM Support**: [IBM Support Portal](https://www.ibm.com/mysupport)
- **Email**: ecm-container-service@ibm.com

## 📄 License

Licensed Materials - Property of IBM

(C) Copyright IBM Corp. 2026. All Rights Reserved.

US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

---

**Chart Version**: 26.0.1 | **App Version**: 26.0.0 | **Last Updated**: 2026-07-10
