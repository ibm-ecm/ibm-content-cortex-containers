# IBM Model Gateway Operator - Values Reference Guide

[![Chart Version](https://img.shields.io/badge/Chart-26.0.1-green.svg)](./Chart.yaml)
[![Helm Version](https://img.shields.io/badge/Helm-v4.0+-blue.svg)](https://helm.sh)

## 📋 Table of Contents

- [Overview](#overview)
- [Quick Reference](#quick-reference)
- [Complete Values Reference](#complete-values-reference)
- [Configuration Examples](#configuration-examples)
- [Validation](#validation)

## 🎯 Overview

This document provides a comprehensive reference for all configuration values in the IBM Model Gateway Operator Helm chart.

## 🚀 Quick Reference

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `image.repository` | string | `icr.io/cpopen/ibm-cpd-model-gateway-operator` | Operator image repository |
| `image.tag` | string | `""` | Image tag (overrides digest when set) |
| `image.digest` | string | `sha256:c7d8b463...` | Image digest (used when tag is empty) |
| `replicaCount` | integer | `1` | Number of operator replicas |
| `operator.name` | string | `ibm-model-gateway-operator` | Operator deployment name |
| `operator.resources.limits.cpu` | string | `500m` | CPU limit |
| `operator.resources.limits.memory` | string | `1024Mi` | Memory limit |
| `operator.resources.requests.cpu` | string | `100m` | CPU request |
| `operator.resources.requests.memory` | string | `256Mi` | Memory request |
| `serviceAccount.name` | string | `ibm-model-gateway-operator-sa` | Service account name |

## 📖 Complete Values Reference

### Name Overrides

```yaml
# Override the chart name
nameOverride: ""

# Override the full name (release-name + chart-name)
fullnameOverride: ""
```

---

### Image Configuration

```yaml
image:
  # Image repository
  # Default: icr.io/cpopen/ibm-cpd-model-gateway-operator
  repository: icr.io/cpopen/ibm-cpd-model-gateway-operator

  # Image digest — used when tag is empty (recommended for production)
  # Default: sha256:aa24398342468543ca793bbb04918ea5385915bdea57882892f44537013e280a
  digest: "sha256:aa24398342468543ca793bbb04918ea5385915bdea57882892f44537013e280a"

  # Image tag — when set, overrides digest
  # Default: ""
  tag: ""

  # Image pull policy
  # Options: Always, IfNotPresent, Never
  # Default: IfNotPresent
  pullPolicy: IfNotPresent
```

**Image reference behaviour:**
- If `tag` is set → `repository:tag`
- If `tag` is empty → `repository@digest`

---

### Image Pull Secrets

```yaml
# Default: [{name: ibm-entitlement-key}]
imagePullSecrets:
  - name: ibm-entitlement-key
```

---

### Replica Count

```yaml
# Default: 1
replicaCount: 1
```

---

### Service Account

```yaml
serviceAccount:
  # Create a service account
  # Default: true
  create: true

  # Service account name
  # Default: ibm-model-gateway-operator-sa
  name: "ibm-model-gateway-operator-sa"
```

---

### RBAC

```yaml
rbac:
  # Create Role and RoleBinding
  # Default: true
  create: true
```

---

### Operator Configuration

```yaml
operator:
  # Operator deployment name
  # Default: ibm-model-gateway-operator
  name: ibm-model-gateway-operator

  # Resource limits and requests
  resources:
    limits:
      cpu: 500m
      memory: 1024Mi
      ephemeral-storage: 250Mi
    requests:
      cpu: 100m
      memory: 256Mi
      ephemeral-storage: 250Mi

  # Pod security context
  securityContext:
    runAsNonRoot: true
    # runAsUser: 1001
    # fsGroup: 0
    # seccompProfile:
    #   type: RuntimeDefault

  # Container security context
  containerSecurityContext:
    allowPrivilegeEscalation: false
    privileged: false
    readOnlyRootFilesystem: true
    capabilities:
      drop:
        - ALL

  # Operator CLI arguments
  args:
    - --zap-log-level
    - error
    - --max-concurrent-reconciles
    - '1'
    - --reconcile-period
    - 0s
```

---

### Health Probes

```yaml
livenessProbe:
  httpGet:
    path: /healthz
    port: 6789
    scheme: HTTP
  initialDelaySeconds: 10
  periodSeconds: 10
  timeoutSeconds: 5
  successThreshold: 1
  failureThreshold: 3

readinessProbe:
  httpGet:
    path: /readyz
    port: 6789
    scheme: HTTP
  initialDelaySeconds: 5
  periodSeconds: 10
  timeoutSeconds: 5
  successThreshold: 1
  failureThreshold: 3
```

---

### Node Affinity

```yaml
affinity:
  nodeAffinity:
    requiredDuringSchedulingIgnoredDuringExecution:
      nodeSelectorTerms:
        - matchExpressions:
            - key: kubernetes.io/arch
              operator: In
              values:
                - amd64
                - s390x
                - ppc64le
    preferredDuringSchedulingIgnoredDuringExecution:
      - weight: 3
        preference:
          matchExpressions:
            - key: kubernetes.io/arch
              operator: In
              values:
                - amd64
                - s390x
                - ppc64le
```

---

### Node Selector & Tolerations

```yaml
# Additional node selectors
nodeSelector: {}

# Tolerations for tainted nodes
tolerations: []
# Example:
# tolerations:
#   - key: "dedicated"
#     operator: "Equal"
#     value: "model-gateway"
#     effect: "NoSchedule"
```

---

### Pod Annotations

```yaml
podAnnotations:
  productID: "9c2d4f167cdb411fa3b1d787eb3c7c34"
  productName: "IBM Content Cortex Essentials"
  productMetric: "AUTHORIZED_USER"
  productChargedContainers: ""
  productVersion: "26.0.0"
```

---

### Descriptor Labels

```yaml
# Labels that align with operator descriptor files
descriptorLabels:
  instance: ibm-model-gateway
  managedBy: ibm-model-gateway
  name: ibm-model-gateway
```

---

### Common Labels

```yaml
# Applied to all chart-managed resources
labels:
  control-plane: ibm-model-gateway-operator
  release: "13.0.4"
```

---

### Network Policy Labels

```yaml
networkPolicyLabels:
  com.ibm.fncm.networking/egress-allow-all: "true"
  com.ibm.fncm.networking/egress-allow-k8s-services: "true"
  com.ibm.fncm.networking/egress-allow-same-namespace: "true"
  com.ibm.fncm.networking/egress-deny-all: "true"
```

---

## 📝 Configuration Examples

### Minimal

```yaml
image:
  tag: "13.0.4"

imagePullSecrets:
  - name: ibm-entitlement-key
```

### Development

```yaml
image:
  tag: "13.0.4"
  pullPolicy: Always

operator:
  args:
    - --zap-log-level
    - info
    - --max-concurrent-reconciles
    - '1'
    - --reconcile-period
    - 30s
  resources:
    limits:
      cpu: 500m
      memory: 512Mi
      ephemeral-storage: 250Mi
    requests:
      cpu: 100m
      memory: 256Mi
      ephemeral-storage: 250Mi
```

### Production (digest-pinned)

```yaml
image:
  digest: "sha256:aa24398342468543ca793bbb04918ea5385915bdea57882892f44537013e280a"
  pullPolicy: IfNotPresent

operator:
  securityContext:
    runAsNonRoot: true
    runAsUser: 1001
    seccompProfile:
      type: RuntimeDefault
  containerSecurityContext:
    allowPrivilegeEscalation: false
    privileged: false
    readOnlyRootFilesystem: true
    capabilities:
      drop:
        - ALL

podAnnotations:
  productID: "9c2d4f167cdb411fa3b1d787eb3c7c34"
  productName: "IBM Content Cortex Essentials"
  productVersion: "26.0.0"
  productMetric: "AUTHORIZED_USER"
  productChargedContainers: ""
```

### Private Registry

```yaml
image:
  repository: my-registry.company.com/ibm-cpd-model-gateway-operator
  tag: "26.0.0"

imagePullSecrets:
  - name: my-registry-secret
```

## 🔍 Validation

```bash
# Lint the chart
helm lint ./helm-charts/model-gateway-operator --values my-values.yaml

# Dry-run installation
helm install model-gateway-operator ./helm-charts/model-gateway-operator \
  --namespace ibm-model-gateway \
  --values my-values.yaml \
  --dry-run --debug

# Template rendering
helm template model-gateway-operator ./helm-charts/model-gateway-operator \
  --namespace ibm-model-gateway \
  --values my-values.yaml
```

## 📞 Support

- **Documentation**: [Chart README](./README.md)
- **Schema**: [values.schema.json](./values.schema.json)
- **IBM Support**: [IBM Support Portal](https://www.ibm.com/mysupport)

---

**Chart Version**: 13.0.4 | **Last Updated**: 2026-07-10
