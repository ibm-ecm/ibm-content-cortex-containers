# IBM Redis Operator Helm Chart - Values Reference Guide

> Complete reference for all configurable values in the `ibm-redis-operator` Helm chart.

## 📋 Table of Contents

- [Overview](#overview)
- [Quick Reference](#quick-reference)
- [Complete Values Reference](#complete-values-reference)
  - [Name Overrides](#name-overrides)
  - [Image Configuration](#image-configuration)
  - [Image Pull Secrets](#image-pull-secrets)
  - [Replica Count](#replica-count)
  - [Service Account](#service-account)
  - [RBAC Configuration](#rbac-configuration)
  - [Operator Configuration](#operator-configuration)
  - [Health Probes](#health-probes)
  - [Node Affinity](#node-affinity)
  - [Node Selector](#node-selector)
  - [Tolerations](#tolerations)
  - [Pod Annotations](#pod-annotations)
  - [Descriptor Labels](#descriptor-labels)
  - [Labels](#labels)
  - [Network Policy Labels](#network-policy-labels)
  - [Vault Integration](#vault-integration)
- [Configuration Examples](#configuration-examples)
- [Support](#support)

---

## 🎯 Overview

This document provides a complete reference for all values exposed by the `ibm-redis-operator` chart. Every parameter listed here can be overridden via `--set` flags or a custom values file.

---

## 🚀 Quick Reference

### Essential Parameters

| Parameter | Default | Required |
|---|---|---|
| `image.repository` | `icr.io/cpopen/ibm-redis-cp-operator` | Yes |
| `image.digest` | `sha256:cb34b47…` | Yes (unless tag set) |
| `imagePullSecrets[0].name` | `ibm-entitlement-key` | Yes |
| `serviceAccount.name` | `ibm-redis-operator-sa` | Yes |
| `operator.name` | `ibm-redis-operator` | Yes |

### Resource Defaults

| Container | CPU Request | CPU Limit | Memory Request | Memory Limit |
|---|---|---|---|---|
| `ibm-redis-operator` | `100m` | `750m` | `256Mi` | `1536Mi` |

---

## 📖 Complete Values Reference

### Name Overrides

```yaml
nameOverride: ""
fullnameOverride: ""
```

| Parameter | Type | Default | Description |
|---|---|---|---|
| `nameOverride` | string | `""` | Override the chart name component used in resource names |
| `fullnameOverride` | string | `""` | Override the full name (`release-name + chart-name`) |

---

### Image Configuration

```yaml
image:
  repository: icr.io/cpopen/ibm-redis-cp-operator
  digest: "sha256:501f90a1fde4f1a8c5097daff37e103900d9b67145820853146b03015d805c02"
  tag: ""
  pullPolicy: IfNotPresent
```

| Parameter | Type | Default | Description |
|---|---|---|---|
| `image.repository` | string | `icr.io/cpopen/ibm-redis-cp-operator` | Container image repository |
| `image.digest` | string | `sha256:cb34b47…` | Image digest. Used when `tag` is empty |
| `image.tag` | string | `""` | Image tag. When set, overrides `digest` |
| `image.pullPolicy` | string | `IfNotPresent` | One of `Always`, `IfNotPresent`, `Never` |

**Digest vs Tag:**
- Leave `tag` empty to use `repository@digest` (recommended for production)
- Set `tag` to use `repository:tag` (useful for development/testing)

---

### Image Pull Secrets

```yaml
imagePullSecrets:
  - name: ibm-entitlement-key
```

| Parameter | Type | Default | Description |
|---|---|---|---|
| `imagePullSecrets` | list | `[{name: ibm-entitlement-key}]` | Secrets for pulling images from the registry |

The secret must exist in the target namespace before chart installation:
```bash
kubectl create secret docker-registry ibm-entitlement-key \
  --docker-server=icr.io \
  --docker-username=iamapikey \
  --docker-password=<YOUR_KEY> \
  -n <namespace>
```

---

### Replica Count

```yaml
replicaCount: 1
```

| Parameter | Type | Default | Description |
|---|---|---|---|
| `replicaCount` | integer | `1` | Number of operator replicas. Keep at `1` for operators |

---

### Service Account

```yaml
serviceAccount:
  create: true
  name: "ibm-redis-operator-sa"
```

| Parameter | Type | Default | Description |
|---|---|---|---|
| `serviceAccount.create` | boolean | `true` | Create the service account |
| `serviceAccount.name` | string | `ibm-redis-operator-sa` | Service account name |

---

### RBAC Configuration

```yaml
rbac:
  create: true
```

| Parameter | Type | Default | Description |
|---|---|---|---|
| `rbac.create` | boolean | `true` | Create Role and RoleBinding for the operator |

When `true`, the chart creates:
- **Role** `ibm-redis-operator-role` — namespace-scoped permissions for Redis management
- **RoleBinding** `ibm-redis-operator-rolebinding` — binds the role to the service account

---

### Operator Configuration

```yaml
operator:
  name: ibm-redis-operator

  resources:
    limits:
      cpu: 750m
      ephemeral-storage: 750Mi
      memory: 1536Mi
    requests:
      cpu: 100m
      ephemeral-storage: 250Mi
      memory: 256Mi

  securityContext:
    runAsNonRoot: true

  containerSecurityContext:
    allowPrivilegeEscalation: false
    privileged: false
    readOnlyRootFilesystem: false
    runAsNonRoot: true
    capabilities:
      drop:
        - ALL

  env:
    ansibleGathering: explicit

  args:
    - --enable-leader-election
    - --leader-election-id=ibm-redis-operator
```

| Parameter | Type | Default | Description |
|---|---|---|---|
| `operator.name` | string | `ibm-redis-operator` | Deployment name and `control-plane` selector label |
| `operator.resources.limits.cpu` | string | `750m` | CPU limit |
| `operator.resources.limits.memory` | string | `1536Mi` | Memory limit |
| `operator.resources.limits.ephemeral-storage` | string | `750Mi` | Ephemeral storage limit |
| `operator.resources.requests.cpu` | string | `100m` | CPU request |
| `operator.resources.requests.memory` | string | `256Mi` | Memory request |
| `operator.resources.requests.ephemeral-storage` | string | `250Mi` | Ephemeral storage request |
| `operator.securityContext.runAsNonRoot` | boolean | `true` | Pod must not run as root |
| `operator.securityContext.runAsUser` | integer | _(unset)_ | Explicit UID for the pod |
| `operator.securityContext.fsGroup` | integer | _(unset)_ | Volume filesystem group ID |
| `operator.containerSecurityContext.allowPrivilegeEscalation` | boolean | `false` | Prevent privilege escalation |
| `operator.containerSecurityContext.privileged` | boolean | `false` | Do not run as privileged |
| `operator.containerSecurityContext.readOnlyRootFilesystem` | boolean | `false` | Operator writes to `/tmp` — keep `false` |
| `operator.containerSecurityContext.runAsNonRoot` | boolean | `true` | Container must not run as root |
| `operator.env.ansibleGathering` | string | `explicit` | Ansible facts gathering mode (`smart`, `explicit`, `implicit`) |
| `operator.args` | list | `[--enable-leader-election, ...]` | CLI arguments passed to the operator binary |

---

### Health Probes

```yaml
livenessProbe:
  httpGet:
    path: /healthz
    port: 6789
  initialDelaySeconds: 15
  periodSeconds: 20
  timeoutSeconds: 5
  successThreshold: 1
  failureThreshold: 3

readinessProbe:
  httpGet:
    path: /readyz
    port: 6789
  initialDelaySeconds: 5
  periodSeconds: 10
  timeoutSeconds: 5
  successThreshold: 1
  failureThreshold: 3
```

| Parameter | Type | Default | Description |
|---|---|---|---|
| `livenessProbe.initialDelaySeconds` | integer | `15` | Seconds before first liveness check |
| `livenessProbe.periodSeconds` | integer | `20` | Interval between liveness checks |
| `livenessProbe.timeoutSeconds` | integer | `5` | Check timeout |
| `livenessProbe.failureThreshold` | integer | `3` | Consecutive failures before restart |
| `readinessProbe.initialDelaySeconds` | integer | `5` | Seconds before first readiness check |
| `readinessProbe.periodSeconds` | integer | `10` | Interval between readiness checks |
| `readinessProbe.timeoutSeconds` | integer | `5` | Check timeout |
| `readinessProbe.failureThreshold` | integer | `3` | Consecutive failures before unready |

---

### Node Affinity

```yaml
affinity:
  nodeAffinity:
    requiredDuringSchedulingIgnoredDuringExecution:
      nodeSelectorTerms:
        - matchExpressions:
            - key: kubernetes.io/arch
              operator: In
              values:
                - amd64
                - s390x
                - ppc64le
    preferredDuringSchedulingIgnoredDuringExecution:
      - weight: 3
        preference:
          matchExpressions:
            - key: kubernetes.io/arch
              operator: In
              values:
                - amd64
                - s390x
                - ppc64le
```

| Parameter | Type | Description |
|---|---|---|
| `affinity` | object | Full Kubernetes affinity spec; override to restrict scheduling |

---

### Node Selector

```yaml
nodeSelector: {}
```

| Parameter | Type | Default | Description |
|---|---|---|---|
| `nodeSelector` | object | `{}` | Additional node label selectors |

---

### Tolerations

```yaml
tolerations: []
```

| Parameter | Type | Default | Description |
|---|---|---|---|
| `tolerations` | list | `[]` | Kubernetes tolerations for tainted nodes |

---

### Pod Annotations

```yaml
podAnnotations:
  cloudpakId: "eb9998dcc5d24e3eb5b6fb488f750fe2"
  cloudpakName: "IBM Cloud Pak for Data"
  productID: "eb9998dcc5d24e3eb5b6fb488f750fe2"
  productMetric: "FREE"
  productName: "IBM CloudPak Redis"
```

| Parameter | Type | Default | Description |
|---|---|---|---|
| `podAnnotations` | object | _(see above)_ | Annotations added to operator pods |

---

### Descriptor Labels

```yaml
descriptorLabels:
  instance: ibm-redis
  managedBy: ibm-redis
  name: ibm-redis
```

| Parameter | Type | Default | Description |
|---|---|---|---|
| `descriptorLabels.instance` | string | `ibm-redis` | `app.kubernetes.io/instance` label value |
| `descriptorLabels.managedBy` | string | `ibm-redis` | `app.kubernetes.io/managed-by` label value |
| `descriptorLabels.name` | string | `ibm-redis` | `app.kubernetes.io/name` label value |

---

### Labels

```yaml
labels:
  release: "1.4.0"
```

| Parameter | Type | Default | Description |
|---|---|---|---|
| `labels` | object | `{release: "1.4.0"}` | Additional labels applied to all chart resources |

---

### Network Policy Labels

```yaml
networkPolicyLabels: {}
```

| Parameter | Type | Default | Description |
|---|---|---|---|
| `networkPolicyLabels` | object | `{}` | Labels added to pods for network policy targeting |

---

### Vault Integration

```yaml
vault:
  enabled: false
  secretsMountPath: /tmp/secrets
  certificatesMountPath: /tmp/certificates
  secrets: []
```

| Parameter | Type | Default | Description |
|---|---|---|---|
| `vault.enabled` | boolean | `false` | Mount secrets from HashiCorp Vault via CSI driver |
| `vault.secretsMountPath` | string | `/tmp/secrets` | Mount path for credential secrets |
| `vault.certificatesMountPath` | string | `/tmp/certificates` | Mount path for TLS certificate secrets |
| `vault.secrets` | list | `[]` | Secrets to mount; each entry needs `name` and `type` (`secret`\|`certificate`) |

**Example:**
```yaml
vault:
  enabled: true
  secrets:
    - name: ibm-redis-secret
      type: secret
    - name: ibm-redis-ssl-secret
      type: certificate
```

---

## 📝 Configuration Examples

### Minimal Configuration

```yaml
imagePullSecrets:
  - name: ibm-entitlement-key
```

### Development Environment

```yaml
image:
  tag: "1.4.0"
  pullPolicy: Always

operator:
  resources:
    limits:
      cpu: 500m
      memory: 512Mi
    requests:
      cpu: 50m
      memory: 128Mi

replicaCount: 1
```

### Production Environment

```yaml
image:
  repository: icr.io/cpopen/ibm-redis-cp-operator
  digest: "sha256:501f90a1fde4f1a8c5097daff37e103900d9b67145820853146b03015d805c02"
  pullPolicy: IfNotPresent

operator:
  resources:
    limits:
      cpu: 750m
      memory: 1536Mi
      ephemeral-storage: 750Mi
    requests:
      cpu: 100m
      memory: 256Mi
      ephemeral-storage: 250Mi

labels:
  release: "1.4.0"
  environment: "production"
```

### Vault-Backed Secrets

```yaml
vault:
  enabled: true
  secretsMountPath: /tmp/secrets
  certificatesMountPath: /tmp/certificates
  secrets:
    - name: ibm-redis-secret
      type: secret
    - name: ibm-redis-ssl-secret
      type: certificate
```

---

## 📞 Support

- Documentation: https://www.ibm.com/docs/SSL4SY_26.0.0/com.ibm.p8.containers.doc/containers.html
- GitHub Issues: https://github.com/ibm-ecm/ibm-content-cortex-containers/issues
- Email: ecm-container-service@ibm.com
