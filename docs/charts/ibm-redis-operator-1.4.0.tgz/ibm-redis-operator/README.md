# IBM Redis Operator Helm Chart

> Kubernetes operator for deploying and managing IBM Redis CP — the high-availability Redis cache layer for IBM Content Cortex and IBM Cloud Pak for Data.

## 📋 Table of Contents

- [Overview](#overview)
- [Prerequisites](#prerequisites)
- [Quick Start](#quick-start)
- [Installation](#installation)
- [Configuration](#configuration)
- [Post-Installation](#post-installation)
- [Upgrading](#upgrading)
- [Uninstallation](#uninstallation)
- [Troubleshooting](#troubleshooting)
- [Advanced Configuration](#advanced-configuration)
- [Useful Helm Commands](#useful-helm-commands)
- [Support](#support)

---

## 🎯 Overview

The **IBM Redis Operator** Helm chart deploys and manages the lifecycle of the IBM Redis CP operator in a Kubernetes or OpenShift cluster. The operator manages `Rediscp` Custom Resources and provisions the full Redis sentinel cluster — Redis pods, HAProxy load balancer, persistent volumes, and supporting RBAC — all within a single namespace.

### What IBM Redis CP provides

- **High-availability Redis** with sentinel failover
- **HAProxy** load-balanced entry point for Redis clients
- **Persistent storage** for Redis data using standard Kubernetes PVCs
- **Namespace-scoped** deployment compatible with OpenShift multi-tenancy
- **Credential secret management** via Kubernetes secrets or HashiCorp Vault

---

## ✅ Prerequisites

### Required

| Requirement | Version |
|---|---|
| Kubernetes | 1.25+ |
| OpenShift | 4.10+ (optional) |
| Helm | 3.8+ |
| IBM Entitlement Key | Valid key with access to `icr.io/cpopen` |

### Recommended

- `kubectl` configured to reach your target cluster
- Cluster admin permissions to install CRDs

### Network Requirements

The operator pod requires egress to:
- `icr.io` — IBM Container Registry for image pulls
- Kubernetes API server — for operator reconciliation

---

## 🚀 Quick Start

```bash
# 1. Add the Helm repository
helm repo add ibm-ccx https://ibm-ecm.github.io/ibm-content-cortex-containers
helm repo update

# 2. Create namespace
kubectl create namespace ibm-redis

# 3. Create entitlement key secret
kubectl create secret docker-registry ibm-entitlement-key \
  --docker-server=icr.io \
  --docker-username=iamapikey \
  --docker-password=<YOUR_ENTITLEMENT_KEY> \
  -n ibm-redis

# 4. Install the operator
helm install ibm-redis-operator ibm-ccx/ibm-redis-operator \
  -n ibm-redis

# 5. Verify
kubectl get pods -n ibm-redis
```

---

## 📦 Installation

### Step 1: Create Namespace

```bash
kubectl create namespace ibm-redis
```

### Step 2: Create Image Pull Secret

```bash
kubectl create secret docker-registry ibm-entitlement-key \
  --docker-server=icr.io \
  --docker-username=iamapikey \
  --docker-password=<YOUR_ENTITLEMENT_KEY> \
  -n ibm-redis
```

### Step 3: Install the Chart

**Minimal install (defaults only):**
```bash
helm install ibm-redis-operator ibm-ccx/ibm-redis-operator \
  -n ibm-redis
```

**Install with a custom values file:**
```bash
helm install ibm-redis-operator ibm-ccx/ibm-redis-operator \
  -n ibm-redis \
  -f my-values.yaml
```

**Install with inline overrides:**
```bash
helm install ibm-redis-operator ibm-ccx/ibm-redis-operator \
  -n ibm-redis \
  --set image.tag=1.4.0 \
  --set operator.resources.limits.memory=2Gi
```

**Skip CRD installation (if already present):**
```bash
helm install ibm-redis-operator ibm-ccx/ibm-redis-operator \
  -n ibm-redis \
  --skip-crds
```

### Step 4: Verify Installation

```bash
# Operator pod running
kubectl get pods -n ibm-redis -l control-plane=ibm-redis-operator

# Deployment ready
kubectl get deployment ibm-redis-operator -n ibm-redis

# CRD installed
kubectl get crd rediscps.redis.ibm.com

# Run chart tests
helm test ibm-redis-operator -n ibm-redis
```

---

## ⚙️ Configuration

### Key Configuration Parameters

| Parameter | Default | Description |
|---|---|---|
| `image.repository` | `icr.io/cpopen/ibm-redis-cp-operator` | Operator image repository |
| `image.digest` | `sha256:cb34b47…` | Operator image digest |
| `image.tag` | `""` | Override image tag (uses digest if empty) |
| `replicaCount` | `1` | Operator replicas |
| `serviceAccount.name` | `ibm-redis-operator-sa` | Service account name |
| `operator.resources.limits.cpu` | `750m` | CPU limit for operator container |
| `operator.resources.limits.memory` | `1536Mi` | Memory limit for operator container |
| `operator.env.ansibleGathering` | `explicit` | Ansible facts gathering mode |

### Image Configuration

The chart supports two image reference modes:

**Using digest (default — recommended for production):**
```yaml
image:
  repository: icr.io/cpopen/ibm-redis-cp-operator
  digest: "sha256:501f90a1fde4f1a8c5097daff37e103900d9b67145820853146b03015d805c02"
  tag: ""
```

**Using tag:**
```yaml
image:
  repository: icr.io/cpopen/ibm-redis-cp-operator
  tag: "1.4.0"
  digest: ""   # ignored when tag is set
```

### Resource Configuration

Adjust resources to match your cluster capacity:

```yaml
operator:
  resources:
    limits:
      cpu: 750m
      memory: 1536Mi
      ephemeral-storage: 750Mi
    requests:
      cpu: 100m
      memory: 256Mi
      ephemeral-storage: 250Mi
```

### Security Configuration

```yaml
operator:
  # Pod-level security context
  securityContext:
    runAsNonRoot: true
    # runAsUser: 1001
    # fsGroup: 0

  # Container-level security context
  containerSecurityContext:
    allowPrivilegeEscalation: false
    privileged: false
    readOnlyRootFilesystem: false   # operator writes to /tmp
    runAsNonRoot: true
    capabilities:
      drop:
        - ALL
```

### Node Architecture

By default the operator targets `amd64`, `s390x`, and `ppc64le` nodes:

```yaml
affinity:
  nodeAffinity:
    requiredDuringSchedulingIgnoredDuringExecution:
      nodeSelectorTerms:
        - matchExpressions:
            - key: kubernetes.io/arch
              operator: In
              values:
                - amd64
                - s390x
                - ppc64le
```

### Vault Integration for Secrets

```yaml
vault:
  enabled: true
  secretsMountPath: /tmp/secrets
  certificatesMountPath: /tmp/certificates
  secrets:
    - name: ibm-redis-secret
      type: secret
    - name: ibm-redis-ssl-secret
      type: certificate
```

### Custom Values File Example

```yaml
# custom-values.yaml
image:
  repository: icr.io/cpopen/ibm-redis-cp-operator
  digest: "sha256:501f90a1fde4f1a8c5097daff37e103900d9b67145820853146b03015d805c02"

imagePullSecrets:
  - name: ibm-entitlement-key

operator:
  name: ibm-redis-operator
  resources:
    limits:
      cpu: 1
      memory: 2Gi
      ephemeral-storage: 1Gi
    requests:
      cpu: 200m
      memory: 512Mi
      ephemeral-storage: 250Mi

labels:
  release: "1.4.0"
  environment: "production"
```

---

## 🔄 Post-Installation

### 1. Verify Operator Status

```bash
kubectl get deployment ibm-redis-operator -n ibm-redis
kubectl get pods -n ibm-redis -l control-plane=ibm-redis-operator
```

### 2. Verify CRD Installation

```bash
kubectl get crd rediscps.redis.ibm.com
kubectl describe crd rediscps.redis.ibm.com
```

### 3. Generate and Apply the Redis CR

> **Recommended**: Use the IBM Content Cortex prerequisites script to generate the Custom Resource and all supporting artifacts automatically. The script handles property collection, secret generation, and CR templating for you.

From the `scripts/` directory:

```bash
# Step 1 — Gather deployment configuration interactively
python3 prerequisites.py gather

# Step 2 — Generate all deployment artifacts (CR YAML, Kubernetes secrets, SQL scripts)
python3 prerequisites.py generate

# Step 3 — Validate external dependencies (certificates, databases, LDAP/IDP)
python3 prerequisites.py validate
```

Generated artifacts are written to `scripts/generatedFiles/<namespace>/`. Apply the generated Redis CR:

```bash
kubectl apply -f scripts/generatedFiles/<namespace>/ibm_redis_cr.yaml -n ibm-redis
kubectl get rediscps -n ibm-redis
```

If you need to deploy without the prerequisites script, you can apply the reference CR directly:

```bash
kubectl apply -f descriptors/redis/ibm_redis_cr.yaml -n ibm-redis
kubectl get rediscps -n ibm-redis
```

### 4. Monitor Deployment Progress

```bash
kubectl get pods -n ibm-redis -w
kubectl logs -n ibm-redis -l control-plane=ibm-redis-operator -f
```

---

## 📈 Upgrading

### Upgrade the Operator

```bash
helm repo update
helm upgrade ibm-redis-operator ibm-ccx/ibm-redis-operator \
  -n ibm-redis \
  -f my-values.yaml
```

### Verify Upgrade

```bash
kubectl get deployment ibm-redis-operator -n ibm-redis \
  -o jsonpath='{.spec.template.spec.containers[0].image}'
```

### Rollback if Needed

```bash
helm rollback ibm-redis-operator -n ibm-redis
helm history ibm-redis-operator -n ibm-redis
```

---

## 🗑️ Uninstallation

### Standard Uninstall

```bash
helm uninstall ibm-redis-operator -n ibm-redis
```

> ⚠️ CRDs are **not** deleted automatically to prevent data loss.

### Complete Cleanup

```bash
# Delete any Redis CR instances first
kubectl delete rediscps --all -n ibm-redis

# Uninstall chart
helm uninstall ibm-redis-operator -n ibm-redis

# Manually remove CRD (destructive — removes all Rediscp data)
kubectl delete crd rediscps.redis.ibm.com

# Remove namespace
kubectl delete namespace ibm-redis
```

---

## 🔧 Troubleshooting

### Operator Not Starting

```bash
# Describe the pod for events
kubectl describe pod -n ibm-redis -l control-plane=ibm-redis-operator

# Check previous container logs
kubectl logs -n ibm-redis -l control-plane=ibm-redis-operator --previous

# Check image pull status
kubectl get events -n ibm-redis --sort-by='.lastTimestamp' | grep -i pull
```

### CRD Issues

```bash
# Verify CRD is installed
kubectl get crd rediscps.redis.ibm.com

# Re-install CRD manually
kubectl apply -f helm-charts/ibm-redis-operator/crds/rediscps.redis.ibm.com.yaml
```

### RBAC Issues

```bash
kubectl get role ibm-redis-operator-role -n ibm-redis -o yaml
kubectl get rolebinding ibm-redis-operator-rolebinding -n ibm-redis -o yaml
kubectl auth can-i list rediscps --as=system:serviceaccount:ibm-redis:ibm-redis-operator-sa -n ibm-redis
```

### Check All Resources

```bash
kubectl get all -n ibm-redis
kubectl get serviceaccount,role,rolebinding -n ibm-redis
```

---

## 🎓 Advanced Configuration

### Using a Private Registry Mirror

```yaml
image:
  repository: my-registry.example.com/cpopen/ibm-redis-operator
  tag: "1.4.0"

imagePullSecrets:
  - name: my-registry-secret
```

### Air-Gapped Deployment

```bash
# Mirror image
skopeo copy \
  docker://icr.io/cpopen/ibm-redis-cp-operator@sha256:cb34b47… \
  docker://my-registry.example.com/cpopen/ibm-redis-operator:1.4.0

# Install with mirror
helm install ibm-redis-operator ibm-ccx/ibm-redis-operator \
  -n ibm-redis \
  --set image.repository=my-registry.example.com/cpopen/ibm-redis-operator \
  --set image.tag=1.4.0
```

### Tolerations for Dedicated Nodes

```yaml
tolerations:
  - key: "dedicated"
    operator: "Equal"
    value: "redis"
    effect: "NoSchedule"

nodeSelector:
  node-role.kubernetes.io/redis: "true"
```

---

## 📚 Useful Helm Commands

```bash
# Render chart locally without installing
helm template ibm-redis-operator ibm-ccx/ibm-redis-operator -n ibm-redis

# Validate values against schema
helm lint helm-charts/ibm-redis-operator

# Show computed values
helm get values ibm-redis-operator -n ibm-redis

# Show all resources deployed
helm get manifest ibm-redis-operator -n ibm-redis

# List releases
helm list -n ibm-redis
```

---

## 📞 Support

### Documentation
- [IBM Content Cortex Documentation](https://www.ibm.com/docs/SSL4SY_26.0.0/com.ibm.p8.containers.doc/containers.html)

### Getting Help
- Open an issue at [GitHub](https://github.com/ibm-ecm/ibm-content-cortex-containers/issues)
- Contact: ecm-container-service@ibm.com

## 📄 License

Licensed Materials - Property of IBM  
(C) Copyright IBM Corp. 2026. All Rights Reserved.
