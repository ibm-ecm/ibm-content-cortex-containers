# IBM Content Cortex WDU Services Operator Helm Chart

[![Helm Version](https://img.shields.io/badge/Helm-v4.0+-blue.svg)](https://helm.sh)
[![Kubernetes Version](https://img.shields.io/badge/Kubernetes-v1.24+-blue.svg)](https://kubernetes.io)
[![OpenShift Version](https://img.shields.io/badge/OpenShift-v4.12+-red.svg)](https://www.openshift.com)
[![Chart Version](https://img.shields.io/badge/Chart-26.1.0-green.svg)](./Chart.yaml)

## 📋 Table of Contents

- [Overview](#overview)
- [Prerequisites](#prerequisites)
- [Quick Start](#quick-start)
- [Installation](#installation)
- [Configuration](#configuration)
- [Post-Installation](#post-installation)
- [Upgrading](#upgrading)
- [Uninstallation](#uninstallation)
- [Troubleshooting](#troubleshooting)
- [Advanced Configuration](#advanced-configuration)
- [Useful Helm Commands](#useful-helm-commands)
- [Support](#support)

## 🎯 Overview

The **IBM Content Cortex WDU Services Operator** Helm chart deploys the operator for **IBM Workflow and Document Understanding (WDU) Services** on Kubernetes and OpenShift platforms. The operator enables intelligent document understanding and workflow automation for enterprise content management, providing:

- **Intelligent Document Understanding**: AI-powered extraction and classification of content from enterprise documents
- **Workflow Orchestration**: Automated workflow execution driven by document content and metadata
- **Secure Credential Management**: Kubernetes secrets for secure credential management
- **Cloud-Native Deployment**: Kubernetes-native architecture with operator pattern
- **Namespace-scoped RBAC**: Fine-grained access control for multi-tenant environments

### What is IBM WDU Services?

IBM WDU (Workflow and Document Understanding) Services is a component of the IBM Content Cortex platform that enhances enterprise content management with automated document understanding and workflow capabilities:

1. **Document Understanding**: Extracts structured data and insights from unstructured documents using AI-powered analysis
2. **Classification Engine**: Automatically classifies and routes documents based on content recognition
3. **Workflow Integration**: Connects document understanding results to downstream IBM Content Platform Engine workflows

**Key Capabilities:**
- **Intelligent Extraction**: Extract key fields, tables, and entities from complex documents
- **Automated Classification**: Route and categorize documents without manual intervention
- **Workflow Trigger Automation**: Initiate content workflows based on document understanding results
- **Enterprise Integration**: Deep integration with IBM Content Platform Engine and Content Navigator

## ✅ Prerequisites

Before installing this chart, ensure you have:

### Required

- **Kubernetes 1.24+** or **OpenShift 4.12+**
- **Helm 4.0+** installed and configured
- **IBM Entitlement Key** from [IBM Container Library](https://myibm.ibm.com/products-services/containerlibrary)
- **Namespace** created for the deployment
- **Minimum Resources**: 10m CPU and 64Mi memory available per operator replica
- **IBM Content Cortex** (Content Operator) deployed in the same namespace

### Recommended

- **Network Policies**: Configured for appropriate egress access

## 🚀 Quick Start

```bash
# Add the IBM Content Cortex Helm repository
helm repo add ibm-content-cortex https://ibm-ecm.github.io/ibm-content-cortex-containers
helm repo update

# Create namespace
kubectl create namespace ibm-ccx

# Create IBM entitlement key secret
kubectl create secret docker-registry ibm-entitlement-key \
  --docker-server=icr.io \
  --docker-username=iamapikey \
  --docker-password=<YOUR_ENTITLEMENT_KEY> \
  -n ibm-ccx

# Install the chart
helm install ibm-wdu-operator ibm-content-cortex/ibm-ccx-wdu-services-operator \
  -n ibm-ccx
```

## 📦 Installation

### Step 1: Create Namespace

```bash
kubectl create namespace ibm-ccx
```

### Step 2: Create Image Pull Secret

```bash
kubectl create secret docker-registry ibm-entitlement-key \
  --docker-server=icr.io \
  --docker-username=iamapikey \
  --docker-password=<YOUR_ENTITLEMENT_KEY> \
  -n ibm-ccx
```

### Step 3: Install the Chart

```bash
# Using default values
helm install ibm-wdu-operator ibm-content-cortex/ibm-ccx-wdu-services-operator \
  -n ibm-ccx

# Using a custom values file
helm install ibm-wdu-operator ibm-content-cortex/ibm-ccx-wdu-services-operator \
  -f my-values.yaml \
  -n ibm-ccx
```

### Step 4: Verify Installation

```bash
# Check deployment
kubectl get deployment ibm-ccx-wdu-services-operator -n ibm-ccx

# Check pods
kubectl get pods -n ibm-ccx -l control-plane=ibm-ccx-wdu-services-operator

# Check CRD
kubectl get crd ccxwduservices.ccxwdu.operator.ibm.com
```

## ⚙️ Configuration

### Key Configuration Parameters

| Parameter | Default | Description |
|-----------|---------|-------------|
| `image.repository` | `icr.io/cpopen/ibm-ccx-wdu-operator` | Operator image repository |
| `image.digest` | `sha256:6ff1...` | Image digest (used when tag is empty) |
| `image.tag` | `""` | Image tag override |
| `replicaCount` | `1` | Number of operator replicas |
| `operator.name` | `ibm-ccx-wdu-services-operator` | Deployment name |
| `serviceAccount.name` | `ibm-ccxwdu-services-operator-sa` | Service account name |
### Resource Configuration

```yaml
operator:
  resources:
    limits:
      cpu: 500m
      memory: 128Mi
    requests:
      cpu: 10m
      memory: 64Mi
```

### Security Configuration

```yaml
operator:
  securityContext:
    runAsNonRoot: true
  containerSecurityContext:
    allowPrivilegeEscalation: false
    privileged: false
    readOnlyRootFilesystem: true
    capabilities:
      drop:
        - ALL
```

### Custom Values File Example

```yaml
image:
  repository: icr.io/cpopen/ibm-ccx-wdu-operator
  tag: "26.1.0"
  pullPolicy: IfNotPresent

replicaCount: 1

serviceAccount:
  create: true
  name: "ibm-ccxwdu-services-operator-sa"

rbac:
  create: true

operator:
  name: ibm-ccx-wdu-services-operator
  resources:
    limits:
      cpu: 500m
      memory: 128Mi
    requests:
      cpu: 10m
      memory: 64Mi

podAnnotations:
  productID: "9c2d4f167cdb411fa3b1d787eb3c7c34"
  productName: "IBM Content Cortex Essentials"
  productMetric: "AUTHORIZED_USER"
  productVersion: "26.0.0"
```

## 🔄 Post-Installation

### 1. Verify Operator Status

```bash
kubectl get deployment ibm-ccx-wdu-services-operator -n ibm-ccx
kubectl get pods -n ibm-ccx -l control-plane=ibm-ccx-wdu-services-operator
```

### 2. Verify CRD Installation

```bash
kubectl get crd ccxwduservices.ccxwdu.operator.ibm.com
kubectl describe crd ccxwduservices.ccxwdu.operator.ibm.com
```

### 3. Generate and Apply the WDU Services CR

> **Recommended**: Use the IBM Content Cortex prerequisites script to generate the Custom Resource and all supporting artifacts automatically. The script handles property collection, secret generation, and CR templating for you.

From the `scripts/` directory:

```bash
# Step 1 — Gather deployment configuration interactively
python3 prerequisites.py gather

# Step 2 — Generate all deployment artifacts (CR YAML, Kubernetes secrets, SQL scripts)
python3 prerequisites.py generate

# Step 3 — Validate external dependencies (certificates, databases, LDAP/IDP)
python3 prerequisites.py validate
```

Generated artifacts are written to `scripts/generatedFiles/<namespace>/`. Apply the generated WDU Services CR:

```bash
kubectl apply -f scripts/generatedFiles/<namespace>/ibm_wdu_services_cr.yaml -n ibm-ccx
```

If you need to deploy without the prerequisites script, you can apply the reference CR directly:

```bash
kubectl apply -f descriptors/wdu/ibm_wdu_services_cr.yaml -n ibm-ccx
```

### 4. Monitor Deployment Progress

```bash
kubectl get ccxwduservices -n ibm-ccx
kubectl describe ccxwduservices -n ibm-ccx
```

## 📈 Upgrading

### Upgrade the Operator

```bash
helm repo update
helm upgrade ibm-wdu-operator ibm-content-cortex/ibm-ccx-wdu-services-operator \
  -n ibm-ccx
```

### Rollback if Needed

```bash
helm rollback ibm-wdu-operator -n ibm-ccx
```

## 🗑️ Uninstallation

### Standard Uninstall

```bash
helm uninstall ibm-wdu-operator -n ibm-ccx
```

### Complete Cleanup

```bash
# Uninstall chart
helm uninstall ibm-wdu-operator -n ibm-ccx

# Delete CRD (WARNING: this deletes all WDU CR instances)
kubectl delete crd ccxwduservices.ccxwdu.operator.ibm.com

# Delete namespace (optional)
kubectl delete namespace ibm-ccx
```

## 🔧 Troubleshooting

### Operator Not Starting

```bash
# Check pod status
kubectl describe pod -n ibm-ccx -l control-plane=ibm-ccx-wdu-services-operator

# Check logs
kubectl logs -n ibm-ccx -l control-plane=ibm-ccx-wdu-services-operator

# Check previous logs if pod restarted
kubectl logs -n ibm-ccx -l control-plane=ibm-ccx-wdu-services-operator --previous
```

### Image Pull Errors

```bash
# Verify entitlement key secret
kubectl get secret ibm-entitlement-key -n ibm-ccx

# Check events
kubectl get events -n ibm-ccx --sort-by='.lastTimestamp'
```

### CRD Issues

```bash
# Reinstall CRD manually
kubectl apply -f descriptors/wdu/ccxwduservices_v1_ccxwduservices_crd.yaml

# Verify CRD schema
kubectl get crd ccxwduservices.ccxwdu.operator.ibm.com -o yaml
```

## 🎓 Advanced Configuration

### Using Private Registry

```yaml
image:
  repository: my-registry.example.com/ibm-ccx-wdu-operator
  tag: "26.1.0"

imagePullSecrets:
  - name: my-registry-secret
```

### Air-Gapped Deployment

```bash
# Pull and push image to private registry
docker pull icr.io/cpopen/ibm-ccx-wdu-operator:26.1.0
docker tag icr.io/cpopen/ibm-ccx-wdu-operator:26.1.0 my-registry.example.com/ibm-ccx-wdu-operator:26.1.0
docker push my-registry.example.com/ibm-ccx-wdu-operator:26.1.0

# Install using private registry
helm install ibm-wdu-operator ibm-content-cortex/ibm-ccx-wdu-services-operator \
  --set image.repository=my-registry.example.com/ibm-ccx-wdu-operator \
  --set image.tag=26.1.0 \
  -n ibm-ccx
```

## 📚 Useful Helm Commands

```bash
# List all releases
helm list -n ibm-ccx

# Show release status
helm status ibm-wdu-operator -n ibm-ccx

# Show current values
helm get values ibm-wdu-operator -n ibm-ccx

# Dry-run install
helm install ibm-wdu-operator ibm-content-cortex/ibm-ccx-wdu-services-operator \
  --dry-run --debug -n ibm-ccx

# Lint chart locally
helm lint helm-charts/wdu-operator/

# Run chart tests
helm test ibm-wdu-operator -n ibm-ccx
```

## 📞 Support

### Documentation
- [IBM Content Cortex Documentation](https://www.ibm.com/docs/SSL4SY_26.0.0/com.ibm.p8.containers.doc/containers.html)
- [Chart Repository](https://ibm-ecm.github.io/ibm-content-cortex-containers)

### Getting Help
- Contact: ecm-container-service@ibm.com
- GitHub: https://github.com/ibm-ecm/ibm-content-cortex-containers

## 📄 License

Licensed Materials - Property of IBM

(C) Copyright IBM Corp. 2026. All Rights Reserved.

US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
