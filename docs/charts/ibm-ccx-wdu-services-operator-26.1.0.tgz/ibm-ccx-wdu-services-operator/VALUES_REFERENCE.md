# IBM Content Cortex WDU Services Operator - Values Reference Guide

[![Chart Version](https://img.shields.io/badge/Chart-26.1.0-green.svg)](./Chart.yaml)
[![Helm Version](https://img.shields.io/badge/Helm-v4.0+-blue.svg)](https://helm.sh)

## 📋 Table of Contents

- [Overview](#overview)
- [Quick Reference](#quick-reference)
- [Complete Values Reference](#complete-values-reference)
- [Configuration Examples](#configuration-examples)
- [Validation](#validation)

## 🎯 Overview

This document provides a comprehensive reference for all configuration values available in the IBM Content Cortex WDU Services Operator Helm chart. Each parameter is documented with its purpose, type, default value, and usage examples.

## 🚀 Quick Reference

### Essential Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `image.repository` | string | `icr.io/cpopen/ibm-ccx-wdu-operator` | Operator image repository |
| `image.tag` | string | `""` | Image tag (overrides digest) |
| `image.digest` | string | `sha256:6ff1...` | Image digest (used when tag is empty) |
| `replicaCount` | integer | `1` | Number of operator replicas |
| `operator.name` | string | `ibm-ccx-wdu-services-operator` | Operator deployment name |
| `operator.args` | array | `[--leader-elect, --health-probe-bind-address=:8081]` | Operator arguments |

### Resource Defaults

| Component | CPU Request | CPU Limit | Memory Request | Memory Limit |
|-----------|-------------|-----------|----------------|--------------|
| Operator | 10m | 500m | 64Mi | 128Mi |

## 📖 Complete Values Reference

### Name Overrides

```yaml
# Override the chart name
# Type: string
# Default: ""
nameOverride: ""

# Override the full name (release-name + chart-name)
# Type: string
# Default: ""
fullnameOverride: ""
```

---

### Image Configuration

```yaml
image:
  # Image repository for the Content Cortex WDU Services operator
  # Type: string
  # Default: icr.io/cpopen/ibm-ccx-wdu-operator
  # Required: Yes
  repository: icr.io/cpopen/ibm-ccx-wdu-operator

  # Default image digest used when tag is not provided
  # Type: string
  # Required: No (used as fallback)
  digest: "sha256:6ff16682b5219ec76f8406a0620d5daa3b4eb437f745cf38464199005ddb40cf"

  # Optional image tag override
  # Type: string
  # Default: ""
  # Note: When set, uses repository:tag instead of repository@digest
  tag: ""

  # Image pull policy
  # Type: string
  # Default: IfNotPresent
  # Options: Always, IfNotPresent, Never
  pullPolicy: IfNotPresent
```

---

### Image Pull Secrets

```yaml
# Secrets for accessing the container registry
# Type: array
# Default: [{name: ibm-entitlement-key}]
imagePullSecrets:
  - name: ibm-entitlement-key
```

---

### Replica Count

```yaml
# Number of operator replicas
# Type: integer
# Default: 1
# Note: Operators typically run as a single replica
replicaCount: 1
```

---

### Service Account

```yaml
serviceAccount:
  # Whether to create a service account
  # Type: boolean
  # Default: true
  create: true

  # Service account name
  # Type: string
  # Default: ibm-ccxwdu-services-operator-sa
  name: "ibm-ccxwdu-services-operator-sa"
```

---

### RBAC Configuration

```yaml
rbac:
  # Whether to create RBAC resources (Role, RoleBinding)
  # Type: boolean
  # Default: true
  create: true
```

---

### Operator Configuration

```yaml
operator:
  # Deployment name
  # Type: string
  # Default: ibm-ccx-wdu-services-operator
  name: ibm-ccx-wdu-services-operator

  # Resource limits and requests
  resources:
    limits:
      cpu: 500m
      memory: 128Mi
    requests:
      cpu: 10m
      memory: 64Mi

  # Pod security context
  securityContext:
    runAsNonRoot: true
    # runAsUser: 1001
    # fsGroup: 0

  # Container security context
  containerSecurityContext:
    allowPrivilegeEscalation: false
    privileged: false
    readOnlyRootFilesystem: true
    capabilities:
      drop:
        - ALL

  # Operator command-line arguments
  args:
    - --leader-elect
    - --health-probe-bind-address=:8081
```

---

### Health Probes

```yaml
livenessProbe:
  httpGet:
    path: /healthz
    port: 8081
  initialDelaySeconds: 15
  periodSeconds: 20
  timeoutSeconds: 5
  successThreshold: 1
  failureThreshold: 3

readinessProbe:
  httpGet:
    path: /readyz
    port: 8081
  initialDelaySeconds: 5
  periodSeconds: 10
  timeoutSeconds: 5
  successThreshold: 1
  failureThreshold: 3
```

---

### Node Affinity

```yaml
affinity:
  nodeAffinity:
    requiredDuringSchedulingIgnoredDuringExecution:
      nodeSelectorTerms:
        - matchExpressions:
            - key: kubernetes.io/arch
              operator: In
              values:
                - amd64
    preferredDuringSchedulingIgnoredDuringExecution:
      - weight: 3
        preference:
          matchExpressions:
            - key: kubernetes.io/arch
              operator: In
              values:
                - amd64
```

---

### Pod Annotations

```yaml
podAnnotations:
  kubectl.kubernetes.io/default-container: "manager"
  productID: "9c2d4f167cdb411fa3b1d787eb3c7c34"
  productName: "IBM Content Cortex Essentials"
  productMetric: "AUTHORIZED_USER"
  productChargedContainers: ""
  productVersion: "26.0.0"
```

---

### Descriptor Labels

```yaml
descriptorLabels:
  instance: ibm-ccx-wdu-services
  managedBy: ibm-ccx-wdu-services
  name: ibm-ccx-wdu-services
```

---

### Common Labels

```yaml
labels:
  control-plane: ibm-ccx-wdu-services-operator
  release: "26.1.0"
```

---

### Network Policy Labels

```yaml
networkPolicyLabels:
  com.ibm.ccxai.networking/egress-allow-all: "true"
  com.ibm.ccxai.networking/egress-allow-k8s-services: "true"
  com.ibm.ccxai.networking/egress-allow-same-namespace: "true"
  com.ibm.ccxai.networking/egress-deny-all: "true"
```

---

## 📝 Configuration Examples

### Minimal Configuration

```yaml
image:
  repository: icr.io/cpopen/ibm-ccx-wdu-operator
  digest: "sha256:6ff16682b5219ec76f8406a0620d5daa3b4eb437f745cf38464199005ddb40cf"

replicaCount: 1

serviceAccount:
  create: true
  name: "ibm-ccxwdu-services-operator-sa"
```

### Production Environment

```yaml
image:
  repository: icr.io/cpopen/ibm-ccx-wdu-operator
  digest: "sha256:6ff16682b5219ec76f8406a0620d5daa3b4eb437f745cf38464199005ddb40cf"
  pullPolicy: IfNotPresent

replicaCount: 1

operator:
  name: ibm-ccx-wdu-services-operator
  resources:
    limits:
      cpu: 500m
      memory: 256Mi
    requests:
      cpu: 50m
      memory: 128Mi
  securityContext:
    runAsNonRoot: true
  containerSecurityContext:
    allowPrivilegeEscalation: false
    privileged: false
    readOnlyRootFilesystem: true
    capabilities:
      drop:
        - ALL
```

### Private Registry Configuration

```yaml
image:
  repository: my-registry.example.com/ibm-ccx-wdu-operator
  tag: "26.1.0"

imagePullSecrets:
  - name: my-private-registry-secret
```

---

## 🔍 Validation

### Validate Values File

```bash
# Validate syntax
helm lint helm-charts/wdu-operator/ -f my-values.yaml

# Dry run to check rendering
helm install ibm-wdu-operator helm-charts/wdu-operator/ \
  -f my-values.yaml \
  --dry-run --debug \
  -n ibm-ccx
```

### Common Validation Errors

| Error | Cause | Solution |
|-------|-------|----------|
| `operator is required` | Missing `operator` block | Add `operator.name` to values |
| `image pull failed` | Missing entitlement key | Create `ibm-entitlement-key` secret |
| `CRD not found` | Helm installed with `--skip-crds` | Apply CRD manually from `crds/` directory |

## 📞 Support

- Contact: ecm-container-service@ibm.com
- GitHub: https://github.com/ibm-ecm/ibm-content-cortex-containers
- Documentation: https://www.ibm.com/docs/SSL4SY_26.0.0/com.ibm.p8.containers.doc/containers.html
