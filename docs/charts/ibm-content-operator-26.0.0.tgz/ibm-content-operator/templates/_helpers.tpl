{{/*
Expand the name of the chart.
*/}}
{{- define "ibm-content-operator.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "ibm-content-operator.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "ibm-content-operator.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "ibm-content-operator.labels" -}}
helm.sh/chart: {{ include "ibm-content-operator.chart" . }}
{{ include "ibm-content-operator.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- range $key, $value := .Values.labels }}
{{ $key }}: {{ $value | quote }}
{{- end }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "ibm-content-operator.selectorLabels" -}}
app.kubernetes.io/name: {{ include "ibm-content-operator.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Pod labels - includes selector labels plus custom labels
*/}}
{{- define "ibm-content-operator.podLabels" -}}
{{ include "ibm-content-operator.selectorLabels" . }}
name: {{ .Values.operator.name }}
{{- range $key, $value := .Values.labels }}
{{ $key }}: {{ $value | quote }}
{{- end }}
{{- range $key, $value := .Values.networkPolicyLabels }}
{{ $key }}: {{ $value | quote }}
{{- end }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "ibm-content-operator.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "ibm-content-operator.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Return the proper image name. Use repository:tag when tag is provided;
otherwise fall back to repository@digest.
*/}}
{{- define "ibm-content-operator.image" -}}
{{- if .Values.image.tag }}
{{- printf "%s:%s" .Values.image.repository .Values.image.tag }}
{{- else }}
{{- printf "%s@%s" .Values.image.repository .Values.image.digest }}
{{- end }}
{{- end }}

{{/*
Return the proper image pull policy
*/}}
{{- define "ibm-content-operator.imagePullPolicy" -}}
{{- .Values.image.pullPolicy }}
{{- end }}