# IBM Content Operator Helm Chart - Values Reference Guide

[![Chart Version](https://img.shields.io/badge/Chart-26.0.0-green.svg)](./Chart.yaml)
[![Helm Version](https://img.shields.io/badge/Helm-v4.0+-blue.svg)](https://helm.sh)

## 📋 Table of Contents

- [Overview](#overview)
- [Quick Reference](#quick-reference)
- [Complete Values Reference](#complete-values-reference)
- [Configuration Examples](#configuration-examples)
- [Environment-Specific Configurations](#environment-specific-configurations)
- [Advanced Configurations](#advanced-configurations)
- [Validation](#validation)

## 🎯 Overview

This document provides a comprehensive reference for all configuration values available in the IBM Content Operator Helm chart. Each parameter is documented with its purpose, type, default value, and usage examples.

## 🚀 Quick Reference

### Essential Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `image.repository` | string | `icr.io/cpopen/icp4a-content-operator` | Operator image repository |
| `image.tag` | string | `""` | Image tag (overrides digest) |
| `image.digest` | string | `sha256:96c59421...` | Image digest (used when tag is empty) |
| `replicaCount` | integer | `1` | Number of operator replicas |
| `operator.name` | string | `ibm-content-operator` | Operator deployment name |
| `operator.env.fncmLicense` | string | `accept` | License acceptance (REQUIRED) |

### Resource Defaults

| Component | CPU Request | CPU Limit | Memory Request | Memory Limit |
|-----------|-------------|-----------|----------------|--------------|
| Operator | 500m | 1 | 256Mi | 2Gi |
| Init Container | 500m | 1 | 256Mi | 2Gi |

## 📖 Complete Values Reference

### Name Overrides

```yaml
# Override the chart name
# Type: string
# Default: ""
# Usage: Customize the chart name in resource names
nameOverride: ""

# Override the full name (release-name + chart-name)
# Type: string
# Default: ""
# Usage: Completely customize the full resource name
fullnameOverride: ""
```

**Examples:**
```yaml
# Use custom chart name
nameOverride: "content-op"

# Use completely custom name
fullnameOverride: "my-content-operator"
```

---

### Image Configuration

```yaml
image:
  # Image repository for the Content Cortex operator
  # Type: string
  # Default: icr.io/cpopen/icp4a-content-operator
  # Required: Yes
  repository: icr.io/cpopen/icp4a-content-operator
  
  # Default image digest used when tag is not provided
  # Type: string
  # Default: sha256:2e7018e71dbee5c114b1f82e0866d459832478d7e5f33590a5762adb1efb6295
  # Required: No (used as fallback)
  # Note: Provides immutable image reference
  digest: "sha256:2e7018e71dbee5c114b1f82e0866d459832478d7e5f33590a5762adb1efb6295"
  
  # Optional image tag override
  # Type: string
  # Default: ""
  # Required: No
  # Note: When set, uses repository:tag instead of repository@digest
  tag: ""
  
  # Image pull policy
  # Type: string
  # Default: IfNotPresent
  # Options: Always, IfNotPresent, Never
  # Required: Yes
  pullPolicy: IfNotPresent
```

**Image Reference Behavior:**
- If `tag` is set: Uses `repository:tag`
- If `tag` is empty: Uses `repository@digest`

**Examples:**
```yaml
# Use specific tag (flexible)
image:
  tag: "26.0.0"

# Use digest (immutable, recommended for production)
image:
  tag: ""
  digest: "sha256:96c59421..."

# Use private registry
image:
  repository: my-registry.company.com/icp4a-content-operator
  tag: "26.0.0"

# Always pull latest
image:
  tag: "latest"
  pullPolicy: Always
```

---

### Image Pull Secrets

```yaml
# Image pull secrets for accessing the container registry
# Type: array of objects
# Default: [{name: ibm-entitlement-key}, {name: admin.registrykey}]
# Required: Yes (secrets must exist in namespace)
# Note: Secrets must be created before chart installation
imagePullSecrets:
  - name: ibm-entitlement-key
  - name: admin.registrykey
```

**Examples:**
```yaml
# Single secret
imagePullSecrets:
  - name: ibm-entitlement-key

# Multiple secrets
imagePullSecrets:
  - name: ibm-entitlement-key
  - name: my-registry-secret
  - name: backup-registry-secret

# Private registry secret
imagePullSecrets:
  - name: my-private-registry
```

---

### Replica Count

```yaml
# Number of operator replicas
# Type: integer
# Default: 1
# Range: 1-5 (typically 1 for operators)
# Required: Yes
# Note: Multiple replicas provide high availability
replicaCount: 1
```

**Examples:**
```yaml
# Single replica (default)
replicaCount: 1

# High availability (3 replicas)
replicaCount: 3

# Maximum recommended
replicaCount: 5
```

---

### Service Account

```yaml
serviceAccount:
  # Specifies whether a service account should be created
  # Type: boolean
  # Default: true
  # Required: Yes
  create: true
  
  # The name of the service account to use
  # Type: string
  # Default: ibm-content-operator-sa
  # Required: Yes (if create is true)
  # Note: If not set and create is true, name is generated from fullname template
  name: "ibm-content-operator-sa"
```

**Examples:**
```yaml
# Create with default name
serviceAccount:
  create: true
  name: "ibm-content-operator-sa"

# Use existing service account
serviceAccount:
  create: false
  name: "existing-sa"

# Auto-generate name
serviceAccount:
  create: true
  name: ""
```

---

### RBAC Configuration

```yaml
rbac:
  # Specifies whether RBAC resources should be created
  # Type: boolean
  # Default: true
  # Required: Yes
  # Note: Creates Role and RoleBinding (namespace-scoped)
  create: true
```

**Examples:**
```yaml
# Create RBAC resources (default)
rbac:
  create: true

# Skip RBAC creation (use existing)
rbac:
  create: false
```

---

### Operator Configuration

```yaml
operator:
  # Operator name
  # Type: string
  # Default: ibm-content-operator
  # Required: Yes
  name: ibm-content-operator
  
  # Resource limits and requests for the operator container
  resources:
    limits:
      # CPU limit
      # Type: string
      # Default: "1"
      # Format: Kubernetes CPU units (e.g., "1", "500m", "2")
      cpu: "1"
      
      # Memory limit
      # Type: string
      # Default: 2Gi
      # Format: Kubernetes memory units (e.g., "2Gi", "512Mi", "4Gi")
      memory: 2Gi
    
    requests:
      # CPU request
      # Type: string
      # Default: 500m
      # Format: Kubernetes CPU units
      cpu: 500m
      
      # Memory request
      # Type: string
      # Default: 256Mi
      # Format: Kubernetes memory units
      memory: 256Mi
  
  # Security context for the operator pod
  securityContext:
    # Run as non-root user
    # Type: boolean
    # Default: true
    # Required: Yes (security best practice)
    runAsNonRoot: true
    
    # User ID to run the container as
    # Type: integer
    # Default: Not set (uses image default)
    # Optional: Uncomment to specify
    # runAsUser: 1001
    
    # File system group ID
    # Type: integer
    # Default: Not set
    # Optional: Uncomment to specify
    # fsGroup: 0
  
  # Security context for the operator container
  containerSecurityContext:
    # Allow privilege escalation
    # Type: boolean
    # Default: false
    # Required: Yes (security best practice)
    allowPrivilegeEscalation: false
    
    # Run as privileged container
    # Type: boolean
    # Default: false
    # Required: Yes (security best practice)
    privileged: false
    
    # Read-only root filesystem
    # Type: boolean
    # Default: true
    # Required: Yes (security best practice)
    readOnlyRootFilesystem: true
    
    # Capabilities to drop
    # Type: object
    # Default: Drop ALL capabilities
    # Required: Yes (security best practice)
    capabilities:
      drop:
        - ALL
    
    # Seccomp profile (OpenShift 4.12+)
    # Type: object
    # Default: Not set (commented out)
    # Optional: Uncomment for enhanced security
    # seccompProfile:
    #   type: RuntimeDefault
  
  # Init container configuration
  initContainer:
    # Security context for the init container
    securityContext:
      allowPrivilegeEscalation: false
      privileged: false
      readOnlyRootFilesystem: true
      capabilities:
        drop:
          - ALL
      # seccompProfile:
      #   type: RuntimeDefault
    
    # Resource limits and requests for the init container
    resources:
      limits:
        cpu: "1"
        memory: 2Gi
      requests:
        cpu: 500m
        memory: 256Mi
  
  # Environment variables for the operator
  env:
    # Maximum concurrent reconciles for FNCMCluster resources
    # Type: string
    # Default: "10"
    # Range: "1" to "50"
    # Note: Higher values increase throughput but use more resources
    maxConcurrentReconciles: "10"
    
    # Ansible gathering mode
    # Type: string
    # Default: smart
    # Options: smart, explicit, implicit
    # Note: Controls Ansible fact gathering behavior
    ansibleGathering: smart
    
    # License acceptance
    # Type: string
    # Default: accept
    # Options: accept, decline
    # Required: MUST be "accept" to run the operator
    fncmLicense: "accept"
  
  # Command line arguments for the operator
  # Type: array of strings
  # Default: ['--zap-encoder=console']
  # Note: Controls operator logging format
  args:
    - '--zap-encoder=console'
```

**Resource Configuration Examples:**

```yaml
# Development environment (minimal resources)
operator:
  resources:
    limits:
      cpu: "500m"
      memory: 1Gi
    requests:
      cpu: 250m
      memory: 256Mi

# Production environment (recommended)
operator:
  resources:
    limits:
      cpu: "2"
      memory: 4Gi
    requests:
      cpu: 1
      memory: 2Gi

# High-load environment
operator:
  resources:
    limits:
      cpu: "4"
      memory: 8Gi
    requests:
      cpu: 2
      memory: 4Gi
  env:
    maxConcurrentReconciles: "20"
```

**Security Context Examples:**

```yaml
# Enhanced security (OpenShift 4.12+)
operator:
  securityContext:
    runAsNonRoot: true
    runAsUser: 1001
    fsGroup: 1001
  
  containerSecurityContext:
    allowPrivilegeEscalation: false
    privileged: false
    readOnlyRootFilesystem: true
    capabilities:
      drop:
        - ALL
    seccompProfile:
      type: RuntimeDefault

# Minimal security (not recommended for production)
operator:
  securityContext:
    runAsNonRoot: true
  
  containerSecurityContext:
    allowPrivilegeEscalation: false
    privileged: false
    readOnlyRootFilesystem: true
    capabilities:
      drop:
        - ALL
```

---

### Health Probes

```yaml
# Liveness probe configuration
# Type: object
# Purpose: Determines if container needs to be restarted
livenessProbe:
  httpGet:
    path: /healthz
    port: 6789
    scheme: HTTP
  initialDelaySeconds: 15  # Wait before first probe
  periodSeconds: 20        # Probe frequency
  timeoutSeconds: 5        # Probe timeout
  successThreshold: 1      # Consecutive successes needed
  failureThreshold: 3      # Consecutive failures before restart

# Readiness probe configuration
# Type: object
# Purpose: Determines if container is ready to serve traffic
readinessProbe:
  httpGet:
    path: /readyz
    port: 6789
    scheme: HTTP
  initialDelaySeconds: 5   # Wait before first probe
  periodSeconds: 10        # Probe frequency
  timeoutSeconds: 5        # Probe timeout
  successThreshold: 1      # Consecutive successes needed
  failureThreshold: 3      # Consecutive failures before marking unready
```

**Examples:**
```yaml
# Aggressive probing (faster failure detection)
livenessProbe:
  httpGet:
    path: /healthz
    port: 6789
  initialDelaySeconds: 10
  periodSeconds: 10
  timeoutSeconds: 3
  failureThreshold: 2

# Conservative probing (slower, more tolerant)
livenessProbe:
  httpGet:
    path: /healthz
    port: 6789
  initialDelaySeconds: 30
  periodSeconds: 30
  timeoutSeconds: 10
  failureThreshold: 5
```

---

### Node Affinity

```yaml
# Node affinity configuration
# Type: object
# Purpose: Controls which nodes the operator can run on
affinity:
  nodeAffinity:
    # Required node affinity
    # Operator will ONLY run on nodes matching these expressions
    requiredDuringSchedulingIgnoredDuringExecution:
      nodeSelectorTerms:
        - matchExpressions:
            - key: kubernetes.io/arch
              operator: In
              values:
                - amd64
                - ppc64le
    
    # Preferred node affinity
    # Operator PREFERS these nodes but can run elsewhere
    preferredDuringSchedulingIgnoredDuringExecution:
      - weight: 3
        preference:
          matchExpressions:
            - key: kubernetes.io/arch
              operator: In
              values:
                - amd64
                - ppc64le
```

**Examples:**
```yaml
# AMD64 only
affinity:
  nodeAffinity:
    requiredDuringSchedulingIgnoredDuringExecution:
      nodeSelectorTerms:
        - matchExpressions:
            - key: kubernetes.io/arch
              operator: In
              values:
                - amd64

# IBM Z (s390x) only
affinity:
  nodeAffinity:
    requiredDuringSchedulingIgnoredDuringExecution:
      nodeSelectorTerms:
        - matchExpressions:
            - key: kubernetes.io/arch
              operator: In
              values:
                - s390x

# Prefer SSD nodes
affinity:
  nodeAffinity:
    preferredDuringSchedulingIgnoredDuringExecution:
      - weight: 100
        preference:
          matchExpressions:
            - key: disktype
              operator: In
              values:
                - ssd

# Pod anti-affinity (spread across nodes)
affinity:
  podAntiAffinity:
    requiredDuringSchedulingIgnoredDuringExecution:
      - labelSelector:
          matchExpressions:
            - key: name
              operator: In
              values:
                - ibm-content-operator
        topologyKey: kubernetes.io/hostname
```

---

### Node Selector

```yaml
# Additional node selectors
# Type: object (key-value pairs)
# Default: {}
# Purpose: Simple node selection based on labels
nodeSelector: {}
```

**Examples:**
```yaml
# Select nodes with specific labels
nodeSelector:
  disktype: ssd
  environment: production

# Select nodes in specific zone
nodeSelector:
  topology.kubernetes.io/zone: us-east-1a

# Select dedicated nodes
nodeSelector:
  dedicated: content-operator
```

---

### Tolerations

```yaml
# Tolerations for pod scheduling
# Type: array of objects
# Default: []
# Purpose: Allow pods to schedule on tainted nodes
tolerations: []
```

**Examples:**
```yaml
# Tolerate NoSchedule taint
tolerations:
  - key: "dedicated"
    operator: "Equal"
    value: "content"
    effect: "NoSchedule"

# Tolerate any taint on key
tolerations:
  - key: "special"
    operator: "Exists"
    effect: "NoSchedule"

# Tolerate NoExecute (allows running on draining nodes)
tolerations:
  - key: "node.kubernetes.io/not-ready"
    operator: "Exists"
    effect: "NoExecute"
    tolerationSeconds: 300
```

---

### Pod Annotations

```yaml
# Pod annotations
# Type: object (key-value pairs)
# Purpose: Add metadata to operator pods
podAnnotations:
  # IBM product identification
  productID: "9c2d4f167cdb411fa3b1d787eb3c7c34"
  productName: "IBM Content Cortex Essentials"
  productMetric: "AUTHORIZED_USER"
  productChargedContainers: ""
  productVersion: "26.0.0"
  includeSWCUpload: "true"
```

**Examples:**
```yaml
# Add custom annotations
podAnnotations:
  productID: "9c2d4f167cdb411fa3b1d787eb3c7c34"
  productName: "IBM Content Cortex Essentials"
  productVersion: "26.0.0"
  custom-annotation: "custom-value"
  backup-policy: "daily"
  monitoring: "enabled"

# Prometheus monitoring
podAnnotations:
  prometheus.io/scrape: "true"
  prometheus.io/port: "8080"
  prometheus.io/path: "/metrics"

# Vault injection
podAnnotations:
  vault.hashicorp.com/agent-inject: "true"
  vault.hashicorp.com/role: "content-operator"
```

---

### Labels

```yaml
# Common labels applied to all resources
# Type: object (key-value pairs)
# Default: {release: "26.0.0"}
# Note: app.kubernetes.io/managed-by is automatically set to "Helm"
labels:
  release: "26.0.0"
```

**Examples:**
```yaml
# Add custom labels
labels:
  release: "26.0.0"
  environment: "production"
  team: "platform"
  cost-center: "engineering"

# Compliance labels
labels:
  release: "26.0.0"
  compliance: "pci-dss"
  data-classification: "confidential"
```

---

### Network Policy Labels

```yaml
# Network policy labels for the operator pod
# Type: object (key-value pairs)
# Purpose: Control network egress using network policies
networkPolicyLabels:
  # Deny all egress by default
  com.ibm.fncm.networking/egress-deny-all: "true"
  
  # Allow egress to same namespace
  com.ibm.fncm.networking/egress-allow-same-namespace: "true"
  
  # Allow egress to Kubernetes services
  com.ibm.fncm.networking/egress-allow-k8s-services: "true"
  
  # Allow all egress (overrides deny-all)
  com.ibm.fncm.networking/egress-allow-all: "true"
  
  # Allow egress to LDAP servers
  com.ibm.fncm.networking/egress-allow-ldap: "true"
  
  # Allow egress to database servers
  com.ibm.fncm.ecm.networking/egress-allow-db: "true"
```

**Examples:**
```yaml
# Strict network policy (production)
networkPolicyLabels:
  com.ibm.fncm.networking/egress-deny-all: "true"
  com.ibm.fncm.networking/egress-allow-same-namespace: "true"
  com.ibm.fncm.networking/egress-allow-k8s-services: "true"
  com.ibm.fncm.networking/egress-allow-ldap: "true"
  com.ibm.fncm.ecm.networking/egress-allow-db: "true"

# Permissive network policy (development)
networkPolicyLabels:
  com.ibm.fncm.networking/egress-allow-all: "true"

# Custom network policy
networkPolicyLabels:
  com.ibm.fncm.networking/egress-deny-all: "true"
  com.ibm.fncm.networking/egress-allow-same-namespace: "true"
  custom.company.com/egress-allow-monitoring: "true"
```

---

### Vault Integration

```yaml
# Vault Secret Management Configuration
# Type: object
# Purpose: Mount secrets from HashiCorp Vault using Secrets Store CSI Driver
vault:
  # Enable Vault secret mounting
  # Type: boolean
  # Default: false
  # Required: No
  # Prerequisites: Secrets Store CSI Driver and Vault CSI Provider installed
  enabled: false
  
  # Base mount path for credential secrets
  # Type: string
  # Default: /tmp/secrets
  # Purpose: Where credential secrets are mounted in the pod
  secretsMountPath: /tmp/secrets
  
  # Base mount path for certificate secrets
  # Type: string
  # Default: /tmp/certificates
  # Purpose: Where SSL/TLS certificates are mounted in the pod
  certificatesMountPath: /tmp/certificates
  
  # List of secret configurations
  # Type: array of objects
  # Default: []
  # Note: Each secret requires a corresponding SecretProviderClass resource
  secrets: []
  # Example configuration:
  # secrets:
  #   - name: ibm-fncm-secret
  #     type: secret
  #   - name: ibm-ban-secret
  #     type: secret
  #   - name: ldap-bind-secret
  #     type: secret
  #   - name: ibm-ldap-ssl-secret
  #     type: certificate
```

**Examples:**
```yaml
# Enable Vault with multiple secrets
vault:
  enabled: true
  secretsMountPath: /tmp/secrets
  certificatesMountPath: /tmp/certificates
  secrets:
    - name: ibm-fncm-secret
      type: secret
    - name: ibm-ban-secret
      type: secret
    - name: ldap-bind-secret
      type: secret
    - name: ibm-ldap-ssl-secret
      type: certificate
    - name: db-credentials
      type: secret

# Custom mount paths
vault:
  enabled: true
  secretsMountPath: /vault/secrets
  certificatesMountPath: /vault/certs
  secrets:
    - name: app-secrets
      type: secret
```

---

## 📝 Configuration Examples

### Minimal Configuration

```yaml
# Minimal viable configuration
image:
  tag: "26.0.0"

imagePullSecrets:
  - name: ibm-entitlement-key

operator:
  env:
    fncmLicense: "accept"
```

### Development Environment

```yaml
# Development configuration
image:
  tag: "26.0.0"
  pullPolicy: Always

replicaCount: 1

operator:
  resources:
    limits:
      cpu: "500m"
      memory: 1Gi
    requests:
      cpu: 250m
      memory: 256Mi
  
  env:
    fncmLicense: "accept"
    maxConcurrentReconciles: "5"

networkPolicyLabels:
  com.ibm.fncm.networking/egress-allow-all: "true"
```

### Production Environment

```yaml
# Production configuration
image:
  digest: "sha256:96c59421d96ba1d5dbf8821f30164e0037057af611af2e6f5e2c7c87d3cc59d0"
  pullPolicy: IfNotPresent

replicaCount: 3

operator:
  resources:
    limits:
      cpu: "2"
      memory: 4Gi
    requests:
      cpu: 1
      memory: 2Gi
  
  securityContext:
    runAsNonRoot: true
    runAsUser: 1001
    fsGroup: 1001
  
  containerSecurityContext:
    allowPrivilegeEscalation: false
    privileged: false
    readOnlyRootFilesystem: true
    capabilities:
      drop:
        - ALL
    seccompProfile:
      type: RuntimeDefault
  
  env:
    fncmLicense: "accept"
    maxConcurrentReconciles: "20"

affinity:
  podAntiAffinity:
    requiredDuringSchedulingIgnoredDuringExecution:
      - labelSelector:
          matchExpressions:
            - key: name
              operator: In
              values:
                - ibm-content-operator
        topologyKey: kubernetes.io/hostname

networkPolicyLabels:
  com.ibm.fncm.networking/egress-deny-all: "true"
  com.ibm.fncm.networking/egress-allow-same-namespace: "true"
  com.ibm.fncm.networking/egress-allow-k8s-services: "true"
  com.ibm.fncm.networking/egress-allow-ldap: "true"
  com.ibm.fncm.ecm.networking/egress-allow-db: "true"

podAnnotations:
  productID: "9c2d4f167cdb411fa3b1d787eb3c7c34"
  productName: "IBM Content Cortex Essentials"
  productVersion: "26.0.0"
  backup-policy: "daily"
  monitoring: "enabled"
```

### High Availability Configuration

```yaml
# High availability configuration
image:
  digest: "sha256:96c59421d96ba1d5dbf8821f30164e0037057af611af2e6f5e2c7c87d3cc59d0"

replicaCount: 5

operator:
  resources:
    limits:
      cpu: "2"
      memory: 4Gi
    requests:
      cpu: 1
      memory: 2Gi
  
  env:
    fncmLicense: "accept"
    maxConcurrentReconciles: "30"

affinity:
  podAntiAffinity:
    requiredDuringSchedulingIgnoredDuringExecution:
      - labelSelector:
          matchExpressions:
            - key: name
              operator: In
              values:
                - ibm-content-operator
        topologyKey: kubernetes.io/hostname
  
  nodeAffinity:
    preferredDuringSchedulingIgnoredDuringExecution:
      - weight: 100
        preference:
          matchExpressions:
            - key: disktype
              operator: In
              values:
                - ssd

tolerations:
  - key: "dedicated"
    operator: "Equal"
    value: "content"
    effect: "NoSchedule"
```

### Private Registry Configuration

```yaml
# Private registry configuration
image:
  repository: my-registry.company.com/icp4a-content-operator
  tag: "26.0.0"
  pullPolicy: IfNotPresent

imagePullSecrets:
  - name: my-registry-secret

operator:
  env:
    fncmLicense: "accept"
```

### Vault Integration Configuration

```yaml
# Vault integration configuration
image:
  tag: "26.0.0"

operator:
  env:
    fncmLicense: "accept"

vault:
  enabled: true
  secretsMountPath: /tmp/secrets
  certificatesMountPath: /tmp/certificates
  secrets:
    - name: ibm-fncm-secret
      type: secret
    - name: ibm-ban-secret
      type: secret
    - name: ldap-bind-secret
      type: secret
    - name: ibm-ldap-ssl-secret
      type: certificate
```

## 🔍 Validation

### Validate Values File

```bash
# Lint the chart with custom values
helm lint ./helm-charts/content-operator \
  --values my-values.yaml

# Dry-run installation
helm install content-operator ./helm-charts/content-operator \
  --namespace ibm-content \
  --values my-values.yaml \
  --dry-run --debug

# Template rendering
helm template content-operator ./helm-charts/content-operator \
  --namespace ibm-content \
  --values my-values.yaml \
  --debug
```

### Common Validation Errors

**Error: Invalid CPU format**
```yaml
# ❌ Wrong
operator:
  resources:
    limits:
      cpu: 1  # Missing quotes

# ✓ Correct
operator:
  resources:
    limits:
      cpu: "1"
```

**Error: Invalid memory format**
```yaml
# ❌ Wrong
operator:
  resources:
    limits:
      memory: 2GB  # Wrong unit

# ✓ Correct
operator:
  resources:
    limits:
      memory: 2Gi
```

**Error: License not accepted**
```yaml
# ❌ Wrong
operator:
  env:
    fncmLicense: "decline"

# ✓ Correct
operator:
  env:
    fncmLicense: "accept"
```

## 📞 Support

For questions or issues with values configuration:

- **Documentation**: [Chart README](./README.md)
- **Schema**: [values.schema.json](./values.schema.json)
- **Examples**: See [Configuration Examples](#configuration-examples)
- **IBM Support**: [IBM Support Portal](https://www.ibm.com/mysupport)

---

**Chart Version**: 26.0.0 | **Last Updated**: 2026-06-07