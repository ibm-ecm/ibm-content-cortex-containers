# IBM Content Operator Helm Chart

[![Helm Version](https://img.shields.io/badge/Helm-v4.0+-blue.svg)](https://helm.sh)
[![Kubernetes Version](https://img.shields.io/badge/Kubernetes-v1.24+-blue.svg)](https://kubernetes.io)
[![OpenShift Version](https://img.shields.io/badge/OpenShift-v4.12+-red.svg)](https://www.openshift.com)
[![Chart Version](https://img.shields.io/badge/Chart-26.0.0-green.svg)](./Chart.yaml)

## 📋 Table of Contents

- [Overview](#overview)
- [Prerequisites](#prerequisites)
- [Quick Start](#quick-start)
- [Installation](#installation)
- [Configuration](#configuration)
- [Post-Installation](#post-installation)
- [Upgrading](#upgrading)
- [Uninstallation](#uninstallation)
- [Troubleshooting](#troubleshooting)
- [Advanced Configuration](#advanced-configuration)
- [Use Cases](#use-cases)
- [Useful Helm Commands](#useful-helm-commands)
- [Support](#support)

## 🎯 Overview

The **IBM Content Operator** Helm chart deploys the operator for **IBM Content Cortex (CCx)** on Kubernetes and OpenShift platforms. The operator manages the complete lifecycle of Content Cortex deployments through Kubernetes Custom Resources (CRs), providing:

- **Automated Deployment**: Deploy Content Platform Engine (CPE), Content Navigator (ICN), and related services
- **Lifecycle Management**: Handle upgrades, scaling, and configuration changes
- **High Availability**: Support for multi-replica deployments with load balancing
- **Enterprise Security**: Comprehensive RBAC, security contexts, and network policies
- **Architecture Support**: Support for amd64 and ppc64le

### What is Content Cortex?

IBM Content Cortex (CCx) is a comprehensive enterprise content management platform that includes:
- **Content Platform Engine (CPE)**: Core content repository and workflow engine
- **Content Navigator (ICN)**: Modern web-based user interface
- **GraphQL API**: Modern API for content access and manipulation
- **CMIS Services**: Standards-based content integration
- **IBM Enterprise Records (IER)**: Records management capabilities
- **IBM Content Collector for SAP (ICCSAP)**: SAP content integration capabilities
- **CCx for Microsoft Office (CCxMO)**: Microsoft Office integration capabilities
- **Task Manager**: Workflow and case management

## ✅ Prerequisites

Before installing this chart, ensure you have:

### Required

- **Kubernetes 1.24+** or **OpenShift 4.12+**
- **Helm 4.0+** installed and configured
- **IBM Entitlement Key** from [IBM Container Library](https://myibm.ibm.com/products-services/containerlibrary)
- **Namespace** created for the deployment
- **Minimum Resources**: 500m CPU and 256Mi memory available per operator replica

### Recommended

- **Persistent Storage**: StorageClass with dynamic provisioning for content storage
- **Database**: IBM Db2, Oracle, PostgreSQL, or SQL Server for content repository
- **LDAP/AD**: Directory service for user authentication
- **Load Balancer**: For production deployments with multiple replicas

### Network Requirements

The operator requires egress access to:
- Container registry (cp.icr.io or your private registry)
- Database servers
- LDAP/AD servers
- Kubernetes API server

## 🚀 Quick Start

Get up and running in 5 minutes:

```bash
# 1. Create namespace
kubectl create namespace ibm-content

# 2. Create image pull secret
kubectl create secret docker-registry ibm-entitlement-key \
  --docker-server=cp.icr.io \
  --docker-username=cp \
  --docker-password=<your-entitlement-key> \
  --namespace ibm-content

# 3. Install the chart
helm install content-operator ./helm-charts/content-operator \
  --namespace ibm-content

# 4. Verify installation
kubectl get pods -n ibm-content -l name=ibm-content-operator
```

## 📦 Installation

### Step 1: Create Namespace

```bash
kubectl create namespace ibm-content
```

**OpenShift:**
```bash
oc new-project ibm-content
```

### Step 2: Create Image Pull Secret

Get your IBM Entitlement Key from [IBM Container Library](https://myibm.ibm.com/products-services/containerlibrary).

```bash
kubectl create secret docker-registry ibm-entitlement-key \
  --docker-server=cp.icr.io \
  --docker-username=cp \
  --docker-password=<your-entitlement-key> \
  --namespace ibm-content
```

**Verify the secret:**
```bash
kubectl get secret ibm-entitlement-key -n ibm-content
```

### Step 3: Install the Chart

**Basic Installation:**
```bash
helm install content-operator ./helm-charts/content-operator \
  --namespace ibm-content
```

**With Custom Values:**
```bash
helm install content-operator ./helm-charts/content-operator \
  --namespace ibm-content \
  --values custom-values.yaml
```

**With Inline Overrides:**
```bash
helm install content-operator ./helm-charts/content-operator \
  --namespace ibm-content \
  --set image.tag=26.0.0 \
  --set replicaCount=2 \
  --set operator.resources.limits.memory=4Gi
```

### Step 4: Verify Installation

```bash
# Check Helm release
helm list -n ibm-content

# Check operator deployment
kubectl get deployment ibm-content-operator -n ibm-content

# Check operator pods
kubectl get pods -n ibm-content -l name=ibm-content-operator

# View operator logs
kubectl logs -n ibm-content -l name=ibm-content-operator -f

# Check CRD installation
kubectl get crd fncmclusters.fncm.ibm.com
```

**Expected Output:**
```
NAME                   READY   UP-TO-DATE   AVAILABLE   AGE
ibm-content-operator   1/1     1            1           2m

NAME                                    READY   STATUS    RESTARTS   AGE
ibm-content-operator-7d8f9c5b6d-x7k2p   1/1     Running   0          2m
```

## ⚙️ Configuration

### Key Configuration Parameters

The Helm chart configures the operator deployment itself. The generated Content custom resource controls the actual Content deployment. The tested content-related options below are the ones reflected by the generated artifacts under [`scripts/helper_scripts/generate/generate_cr.py`](scripts/helper_scripts/generate/generate_cr.py:380) and [`scripts/helper_scripts/generate/generate_secrets.py`](scripts/helper_scripts/generate/generate_secrets.py:633).

| Parameter | Description | Default | Required |
|-----------|-------------|---------|----------|
| `image.repository` | Operator image repository | `icr.io/cpopen/icp4a-content-operator` | Yes |
| `image.digest` | Operator image digest | chart-defined | No |
| `image.tag` | Operator image tag override | `""` | No |
| `image.pullPolicy` | Image pull policy | `IfNotPresent` | Yes |
| `imagePullSecrets` | Pull secret used by the operator pod | `[{name: ibm-entitlement-key}]` | Yes |
| `replicaCount` | Number of operator replicas | `1` | Yes |
| `operator.resources.*` | CPU and memory requests/limits for the operator pod | chart-defined | Yes |
| `operator.env.fncmLicense` | License acceptance for the operator | `accept` | Yes |
| `operator.env.maxConcurrentReconciles` | Max concurrent reconciles | `10` | No |
| `operator.env.ansibleGathering` | Ansible gathering mode | `smart` | No |
| `vault.enabled` | Enable external secret store integration for mounted secrets | `false` | No |
| `vault.secretsMountPath` | Mount path for credential-type secrets | `/tmp/secrets` | When `vault.enabled=true` |
| `vault.certificatesMountPath` | Mount path for certificate-type secrets | `/tmp/certificates` | When `vault.enabled=true` |
| `vault.secrets[].name` | Secret name expected by the Content CR | none | When `vault.enabled=true` |
| `vault.secrets[].type` | Secret classification: `secret` or `certificate` | none | When `vault.enabled=true` |

### Image Configuration

The chart supports digest-based and tag-based image references:

**Digest-based image reference**
```yaml
image:
  repository: icr.io/cpopen/icp4a-content-operator
  digest: "sha256:96c59421d96ba1d5dbf8821f30164e0037057af611af2e6f5e2c7c87d3cc59d0"
  tag: ""
```

**Tag override**
```yaml
image:
  repository: icr.io/cpopen/icp4a-content-operator
  tag: "26.0.0"
```

### Content CR Options Generated by the Prerequisites Scripts

The generated Content CR includes tested content-related settings from [`scripts/helper_scripts/generate/cr_templates/26.0.0/content/base.yaml`](scripts/helper_scripts/generate/cr_templates/26.0.0/content/base.yaml), [`scripts/helper_scripts/generate/cr_templates/26.0.0/content/database.yaml`](scripts/helper_scripts/generate/cr_templates/26.0.0/content/database.yaml), and [`scripts/helper_scripts/generate/cr_templates/26.0.0/content/ldap.yaml`](scripts/helper_scripts/generate/cr_templates/26.0.0/content/ldap.yaml).

**Shared configuration**
```yaml
spec:
  shared_configuration:
    image_pull_secrets:
      - ibm-entitlement-key
    root_ca_secret: content-root-ca
    sc_deployment_type: production
    sc_deployment_platform: OCP
    sc_fncm_license_model: "<license>"
    sc_deployment_profile_size: small
    enable_fips: false
    sc_content_initialization: false
    sc_content_verification: false
    sc_ingress_enable: false
    sc_generate_sample_network_policies: false
    storage_configuration:
      sc_slow_file_storage_classname: "<slow-class>"
      sc_medium_file_storage_classname: "<medium-class>"
      sc_fast_file_storage_classname: "<fast-class>"
```

**Database configuration**
```yaml
spec:
  datasource_configuration:
    dc_ssl_enabled: true
    dc_gcd_datasource:
      dc_database_type: postgresql
      database_servername: postgres.example.com
      database_name: GCDDB
      database_port: "5432"
      database_ssl_secret_name: ibm-gcd-ssl-secret
    dc_os_datasources:
      - dc_database_type: postgresql
        dc_os_label: os
        database_servername: postgres.example.com
        database_name: OS1DB
        database_port: "5432"
        database_ssl_secret_name: ibm-os-ssl-secret
    dc_icn_datasource:
      dc_database_type: postgresql
      database_servername: postgres.example.com
      database_name: ICNDB
      database_port: "5432"
      database_ssl_secret_name: ibm-icn-ssl-secret
```

**LDAP configuration**
```yaml
spec:
  ldap_configuration:
    lc_selected_ldap_type: "Microsoft Active Directory"
    lc_ldap_server: ldap.example.com
    lc_ldap_port: "636"
    lc_bind_secret: ldap-bind-secret
    lc_ldap_base_dn: "dc=example,dc=com"
    lc_ldap_ssl_enabled: true
    lc_ldap_ssl_secret_name: ibm-ldap-ssl-secret
    lc_ldap_user_name_attribute: "user:sAMAccountName"
    lc_ldap_group_base_dn: "dc=example,dc=com"
    lc_ldap_group_member_id_map: "memberOf:member"
```

### Kubernetes Secret vs Vault

The prerequisites generator supports two tested secret delivery models for Content:

| Mode | Generated artifacts | How the operator consumes them | Notes |
|------|---------------------|--------------------------------|-------|
| Kubernetes Secret | `Secret` YAML files such as `ibm-fncm-secret.yaml`, `ibm-ban-secret.yaml`, and `ldap-bind-secret.yaml` | Referenced directly by secret name in the Content CR | Default behavior in [`scripts/helper_scripts/generate/generate_secrets.py`](scripts/helper_scripts/generate/generate_secrets.py:679) |
| Vault | Vault JSON import files plus `SecretProviderClass` YAML files | Mounted by CSI at `vault.secretsMountPath` or `vault.certificatesMountPath` | Enabled by [`scripts/helper_scripts/generate/generate_cr.py`](scripts/helper_scripts/generate/generate_cr.py:628) and [`scripts/helper_scripts/generate/templates/secretproviderclass.j2`](scripts/helper_scripts/generate/templates/secretproviderclass.j2:1) |

**Kubernetes Secret mode**
- Generates standard Kubernetes `Secret` manifests.
- Secret values are base64-encoded in YAML.
- Password fields are XOR-encoded before being stored for the Content secrets generated by the prerequisites scripts, such as [`ibm-fncm-secret`](scripts/helper_scripts/generate/generate_secrets.py:803), [`ibm-ban-secret`](scripts/helper_scripts/generate/generate_secrets.py:694), and [`ldap-bind-secret`](scripts/helper_scripts/generate/generate_secrets.py:730).

**Vault mode**
- Sets `spec.shared_configuration.sc_vault_configuration.enable_external_secret_store: true` in the generated Content CR.
- Generates `SecretProviderClass` resources instead of Kubernetes `Secret` manifests for the same logical secret names.
- Generates JSON files for import into Vault.
- Uses `type: secret` for credentials and `type: certificate` for TLS material.

### Tested Secret Names Used by Content

The following secret names are directly generated and referenced by the tested content flows:

| Secret name | Purpose | Source |
|-------------|---------|--------|
| `ibm-fncm-secret` | CPE admin and database credentials, including GCD and object store credentials | [`scripts/helper_scripts/generate/generate_secrets.py`](scripts/helper_scripts/generate/generate_secrets.py:803) |
| `ibm-ban-secret` | Navigator admin and database credentials | [`scripts/helper_scripts/generate/generate_secrets.py`](scripts/helper_scripts/generate/generate_secrets.py:694) |
| `ldap-bind-secret` | LDAP bind credentials | [`scripts/helper_scripts/generate/generate_secrets.py`](scripts/helper_scripts/generate/generate_secrets.py:730) |
| `ibm-gcd-ssl-secret` | GCD database TLS material when DB SSL is enabled | [`scripts/helper_scripts/generate/generate_cr.py`](scripts/helper_scripts/generate/generate_cr.py:403) |
| `ibm-os-ssl-secret` | Object store database TLS material when DB SSL is enabled | [`scripts/helper_scripts/generate/generate_cr.py`](scripts/helper_scripts/generate/generate_cr.py:474) |
| `ibm-icn-ssl-secret` | Navigator database TLS material when DB SSL is enabled | [`scripts/helper_scripts/generate/generate_cr.py`](scripts/helper_scripts/generate/generate_cr.py:403) |
| `ibm-ldap-ssl-secret` | LDAP TLS certificate secret when LDAP SSL is enabled | [`scripts/helper_scripts/generate/generate_cr.py`](scripts/helper_scripts/generate/generate_cr.py:232) |
| `ibm-ier-secret` | IBM Enterprise Records keystore secret when IER is enabled | [`scripts/helper_scripts/generate/generate_secrets.py`](scripts/helper_scripts/generate/generate_secrets.py:837) |
| `ibm-iccsap-secret` | IBM Content Collector for SAP keystore secret when ICCSAP is enabled | [`scripts/helper_scripts/generate/generate_secrets.py`](scripts/helper_scripts/generate/generate_secrets.py:853) |
| `content-root-ca` | Shared root CA secret referenced by `root_ca_secret` | [`scripts/helper_scripts/generate/cr_templates/26.0.0/content/base.yaml`](scripts/helper_scripts/generate/cr_templates/26.0.0/content/base.yaml:61) |

### Resource Configuration

**Development-sized operator**
```yaml
operator:
  resources:
    limits:
      cpu: "500m"
      memory: 1Gi
    requests:
      cpu: 250m
      memory: 256Mi
```

**Production-sized operator**
```yaml
operator:
  resources:
    limits:
      cpu: "2"
      memory: 4Gi
    requests:
      cpu: 1
      memory: 2Gi
```

### Security Configuration

**Basic security**
```yaml
operator:
  securityContext:
    runAsNonRoot: true

  containerSecurityContext:
    allowPrivilegeEscalation: false
    privileged: false
    readOnlyRootFilesystem: true
    capabilities:
      drop:
        - ALL
```

**Enhanced security**
```yaml
operator:
  securityContext:
    runAsNonRoot: true
    runAsUser: 1001
    fsGroup: 1001

  containerSecurityContext:
    allowPrivilegeEscalation: false
    privileged: false
    readOnlyRootFilesystem: true
    capabilities:
      drop:
        - ALL
    seccompProfile:
      type: RuntimeDefault
```

### Network Policy Labels

Control operator egress with labels:

```yaml
networkPolicyLabels:
  com.ibm.fncm.networking/egress-deny-all: "true"
  com.ibm.fncm.networking/egress-allow-same-namespace: "true"
  com.ibm.fncm.networking/egress-allow-k8s-services: "true"
  com.ibm.fncm.networking/egress-allow-ldap: "true"
  com.ibm.fncm.ecm.networking/egress-allow-db: "true"
```

### Custom Values File Example

Create `my-values.yaml`:

```yaml
image:
  tag: 26.0.0
  pullPolicy: Always

replicaCount: 2

operator:
  resources:
    limits:
      cpu: "2"
      memory: 4Gi
    requests:
      cpu: 1
      memory: 2Gi
  env:
    maxConcurrentReconciles: "20"
    ansibleGathering: explicit
    fncmLicense: accept

vault:
  enabled: false

affinity:
  nodeAffinity:
    requiredDuringSchedulingIgnoredDuringExecution:
      nodeSelectorTerms:
        - matchExpressions:
            - key: kubernetes.io/arch
              operator: In
              values:
                - amd64

nodeSelector:
  disktype: ssd
  environment: production

tolerations:
  - key: "dedicated"
    operator: "Equal"
    value: "content"
    effect: "NoSchedule"

podAnnotations:
  backup-policy: "daily"
```

**Vault-enabled variant**
```yaml
vault:
  enabled: true
  secretsMountPath: /tmp/secrets
  certificatesMountPath: /tmp/certificates
  secrets:
    - name: ibm-fncm-secret
      type: secret
    - name: ibm-ban-secret
      type: secret
    - name: ldap-bind-secret
      type: secret
    - name: ibm-gcd-ssl-secret
      type: certificate
    - name: ibm-os-ssl-secret
      type: certificate
    - name: ibm-icn-ssl-secret
      type: certificate
    - name: ibm-ldap-ssl-secret
      type: certificate
```

Install with custom values:
```bash
helm install content-operator ./helm-charts/content-operator \
  --namespace ibm-content \
  --values my-values.yaml
```

## 🔄 Post-Installation

### 1. Verify Operator Status

```bash
# Check deployment
kubectl get deployment ibm-content-operator -n ibm-content

# Check pods
kubectl get pods -n ibm-content -l name=ibm-content-operator

# View logs
kubectl logs -n ibm-content -l name=ibm-content-operator --tail=100 -f
```

### 2. Verify CRD Installation

```bash
# Check if CRD exists
kubectl get crd fncmclusters.fncm.ibm.com

# View CRD details
kubectl describe crd fncmclusters.fncm.ibm.com

# List CRD versions
kubectl get crd fncmclusters.fncm.ibm.com -o jsonpath='{.spec.versions[*].name}'
```

### 3. Create Content Cortex Deployment

After the operator is running, create a FNCMCluster custom resource:

```bash
# Apply the CR
kubectl apply -f descriptors/content-cortex/content/ibm_content_cr.yaml -n ibm-content

# Watch the deployment
kubectl get fncmcluster -n ibm-content -w

# Check deployment status
kubectl describe fncmcluster <cr-name> -n ibm-content
```

### 4. Monitor Deployment Progress

```bash
# Watch all pods
kubectl get pods -n ibm-content -w

# Check operator logs for reconciliation
kubectl logs -n ibm-content -l name=ibm-content-operator -f | grep -i reconcile

# Check events
kubectl get events -n ibm-content --sort-by='.lastTimestamp'
```

## 📈 Upgrading

### Upgrade the Operator

```bash
# Upgrade with same values
helm upgrade content-operator ./helm-charts/content-operator \
  --namespace ibm-content \
  --reuse-values

# Upgrade with new values
helm upgrade content-operator ./helm-charts/content-operator \
  --namespace ibm-content \
  --values new-values.yaml

# Upgrade with inline overrides
helm upgrade content-operator ./helm-charts/content-operator \
  --namespace ibm-content \
  --reuse-values \
  --set image.tag=26.0.1
```

### Verify Upgrade

```bash
# Check release history
helm history content-operator -n ibm-content

# Check deployment status
kubectl rollout status deployment/ibm-content-operator -n ibm-content

# Verify new version
kubectl get deployment ibm-content-operator -n ibm-content -o jsonpath='{.spec.template.spec.containers[0].image}'
```

### Rollback if Needed

```bash
# Rollback to previous version
helm rollback content-operator -n ibm-content

# Rollback to specific revision
helm rollback content-operator 2 -n ibm-content
```

## 🗑️ Uninstallation

### Standard Uninstall

```bash
# Uninstall the chart
helm uninstall content-operator -n ibm-content
```

**Note:** This will NOT delete:
- The namespace
- Image pull secrets
- FNCMCluster custom resources
- CRD (to prevent data loss)

### Complete Cleanup

To completely remove everything:

```bash
# 1. Delete all FNCMCluster resources first
kubectl delete fncmcluster --all -n ibm-content

# 2. Wait for resources to be cleaned up
kubectl get pods -n ibm-content -w

# 3. Uninstall the chart
helm uninstall content-operator -n ibm-content

# 4. Delete CRD (WARNING: This deletes all FNCMCluster resources cluster-wide!)
kubectl delete crd fncmclusters.fncm.ibm.com

# 5. Delete namespace
kubectl delete namespace ibm-content
```

### Cleanup Verification

```bash
# Verify no resources remain
kubectl get all -n ibm-content
kubectl get fncmcluster --all-namespaces
kubectl get crd | grep fncm
```

## 🔧 Troubleshooting

### Operator Not Starting

**Symptoms:**
- Pod in `Pending`, `CrashLoopBackOff`, or `ImagePullBackOff` state

**Diagnosis:**
```bash
# Check pod status
kubectl describe pod -n ibm-content -l name=ibm-content-operator

# Check events
kubectl get events -n ibm-content --sort-by='.lastTimestamp' | tail -20

# Check logs
kubectl logs -n ibm-content -l name=ibm-content-operator --previous
```

**Common Causes & Solutions:**

1. **Image Pull Errors:**
   ```bash
   # Verify secret exists
   kubectl get secret ibm-entitlement-key -n ibm-content
   
   # Check secret content
   kubectl get secret ibm-entitlement-key -n ibm-content -o jsonpath='{.data.\.dockerconfigjson}' | base64 -d
   
   # Test image pull manually
   kubectl run test --image=icr.io/cpopen/icp4a-content-operator:26.0.0 \
     --image-pull-policy=Always -n ibm-content --rm -it -- /bin/sh
   ```

2. **Insufficient Resources:**
   ```bash
   # Check node resources
   kubectl describe nodes | grep -A 5 "Allocated resources"
   
   # Reduce resource requests
   helm upgrade content-operator ./helm-charts/content-operator \
     --namespace ibm-content \
     --reuse-values \
     --set operator.resources.requests.cpu=250m \
     --set operator.resources.requests.memory=128Mi
   ```

3. **RBAC Issues:**
   ```bash
   # Check service account
   kubectl get sa ibm-content-operator-sa -n ibm-content
   
   # Check role and rolebinding
   kubectl get role,rolebinding -n ibm-content
   
   # Describe rolebinding
   kubectl describe rolebinding ibm-content-operator-rolebinding -n ibm-content
   ```

### CRD Issues

**Problem: CRD not found**
```bash
# Check if CRD exists
kubectl get crd fncmclusters.fncm.ibm.com

# If missing, reinstall with CRD
helm upgrade content-operator ./helm-charts/content-operator \
  --namespace ibm-content \
  --reuse-values
```

**Problem: CRD version mismatch**
```bash
# Check CRD version
kubectl get crd fncmclusters.fncm.ibm.com -o jsonpath='{.spec.versions[*].name}'

# Update CRD manually if needed
kubectl apply -f helm-charts/content-operator/crds/fncmclusters.fncm.ibm.com.yaml
```

### Operator Logs Show Errors

**Common Error Patterns:**

1. **"Failed to reconcile FNCMCluster"**
   ```bash
   # Check CR status
   kubectl describe fncmcluster <cr-name> -n ibm-content
   
   # Check operator logs for details
   kubectl logs -n ibm-content -l name=ibm-content-operator | grep -A 10 "Failed to reconcile"
   ```

2. **"Unable to connect to database"**
   - Verify database connectivity
   - Check database credentials in secrets
   - Verify network policies allow database access

3. **"LDAP authentication failed"**
   - Verify LDAP server connectivity
   - Check LDAP credentials
   - Verify LDAP configuration in CR

### Performance Issues

**Operator consuming too much CPU/Memory:**
```bash
# Check resource usage
kubectl top pod -n ibm-content -l name=ibm-content-operator

# Reduce concurrent reconciles
helm upgrade content-operator ./helm-charts/content-operator \
  --namespace ibm-content \
  --reuse-values \
  --set operator.env.maxConcurrentReconciles=5
```

### Network Connectivity Issues

```bash
# Test connectivity from operator pod
kubectl exec -it <operator-pod> -n ibm-content -- /bin/sh

# Inside pod, test connectivity
curl -v https://cp.icr.io
nc -zv <database-host> <database-port>
nc -zv <ldap-host> <ldap-port>
```

## 🎓 Advanced Configuration

### Using Private Registry

**1. Create registry secret:**
```bash
kubectl create secret docker-registry my-registry-secret \
  --docker-server=my-registry.company.com \
  --docker-username=myuser \
  --docker-password=mypassword \
  --namespace ibm-content
```

**2. Configure values:**
```yaml
image:
  repository: my-registry.company.com/icp4a-content-operator
  tag: 26.0.0

imagePullSecrets:
  - name: my-registry-secret
```

### Multi-Architecture Deployment

**Configure for specific architecture:**
```yaml
affinity:
  nodeAffinity:
    requiredDuringSchedulingIgnoredDuringExecution:
      nodeSelectorTerms:
        - matchExpressions:
            - key: kubernetes.io/arch
              operator: In
              values:
                - amd64  # or ppc64le
```

**Support multiple architectures:**
```yaml
affinity:
  nodeAffinity:
    requiredDuringSchedulingIgnoredDuringExecution:
      nodeSelectorTerms:
        - matchExpressions:
            - key: kubernetes.io/arch
              operator: In
              values:
                - amd64
                - ppc64le
```

### High Availability Configuration

**Deploy multiple operator replicas:**
```yaml
replicaCount: 3

operator:
  resources:
    limits:
      cpu: "1"
      memory: 2Gi
    requests:
      cpu: 500m
      memory: 512Mi

# Add pod anti-affinity
affinity:
  podAntiAffinity:
    preferredDuringSchedulingIgnoredDuringExecution:
      - weight: 100
        podAffinityTerm:
          labelSelector:
            matchExpressions:
              - key: name
                operator: In
                values:
                  - ibm-content-operator
          topologyKey: kubernetes.io/hostname
```

### Vault Integration for Secrets

Use Vault only when the generated Content CR also enables the external secret store flag and the required Vault artifacts have been created by the prerequisites scripts.

**Helm values for tested Content secrets**
```yaml
vault:
  enabled: true
  secretsMountPath: /tmp/secrets
  certificatesMountPath: /tmp/certificates
  secrets:
    - name: ibm-fncm-secret
      type: secret
    - name: ibm-ban-secret
      type: secret
    - name: ldap-bind-secret
      type: secret
    - name: ibm-gcd-ssl-secret
      type: certificate
    - name: ibm-os-ssl-secret
      type: certificate
    - name: ibm-icn-ssl-secret
      type: certificate
    - name: ibm-ldap-ssl-secret
      type: certificate
    - name: ibm-ier-secret
      type: secret
    - name: ibm-iccsap-secret
      type: secret
```

**Generated Content CR behavior**
```yaml
spec:
  shared_configuration:
    sc_vault_configuration:
      enable_external_secret_store: true
```

**Prerequisites**
- Secrets Store CSI Driver installed
- Vault CSI Provider installed
- Vault secrets imported for the same secret names
- `SecretProviderClass` resources applied for the same secret names
- Include `ibm-ier-secret` when IBM Enterprise Records is enabled
- Include `ibm-iccsap-secret` when IBM Content Collector for SAP is enabled
- CCxMO does not require a dedicated generated secret in the reviewed content flow

### Custom Monitoring and Metrics

**Add Prometheus annotations:**
```yaml
podAnnotations:
  prometheus.io/scrape: "true"
  prometheus.io/port: "8080"
  prometheus.io/path: "/metrics"
```

### Air-Gapped Deployment

**1. Mirror images to private registry:**
```bash
# Pull image
docker pull icr.io/cpopen/icp4a-content-operator:26.0.0

# Tag for private registry
docker tag icr.io/cpopen/icp4a-content-operator:26.0.0 \
  my-registry.company.com/icp4a-content-operator:26.0.0

# Push to private registry
docker push my-registry.company.com/icp4a-content-operator:26.0.0
```

**2. Configure chart:**
```yaml
image:
  repository: my-registry.company.com/icp4a-content-operator
  tag: 26.0.0
  pullPolicy: IfNotPresent

imagePullSecrets:
  - name: my-registry-secret
```

## 💼 Use Cases

### Use Case 1: Content deployment with Kubernetes Secrets

**Scenario:** Standard Content deployment using generated Kubernetes `Secret` manifests.

**What is generated**
- `ibm-fncm-secret`
- `ibm-ban-secret`
- `ldap-bind-secret`
- SSL secrets such as `ibm-gcd-ssl-secret`, `ibm-os-ssl-secret`, `ibm-icn-ssl-secret`, and `ibm-ldap-ssl-secret` when TLS is enabled

**Operator values**
```yaml
replicaCount: 1

operator:
  resources:
    limits:
      cpu: "500m"
      memory: 1Gi
    requests:
      cpu: 250m
      memory: 256Mi

vault:
  enabled: false
```

**Generated Content CR excerpts**
```yaml
spec:
  shared_configuration:
    root_ca_secret: content-root-ca
    sc_content_initialization: false
    sc_content_verification: false

  ldap_configuration:
    lc_bind_secret: ldap-bind-secret
    lc_ldap_ssl_secret_name: ibm-ldap-ssl-secret

  datasource_configuration:
    dc_gcd_datasource:
      database_ssl_secret_name: ibm-gcd-ssl-secret
    dc_os_datasources:
      - database_ssl_secret_name: ibm-os-ssl-secret
    dc_icn_datasource:
      database_ssl_secret_name: ibm-icn-ssl-secret
```

**Installation**
```bash
helm install content-operator ./helm-charts/content-operator \
  --namespace ibm-content \
  --values dev-values.yaml
```

### Use Case 2: Content deployment with Vault-backed mounted secrets

**Scenario:** Content deployment using Vault, `SecretProviderClass` resources, and CSI-mounted secrets instead of Kubernetes `Secret` objects.

**What is generated**
- Vault JSON import files for the same logical Content secret names
- `SecretProviderClass` YAML files for the same logical Content secret names
- Content CR with `sc_vault_configuration.enable_external_secret_store: true`

**Operator values**
```yaml
replicaCount: 2

operator:
  resources:
    limits:
      cpu: "2"
      memory: 4Gi
    requests:
      cpu: 1
      memory: 2Gi

vault:
  enabled: true
  secretsMountPath: /tmp/secrets
  certificatesMountPath: /tmp/certificates
  secrets:
    - name: ibm-fncm-secret
      type: secret
    - name: ibm-ban-secret
      type: secret
    - name: ldap-bind-secret
      type: secret
    - name: ibm-gcd-ssl-secret
      type: certificate
    - name: ibm-os-ssl-secret
      type: certificate
    - name: ibm-icn-ssl-secret
      type: certificate
    - name: ibm-ldap-ssl-secret
      type: certificate
```

**Generated Content CR excerpt**
```yaml
spec:
  shared_configuration:
    sc_vault_configuration:
      enable_external_secret_store: true
```

**Installation**
```bash
helm install content-operator ./helm-charts/content-operator \
  --namespace ibm-content \
  --values vault-values.yaml
```

Only the tested content-related use cases are shown here. Multi-tenant, IBM Z, and disaster recovery examples were removed because they are not part of the generated content-focused secret and configuration flows reviewed for this update.

## 📚 Useful Helm Commands

### Chart Management

```bash
# Lint the chart
helm lint ./helm-charts/content-operator

# Template rendering (dry-run)
helm template content-operator ./helm-charts/content-operator \
  --namespace ibm-content \
  --debug

# Dry-run installation
helm install content-operator ./helm-charts/content-operator \
  --namespace ibm-content \
  --dry-run --debug

# Package the chart
helm package ./helm-charts/content-operator

# Show chart values
helm show values ./helm-charts/content-operator

# Show chart README
helm show readme ./helm-charts/content-operator

# Show all chart information
helm show all ./helm-charts/content-operator
```

### Release Management

```bash
# List releases
helm list -n ibm-content
helm list --all-namespaces

# Get release status
helm status content-operator -n ibm-content

# Get release values
helm get values content-operator -n ibm-content

# Get release manifest
helm get manifest content-operator -n ibm-content

# Get release notes
helm get notes content-operator -n ibm-content

# Get release history
helm history content-operator -n ibm-content

# Get all release information
helm get all content-operator -n ibm-content
```

### Debugging

```bash
# Render templates with values
helm template content-operator ./helm-charts/content-operator \
  --namespace ibm-content \
  --values my-values.yaml \
  --debug > rendered-templates.yaml

# Test installation without applying
helm install content-operator ./helm-charts/content-operator \
  --namespace ibm-content \
  --dry-run --debug | less

# Show computed values
helm get values content-operator -n ibm-content --all

# Export release to file
helm get manifest content-operator -n ibm-content > release-manifest.yaml
```

### Upgrade and Rollback

```bash
# Upgrade with new values
helm upgrade content-operator ./helm-charts/content-operator \
  --namespace ibm-content \
  --values new-values.yaml

# Upgrade with inline overrides
helm upgrade content-operator ./helm-charts/content-operator \
  --namespace ibm-content \
  --reuse-values \
  --set image.tag=26.0.1

# Upgrade with dry-run
helm upgrade content-operator ./helm-charts/content-operator \
  --namespace ibm-content \
  --dry-run --debug

# Rollback to previous version
helm rollback content-operator -n ibm-content

# Rollback to specific revision
helm rollback content-operator 2 -n ibm-content

# Rollback with dry-run
helm rollback content-operator -n ibm-content --dry-run
```

### Cleanup

```bash
# Uninstall release
helm uninstall content-operator -n ibm-content

# Uninstall and keep history
helm uninstall content-operator -n ibm-content --keep-history

# Delete release history
# Note: Helm 4 does not support `helm delete`; uninstall with history retained
# and remove history according to your cluster retention policy if needed.
helm uninstall content-operator -n ibm-content --keep-history

# Uninstall with timeout
helm uninstall content-operator -n ibm-content --timeout 10m
```

### Repository Management

```bash
# Add Helm repository (if using remote repo)
helm repo add ibm-content https://your-repo-url

# Update repositories
helm repo update

# Search for charts
helm search repo ibm-content

# Show chart information from repo
helm show chart ibm-content/content-operator
```

## 📞 Support

### Documentation

- **Product Documentation**: [IBM Content Cortex Documentation](https://www.ibm.com/docs/SSL4SY_26.0.0/com.ibm.p8.containers.doc/containers.html)
- **GitHub Repository**: [Content Cortex Containers](https://github.com/ibm-ecm/ibm-content-cortex-containers)
- **Chart Repository**: [fncm-prerequisites](https://github.ibm.com/ecm-container-service/fncm-prerequisites)

### Getting Help

- **IBM Support**: Open a case through [IBM Support Portal](https://www.ibm.com/mysupport)
- **Email**: support@ibm.com
- **Community**: [IBM ECM Community](https://community.ibm.com/community/user/automation/communities/community-home?CommunityKey=ecm)

### Reporting Issues

When reporting issues, please include:

1. **Chart version**: `helm list -n ibm-content`
2. **Kubernetes version**: `kubectl version`
3. **Operator logs**: `kubectl logs -n ibm-content -l name=ibm-content-operator`
4. **Pod description**: `kubectl describe pod -n ibm-content -l name=ibm-content-operator`
5. **Events**: `kubectl get events -n ibm-content --sort-by='.lastTimestamp'`
6. **Values used**: `helm get values content-operator -n ibm-content`

### Additional Resources

- **Release Notes**: See [CHANGELOG.md](./CHANGELOG.md)
- **Chart Summary**: See [CHART_SUMMARY.md](./CHART_SUMMARY.md)
- **Migration Guide**: See [HELM_CHART_MIGRATION_GUIDE.md](../HELM_CHART_MIGRATION_GUIDE.md)
- **Integration Strategy**: See [HELM_INTEGRATION_STRATEGY.md](../HELM_INTEGRATION_STRATEGY.md)

## 📄 License

Licensed Materials - Property of IBM

(C) Copyright IBM Corp. 2026. All Rights Reserved.

US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

---

**Chart Version**: 26.0.0 | **App Version**: 26.0.0 | **Last Updated**: 2026-06-18