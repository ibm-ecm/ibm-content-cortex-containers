# Content Operator Helm Chart - Summary

## Overview

This Helm chart deploys the IBM Content Operator for Content Cortex (CCx) on Kubernetes/OpenShift. The operator manages FNCMCluster custom resources to deploy and manage Content Cortex (CCx) components.

## Chart Information

- **Chart Name**: content-operator
- **Chart Version**: 26.0.0
- **App Version**: 26.0.0
- **Operator Image**: icr.io/cpopen/icp4a-content-operator:26.0.0

## Architecture

```
content-operator/
├── Chart.yaml                    # Chart metadata
├── values.yaml                   # Default configuration values
├── templates/
│   ├── serviceaccount.yaml      # ServiceAccount for operator
│   ├── role.yaml                # Namespace-scoped Role
│   ├── rolebinding.yaml         # RoleBinding
│   ├── crd.yaml                 # FNCMCluster CRD (optional)
│   ├── deployment.yaml          # Operator Deployment
│   └── NOTES.txt                # Post-installation notes
├── .helmignore                  # Files to ignore
├── CHANGELOG.md                 # Version history
└── CHART_SUMMARY.md            # This file
```

## Key Features

### 1. Namespace-Scoped RBAC
- All RBAC permissions are namespace-scoped
- No cluster-level permissions required
- Operator can only manage resources in its namespace

### 2. Optional CRD Installation
- CRD can be installed with the chart or separately
- Controlled by `crd.install` value
- Useful for multi-tenant environments

### 3. Comprehensive Security
- Pod security contexts with runAsNonRoot
- Container security contexts with dropped capabilities
- Read-only root filesystem
- Network policy labels for egress control

### 4. Multi-Architecture Support
- Supports amd64, s390x, and ppc64le architectures
- Node affinity configured for all supported platforms

### 5. Resource Management
- Configurable resource limits and requests
- Separate configuration for operator and init containers
- Default values suitable for production

## Prerequisites

Before installing this chart, you must:

1. **Create Namespace**
   ```bash
   kubectl create namespace <namespace>
   ```

2. **Create Image Pull Secret**
   ```bash
   kubectl create secret docker-registry ibm-entitlement-key \
     --docker-server=cp.icr.io \
     --docker-username=cp \
     --docker-password=<your-entitlement-key> \
     --namespace <namespace>
   ```

## Installation

### Basic Installation

```bash
helm install content-operator ./helm-charts/content-operator \
  --namespace ibm-content
```

### With Custom Values

```bash
helm install content-operator ./helm-charts/content-operator \
  --namespace ibm-content \
  --set image.tag=26.0.0 \
  --set replicaCount=2
```

### Skip CRD Installation

```bash
helm install content-operator ./helm-charts/content-operator \
  --namespace ibm-content \
  --set crd.install=false
```

### Using Values File

```bash
helm install content-operator ./helm-charts/content-operator \
  --namespace ibm-content \
  --values custom-values.yaml
```

## Configuration

### Key Configuration Options

| Parameter | Description | Default |
|-----------|-------------|---------|
| `image.repository` | Operator image repository | `icr.io/cpopen/icp4a-content-operator` |
| `image.tag` | Operator image tag | `26.0.0` |
| `image.pullPolicy` | Image pull policy | `IfNotPresent` |
| `imagePullSecrets` | Image pull secrets | `[{name: ibm-entitlement-key}]` |
| `replicaCount` | Number of operator replicas | `1` |
| `serviceAccount.create` | Create service account | `true` |
| `serviceAccount.name` | Service account name | `ibm-content-operator-sa` |
| `rbac.create` | Create RBAC resources | `true` |
| `crd.install` | Install CRD | `true` |
| `operator.name` | Operator name | `ibm-content-operator` |
| `operator.resources` | Resource limits/requests | See values.yaml |
| `operator.env.fncmLicense` | License acceptance | `accept` |

### Security Configuration

```yaml
operator:
  securityContext:
    runAsNonRoot: true
  
  containerSecurityContext:
    allowPrivilegeEscalation: false
    privileged: false
    readOnlyRootFilesystem: true
    capabilities:
      drop:
        - ALL
```

### Network Policy Labels

```yaml
networkPolicyLabels:
  com.ibm.fncm.networking/egress-deny-all: "true"
  com.ibm.fncm.networking/egress-allow-same-namespace: "true"
  com.ibm.fncm.networking/egress-allow-k8s-services: "true"
  com.ibm.fncm.networking/egress-allow-all: "true"
  com.ibm.fncm.networking/egress-allow-ldap: "true"
  com.ibm.fncm.ecm.networking/egress-allow-db: "true"
```

## Post-Installation

After installing the chart:

1. **Verify Operator Deployment**
   ```bash
   kubectl get deployment ibm-content-operator -n <namespace>
   ```

2. **Check Operator Pods**
   ```bash
   kubectl get pods -n <namespace> -l name=ibm-content-operator
   ```

3. **View Operator Logs**
   ```bash
   kubectl logs -n <namespace> -l name=ibm-content-operator -f
   ```

4. **Create FNCMCluster Custom Resource**
   ```bash
   kubectl apply -f fncm-cluster.yaml -n <namespace>
   ```

## Upgrading

```bash
helm upgrade content-operator ./helm-charts/content-operator \
  --namespace ibm-content \
  --values custom-values.yaml
```

## Uninstalling

```bash
helm uninstall content-operator --namespace ibm-content
```

**Note**: This will not delete:
- The namespace
- Image pull secrets
- FNCMCluster custom resources
- CRD (if installed)

To completely remove everything:

```bash
# Delete custom resources first
kubectl delete fncmcluster --all -n ibm-content

# Uninstall chart
helm uninstall content-operator -n ibm-content

# Delete CRD (if needed)
kubectl delete crd fncmclusters.fncm.ibm.com

# Delete namespace
kubectl delete namespace ibm-content
```

## Validation

### Lint Chart

```bash
helm lint ./helm-charts/content-operator
```

### Template Rendering

```bash
helm template test ./helm-charts/content-operator \
  --namespace test-ns \
  --debug
```

### Dry Run Installation

```bash
helm install content-operator ./helm-charts/content-operator \
  --namespace ibm-content \
  --dry-run --debug
```

## Troubleshooting

### Operator Not Starting

1. Check pod status:
   ```bash
   kubectl describe pod -n <namespace> -l name=ibm-content-operator
   ```

2. Check image pull:
   ```bash
   kubectl get events -n <namespace> --sort-by='.lastTimestamp'
   ```

3. Verify image pull secret:
   ```bash
   kubectl get secret ibm-entitlement-key -n <namespace>
   ```

### CRD Issues

1. Check if CRD exists:
   ```bash
   kubectl get crd fncmclusters.fncm.ibm.com
   ```

2. Describe CRD:
   ```bash
   kubectl describe crd fncmclusters.fncm.ibm.com
   ```

### RBAC Issues

1. Check service account:
   ```bash
   kubectl get sa ibm-content-operator-sa -n <namespace>
   ```

2. Check role and rolebinding:
   ```bash
   kubectl get role,rolebinding -n <namespace>
   ```

## Support

- **Documentation**: https://www.ibm.com/docs/en/content-cortex
- **Chart Repository**: https://github.ibm.com/ecm-container-service/fncm-prerequisites
- **Support Email**: ecm-container-service@ibm.com

## License

Licensed Materials - Property of IBM
(C) Copyright IBM Corp. 2026. All Rights Reserved.