# Changelog - Content Operator Helm Chart

## [26.0.0] - 2026-04-23

### Updated to Support New values.yaml Structure

#### Major Changes

1. **Updated values.yaml Structure**
   - Restructured to match enterprise Helm chart patterns
   - Moved from `global.namespace` to using `--namespace` flag with `.Release.Namespace`
   - Reorganized operator configuration under `operator.*` namespace
   - Added comprehensive security contexts and resource configurations
   - Added support for pod annotations, labels, and network policy labels

2. **Template Updates**
   - **deployment.yaml**: Updated to use new values structure
     - Changed namespace reference from `.Values.global.namespace` to `.Release.Namespace`
     - Updated operator name from `.Values.name` to `.Values.operator.name`
     - Updated security contexts to use `.Values.operator.securityContext` and `.Values.operator.containerSecurityContext`
     - Updated init container to use `.Values.operator.initContainer.*`
     - Changed image reference from digest to tag-based
     - Added support for nodeSelector and tolerations
     - Updated environment variables to use `.Values.operator.env.*`
     - Changed imagePullSecrets from `.Values.global.imagePullSecrets` to `.Values.imagePullSecrets`

   - **serviceaccount.yaml**: Updated to use `.Release.Namespace` and added standard labels

   - **role.yaml**: Added conditional creation with `{{- if .Values.rbac.create }}` and updated labels

   - **rolebinding.yaml**: Added conditional creation and updated to use new values structure

   - **crd.yaml**: Added conditional installation with `{{- if .Values.crd.install }}` and updated labels

   - **NOTES.txt**: Updated all namespace and operator name references to use new values structure

3. **Removed Templates**
   - **namespace.yaml**: Removed (users create namespace manually before installation)
   - **imagepullsecret.yaml**: Removed (users create secrets manually before installation)

#### New Configuration Options

```yaml
# RBAC Configuration
rbac:
  create: true                    # Create RBAC resources

# CRD Configuration
crd:
  install: true                   # Install CRD with chart

# Operator Configuration
operator:
  name: ibm-content-operator
  resources: {...}
  securityContext: {...}
  containerSecurityContext: {...}
  initContainer:
    securityContext: {...}
    resources: {...}
  env:
    maxConcurrentReconciles: "10"
    ansibleGathering: smart
    fncmLicense: "accept"
  args:
    - '--zap-encoder=console'

# Pod Annotations
podAnnotations:
  productID: "..."
  productName: "..."
  productVersion: "..."
  productChargedContainers: ""
  productMetric: "..."

# Network Policy Labels
networkPolicyLabels:
  com.ibm.fncm.networking/egress-deny-all: "true"
  com.ibm.fncm.networking/egress-allow-same-namespace: "true"
  # ... additional network labels
```

#### Installation Changes

**Before:**
```bash
helm install content-op ./helm-charts/content-operator
```

**After:**
```bash
# Create namespace first
kubectl create namespace ibm-content

# Create image pull secret
kubectl create secret docker-registry ibm-entitlement-key \
  --docker-server=cp.icr.io \
  --docker-username=cp \
  --docker-password=<your-entitlement-key> \
  -n ibm-content

# Install chart
helm install content-op ./helm-charts/content-operator \
  --namespace ibm-content
```

#### Breaking Changes

- **Namespace**: No longer created by chart, must be created beforehand
- **Image Pull Secret**: No longer created by chart, must be created beforehand
- **Values Structure**: Completely restructured, existing values files need updating
- **Image Reference**: Changed from digest-based to tag-based
- **RBAC Scope**: Only namespace-scoped RBAC (no cluster-level permissions)

#### Migration Guide

If upgrading from previous version:

1. Export existing configuration:
   ```bash
   helm get values <release-name> > old-values.yaml
   ```

2. Create namespace and secrets manually:
   ```bash
   kubectl create namespace <namespace>
   kubectl create secret docker-registry ibm-entitlement-key ...
   ```

3. Update values file to new structure (see values.yaml for reference)

4. Upgrade release:
   ```bash
   helm upgrade <release-name> ./helm-charts/content-operator \
     --namespace <namespace> \
     -f new-values.yaml
   ```

#### Validation

Chart passes all validation:
```bash
helm lint ./helm-charts/content-operator
# Result: 1 chart(s) linted, 0 chart(s) failed
```

Template rendering works correctly:
```bash
helm template test ./helm-charts/content-operator --namespace test-ns
# Result: All templates render successfully
```

#### Benefits

- **Enterprise-Ready**: Follows Helm best practices for enterprise deployments
- **Namespace-Scoped**: All RBAC permissions are namespace-scoped for better security
- **Optional CRD**: Skip CRD installation if already present
- **Better Security**: Comprehensive security contexts and network policies
- **Cleaner Separation**: Prerequisites (namespace, secrets) managed separately
- **Standard Labels**: Consistent labeling across all resources
- **Multi-Architecture**: Support for amd64, s390x, and ppc64le

#### Documentation

- See [HELM_INTEGRATION_STRATEGY.md](../HELM_INTEGRATION_STRATEGY.md) for integration with Python scripts
- See [HELM_CHART_MIGRATION_GUIDE.md](../HELM_CHART_MIGRATION_GUIDE.md) for detailed migration steps
- See [values.yaml](values.yaml) for all configuration options